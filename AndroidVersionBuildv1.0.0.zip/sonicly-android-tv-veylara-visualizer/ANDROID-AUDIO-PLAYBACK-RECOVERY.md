# Android audio playback safety

The native Veylara TV visualizer is intentionally decoupled from Sonicly's shared Media3 audio output path. No custom `AudioProcessor`, custom renderer factory, WebView, microphone capture, or second playback engine is attached by the visualizer.

While a track is playing, the renderer uses Veylara's original synthetic Connect-mode pulse/bass/treble fallback to animate the scenes. This preserves playback stability but is not a measurement of the actual PCM waveform or frequency spectrum. Any future true audio analysis should be isolated and validated without changing the playback sink's output behavior.
