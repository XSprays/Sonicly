# Android TV Veylara Visualizer — build fix

This update corrects three Kotlin type mismatches in `SoniclyVisualizerScreen.kt`.

The `blobPath` helper accepts a `Float` seed. The Ring scene passed the integer literals `0`, `2`, and `1` for the ring, ripple, and cloud seeds. These are now `0f`, `2f`, and `1f`.

No visualizer layout, drawing algorithm, navigation, playback, or player code was changed.

Validation performed: source-level check of all `blobPath` call sites, balanced delimiters, and ZIP integrity. A full Android Gradle build and TCL TV runtime test were not available in this environment.
