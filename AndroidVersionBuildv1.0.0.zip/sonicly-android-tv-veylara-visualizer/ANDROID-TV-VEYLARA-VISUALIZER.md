# Veylara visualizer — Android TV native port

## Scope
This update ports the six visual scenes from the uploaded Veylara `visualizer.php` into Sonicly's Android TV Visualizer tab. The existing TV tab/navigation and persistent now-playing bar are left unchanged. The native TV control surface is redesigned for D-pad/remote focus.

## Veylara scenes
- **Ring:** animated irregular ring with layered neon strokes, water/floor reflection, cloud form, center Veylara mark, and beat ripples.
- **Blobs:** three morphing soft blobs, inner glow and equalizer mark.
- **Solar:** atmospheric morphing planet, surface puffs, orbital ellipse, moving comet/blob and trail.
- **Ducks:** layered moving waterline, foam highlights, seven bobbing rubber ducks and reflections.
- **Cat:** orange cartoon cat on a lit stage with ears, face, whiskers, tail, paws and music sparks.
- **Vinyl:** turntable plinth, spinning/grooved record, album art (full disc or center label), spindle, tonearm, orbiting lights and energy rings.

The visual scenes are native Jetpack Compose Canvas drawing. No WebView, JavaScript Canvas, browser GPU surface, or second playback engine is used. Veylara's original logo asset is included at `app/src/main/assets/veylara/veylara-logo.png`.

## Redesigned TV controls
- Six large theme selectors with persistent selected state and visible D-pad focus.
- Sensitivity minus/plus controls, persisted from 0.4× through 3.0×.
- Vinyl-only controls for volume, previous, play/pause, next, full-disc artwork and center-label artwork.
- Vinyl artwork is loaded off the UI thread through the existing authenticated Sonicly client. Artwork is capped by the existing client helper's 3 MB limit.

## Audio and playback safety
Veylara's browser implementation uses tab/system capture or microphone capture, with a synthetic Connect-mode fallback. Android TV cannot reuse browser tab capture. This native port uses Veylara's Connect-mode musical pulse/bass/treble fallback to animate the scenes while Sonicly is playing. It does not claim to analyze the exact PCM waveform/frequency spectrum.

The Android TV renderer does not install a custom Media3 audio processor, change the shared ExoPlayer renderer/audio sink, request microphone permission, or instantiate another player. Vinyl controls operate on the existing player and existing TV transport callbacks.

## Validation
- Original PHP visualizer source inspected; all six original theme IDs are represented in the Android renderer.
- D-pad controls remain Compose-native and focusable.
- Existing TV navigation and playback-service source files are not modified by this change.
- No WebView visualizer assets remain; only the Veylara logo asset is used.
- ZIP integrity and Kotlin delimiter checks passed.

A full Gradle/Android compilation and TCL TV runtime test were not available in the build environment. Please run **Build > Make Project** in Android Studio before installing. This limitation is intentional to avoid claiming a device test that was not performed.
