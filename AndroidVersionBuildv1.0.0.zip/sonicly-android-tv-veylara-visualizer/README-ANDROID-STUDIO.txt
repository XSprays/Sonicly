SONICLY ANDROID + ANDROID TV
============================

Open this folder (sonicly-android) in Android Studio and allow Gradle sync.
Select the app run configuration and deploy to a phone, tablet, Android TV device,
or the corresponding emulator.

DESIGN
------
The app adapts its layout based on Android's television UI mode:
- Phone/tablet: touch-first layout with search, category chips, featured player,
  album-art thumbnails, scrolling track list, and a persistent mini-player.
- Android TV: 10-foot layout with a left navigation rail, large Now Playing hero,
  search, horizontally browsable album-art cards, and a persistent player bar.
  Cards and navigation items are focusable for D-pad/remote use.

CONNECTION
----------
Enter the desktop Sonicly server address and pairing token shown in:
Sonicly Desktop > Settings > Sonicly mobile connection.
Both devices should initially be on the same trusted Wi-Fi network.

ALBUM ART
---------
The Android client reads artworkPath, artworkUrl, or coverArt from each track
object in /api/v1/library. If the desktop server does not provide one of these
fields (or an accessible artwork endpoint), the UI shows a built-in album icon.
The desktop API must expose artwork for real cover art to appear.

BUILD
-----
Use Android Studio's Sync Project with Gradle Files, then Build > Make Project.
Choose app as the run configuration. This project does not include a Gradle
wrapper binary; Android Studio can use its configured Gradle installation or
create/sync the wrapper for the project.

NOTE
----
This is a richer UI/client implementation, not a finished store release. Verify
Gradle sync and device playback against the exact desktop server build. Background
playback service, media notification, queue management, and remote-network access
remain future work.


Veylara native TV visualizer details: see ANDROID-TV-VEYLARA-VISUALIZER.md.
