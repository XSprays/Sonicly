Sonicly Android — Synchronized Video Lyrics
============================================

Implementation
--------------
- Reuses the existing LyricsRepository and its process-wide LRCLIB cache.
- Reuses the single existing Media3 Player/ExoPlayer. The lyrics UI never creates a player.
- Video media items now carry the library Track.id as their Media3 mediaId. The lyrics lookup waits for that specific media item to reach READY before using its duration, avoiding stale duration values when switching from audio to video.
- The Compose lyrics layer is drawn above the existing PlayerView. The bottom lyric card has a reserved gap (112 dp on phones, 148 dp on TV) for the native PlayerView controls.
- Synchronized results automatically enable the previous/current/next line overlay. The current line uses Sonicly blue-to-purple accent styling.
- The Lyrics button toggles the overlay. Fullscreen opens an independent Compose Dialog over the still-running video; Back / Back to video closes only the lyrics view.
- Plain lyrics remain available through the toggle preview and fullscreen text view. Missing/instrumental results show an explanatory status and do not show a fake timed overlay.
- TV controls and lyric rows are focusable and display a distinct focus border; TV uses larger typography and wider margins.

Media3 threading
----------------
- Media3 Player properties are read through onPlayerApplicationThread / readPlayerSnapshot, which marshal reads to Player.applicationLooper.
- awaitPlayerDuration uses a Player.Listener on the same application looper and waits for the selected media ID to become READY. It does not reuse a previous video's/audio item's duration.
- LRCLIB calls remain on Dispatchers.IO. The Player is never accessed from the network dispatcher.
- Lyrics synchronization waits for Media3 events or the next LRC timestamp. UI state is changed only when the active lyric index changes; no fixed high-frequency polling loop is used.

Files changed
-------------
- Added Media3Threading.kt
- Added VideoLyricsOverlay.kt
- Updated MainActivity.kt to overlay lyrics on the existing video PlayerView and set video media IDs / metadata.
- Updated PhoneLyricsDialog.kt to use the same safe player-thread access and event-driven line timing.
- Updated TvUi.kt to read player progress via the application-looper helper.
- LyricsRepository.kt, SoniclyClient.kt, ConnectUi.kt, LocalLibrary.kt, Storage.kt, PlaybackService.kt, AndroidManifest.xml, and Gradle build configuration are preserved from the supplied source project.
