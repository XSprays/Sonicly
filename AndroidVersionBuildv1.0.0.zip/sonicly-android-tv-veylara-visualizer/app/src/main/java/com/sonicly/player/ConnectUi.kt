package com.sonicly.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val CBlue = Color(0xFF39B9F5)
private val CPurple = Color(0xFF9460F5)
private val CPanel = Color(0xFF11182A)
private val CPanel2 = Color(0xFF19243C)
private val CMuted = Color(0xFFB9C7DC)
private val CGreen = Color(0xFF4ADE80)

internal data class PairingTarget(val address: String, val name: String, val challengeId: String)

internal class ConnectState(
    val isTv: Boolean,
    val paired: List<PairedComputer>,
    val found: List<DiscoveredHost>,
    val scanning: Boolean,
    val busy: Boolean,
    val status: String,
    val pairing: PairingTarget?,
    val pairCode: String,
    val ip: String,
    val localSources: List<LocalSource>,
    val scanCount: Int,
    val autoLoad: String
)

internal class ConnectActions(
    val scan: () -> Unit,
    val connectPaired: (PairedComputer) -> Unit,
    val forget: (PairedComputer) -> Unit,
    val pairNew: (DiscoveredHost) -> Unit,
    val setIp: (String) -> Unit,
    val connectIp: () -> Unit,
    val setCode: (String) -> Unit,
    val verify: () -> Unit,
    val cancelPair: () -> Unit,
    // phone only
    val addFolder: () -> Unit,
    val addFiles: () -> Unit,
    val removeLocal: (LocalSource) -> Unit,
    val openLocal: () -> Unit,
    val setAutoLoad: (String) -> Unit
)

private fun Modifier.narrow() = this.widthIn(max = 620.dp).fillMaxWidth()

/** Visible focus ring so the screen is usable with a TV remote too. */
private fun Modifier.focusRing(shape: Shape): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    Modifier.onFocusChanged { focused = it.hasFocus }
        .border(if (focused) 3.dp else 0.dp, if (focused) CBlue else Color.Transparent, shape)
}

private val fieldColors
    @Composable get() = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = CBlue, unfocusedBorderColor = Color.Gray,
        focusedLabelColor = CBlue, unfocusedLabelColor = Color.LightGray, cursorColor = CBlue
    )

/**
 * The screen shown while not connected. Phones get a hamburger menu (Connect / Local files / Settings);
 * Android TV only gets the computer list - local files are not offered on TV.
 */
@Composable
internal fun ConnectFlow(s: ConnectState, a: ConnectActions) {
    var page by remember { mutableStateOf("connect") }
    if (s.isTv) {
        ConnectPage(s, a)
        return
    }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(enabled = !drawer.isOpen && page != "connect") { page = "connect" }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = CPanel, drawerContentColor = Color.White) {
                Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(vertical = 12.dp)) {
                    Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
                        Brand(false)
                        Text("YOUR MEDIA, EVERYWHERE", color = CMuted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    val colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFF203B60), unselectedContainerColor = Color.Transparent,
                        selectedIconColor = CBlue, unselectedIconColor = Color(0xFFD8E2F0),
                        selectedTextColor = Color.White, unselectedTextColor = Color.White
                    )
                    listOf(
                        Triple("connect", "Connect to computer", Icons.Default.Computer),
                        Triple("local", "Local files", Icons.Default.PhoneAndroid),
                        Triple("settings", "Settings", Icons.Default.Settings)
                    ).forEach { (key, label, icon) ->
                        NavigationDrawerItem(
                            label = { Text(label) }, icon = { Icon(icon, null) }, selected = page == key,
                            onClick = { page = key; scope.launch { drawer.close() } },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding), colors = colors
                        )
                    }
                }
            }
        }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, "Open menu", tint = Color.White) }
                Text(
                    when (page) { "local" -> "Local files"; "settings" -> "Settings"; else -> "Connect" },
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                )
            }
            when (page) {
                "local" -> LocalPage(s, a)
                "settings" -> SettingsPage(s, a)
                else -> ConnectPage(s, a)
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text.uppercase(), color = CMuted, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.narrow().padding(top = 8.dp))
}

@Composable
private fun ComputerRow(
    title: String, subtitle: String, dot: Color?, action: String, enabled: Boolean,
    onClick: () -> Unit, onForget: (() -> Unit)? = null
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.narrow().clip(shape).background(CPanel).focusRing(shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Computer, null, tint = CBlue, modifier = Modifier.size(32.dp))
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (dot != null) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                    Spacer(Modifier.width(6.dp))
                }
                Text(subtitle, color = CMuted, fontSize = 12.sp, maxLines = 1)
            }
        }
        Text(action, color = CBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (onForget != null) IconButton(onClick = onForget) { Icon(Icons.Default.Delete, "Forget this computer", tint = CMuted) }
    }
}

@Composable
private fun ConnectPage(s: ConnectState, a: ConnectActions) {
    val pairedIds = s.paired.mapNotNull { it.hostId.takeIf { id -> id.isNotBlank() } }.toSet()
    val pairedHosts = s.paired.map { it.host }.toSet()
    val newHosts = s.found.filter { h -> !(h.hostId.isNotBlank() && h.hostId in pairedIds) && h.address !in pairedHosts }
    fun isOnline(pc: PairedComputer) = s.found.any { (pc.hostId.isNotBlank() && it.hostId == pc.hostId) || it.address == pc.host }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = if (s.isTv) 48.dp else 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(Modifier.narrow(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Brand(s.isTv)
                Text("Your music and videos. On every screen.", color = Color(0xFFE2E8F0))
            }
        }

        // Pairing in progress: enter the code shown on the computer.
        s.pairing?.let { p ->
            item {
                Column(
                    Modifier.narrow().clip(RoundedCornerShape(18.dp)).background(CPanel2).border(1.dp, CPurple, RoundedCornerShape(18.dp)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Pair with ${p.name}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Enter the 4-digit code now showing on that computer. It expires after 2 minutes.", color = CMuted, fontSize = 13.sp)
                    OutlinedTextField(
                        s.pairCode, a.setCode, label = { Text("4-digit desktop code", color = Color.LightGray) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth(), colors = fieldColors
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = a.verify, enabled = !s.busy && s.pairCode.length == 4, modifier = Modifier.weight(1f).height(50.dp)) {
                            Text(if (s.busy) "Please wait…" else "Verify & save")
                        }
                        TextButton(onClick = a.cancelPair) { Text("Cancel", color = CMuted) }
                    }
                }
            }
        }

        item { SectionLabel("Your computers") }
        if (s.paired.isEmpty()) {
            item { Text("No paired computers yet. Pair one below and it will stay here.", color = CMuted, fontSize = 13.sp, modifier = Modifier.narrow()) }
        } else {
            items(s.paired.sortedByDescending { it.lastUsed }, key = { it.hostId.ifBlank { it.host } }) { pc ->
                val online = isOnline(pc)
                ComputerRow(
                    title = pc.name.ifBlank { "Sonicly desktop" },
                    subtitle = pc.host.removePrefix("http://") + "  ·  " + if (online) "Online" else if (s.scanning) "Looking…" else "Not seen on this Wi-Fi",
                    dot = if (online) CGreen else Color.Gray,
                    action = "CONNECT", enabled = !s.busy,
                    onClick = { a.connectPaired(pc) }, onForget = { a.forget(pc) }
                )
            }
        }

        item {
            Row(Modifier.narrow().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("NEW COMPUTERS", color = CMuted, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = a.scan, enabled = !s.scanning && !s.busy) {
                    Icon(Icons.Default.Refresh, null, tint = CBlue, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (s.scanning) "Scanning…" else "Scan again", color = CBlue)
                }
            }
        }
        if (newHosts.isEmpty()) {
            item {
                Text(
                    if (s.scanning) "Searching this Wi-Fi network for Sonicly…" else "No new computers found. Make sure Sonicly is running on your PC and both devices share the same Wi-Fi, or connect by IP address below.",
                    color = CMuted, fontSize = 13.sp, modifier = Modifier.narrow()
                )
            }
        } else {
            items(newHosts, key = { it.address }) { h ->
                ComputerRow(
                    title = h.name.ifBlank { "Sonicly desktop" },
                    subtitle = h.address.removePrefix("http://") + "  ·  Needs pairing",
                    dot = CPurple, action = "PAIR", enabled = !s.busy,
                    onClick = { a.pairNew(h) }
                )
            }
        }

        item { SectionLabel("Connect by IP address") }
        item {
            Row(Modifier.narrow(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    s.ip, a.setIp, label = { Text("e.g. 192.168.1.20", color = Color.LightGray) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { a.connectIp() }),
                    modifier = Modifier.weight(1f), colors = fieldColors
                )
                Spacer(Modifier.width(10.dp))
                Button(onClick = a.connectIp, enabled = !s.busy && s.ip.isNotBlank(), modifier = Modifier.height(56.dp)) { Text("Connect") }
            }
        }
        item { Text("Port 47831 is added automatically. If this computer is already paired it connects right away; otherwise you'll be asked for its pairing code.", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.narrow()) }

        item { Text(s.status, color = Color(0xFF9EDBFF), fontSize = 13.sp, modifier = Modifier.narrow().padding(top = 4.dp, bottom = 24.dp)) }
    }
}

@Composable
private fun LocalPage(s: ConnectState, a: ConnectActions) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Play music and videos stored on this phone. Album art is read from the files themselves, or from a cover.jpg / folder.jpg in the same folder.",
            color = Color(0xFFE2E8F0), fontSize = 14.sp, modifier = Modifier.narrow()
        )
        Button(onClick = a.addFolder, modifier = Modifier.narrow().height(52.dp)) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Add music folder")
        }
        OutlinedButton(onClick = a.addFiles, modifier = Modifier.narrow().height(52.dp)) {
            Icon(Icons.Default.AudioFile, null, tint = CBlue); Spacer(Modifier.width(8.dp)); Text("Add individual files", color = Color.White)
        }

        SectionLabel("Sources on this phone")
        if (s.localSources.isEmpty()) {
            Text("Nothing added yet.", color = CMuted, fontSize = 13.sp, modifier = Modifier.narrow())
        } else {
            s.localSources.forEach { src ->
                Row(Modifier.narrow().clip(RoundedCornerShape(14.dp)).background(CPanel).padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (src.isFolder) Icons.Default.Folder else Icons.Default.AudioFile, null, tint = CBlue)
                    Text(src.name, color = Color.White, modifier = Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1)
                    IconButton(onClick = { a.removeLocal(src) }) { Icon(Icons.Default.Close, "Remove", tint = CMuted) }
                }
            }
        }

        Button(onClick = a.openLocal, enabled = !s.busy && s.localSources.isNotEmpty(), modifier = Modifier.narrow().height(54.dp)) {
            Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(8.dp))
            Text(if (s.busy) "Scanning… ${s.scanCount} files" else "Open local library")
        }
        Text(s.status, color = Color(0xFF9EDBFF), fontSize = 13.sp, modifier = Modifier.narrow())
    }
}

@Composable
private fun SettingsPage(s: ConnectState, a: ConnectActions) {
    val options = listOf(
        Triple("lastComputer", "Last computer", "Reconnect to the computer you used most recently."),
        Triple("local", "Local files", "Open the music and videos on this phone."),
        Triple("none", "Ask me each time", "Always start on this connect screen.")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("WHEN SONICLY OPENS, AUTO-LOAD", color = CMuted, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.narrow())
        options.forEach { (key, title, desc) ->
            val shape = RoundedCornerShape(16.dp)
            Row(
                Modifier.narrow().clip(shape).background(if (s.autoLoad == key) CPanel2 else CPanel)
                    .clickable { a.setAutoLoad(key) }.padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = s.autoLoad == key, onClick = { a.setAutoLoad(key) }, colors = RadioButtonDefaults.colors(selectedColor = CBlue, unselectedColor = Color.Gray))
                Column(Modifier.padding(start = 6.dp)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(desc, color = CMuted, fontSize = 12.sp)
                }
            }
        }
        HorizontalDivider(Modifier.narrow().padding(vertical = 8.dp), color = Color(0xFF293A55))
        Text(
            "Local files only auto-load once you've added a folder or files. If the chosen computer can't be reached, Sonicly stays on the connect screen.",
            color = Color.Gray, fontSize = 12.sp, modifier = Modifier.narrow()
        )
    }
}
