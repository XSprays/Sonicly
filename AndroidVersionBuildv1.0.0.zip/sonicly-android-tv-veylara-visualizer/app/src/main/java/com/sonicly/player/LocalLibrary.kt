package com.sonicly.player

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Phone-only: turns the folders / files the user picked (Storage Access Framework) into [Track]s.
 *
 * Album art comes from, in order: the artwork embedded in the file, a cover.jpg / folder.jpg / front.png
 * style image sitting in the same folder, or (for video) a frame grabbed from the file.
 * Tags + art are cached in an index file so re-scans only re-read files that changed.
 */
object LocalLibrary {
    private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "wma", "mka", "amr", "aiff", "aif", "m4b")
    private val VIDEO_EXT = setOf("mp4", "m4v", "webm", "mkv", "mov", "avi", "mpg", "mpeg", "3gp", "ogv")
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")
    private val COVER_NAMES = listOf("cover", "folder", "front", "album", "albumart", "albumartsmall", "thumb")

    private data class Found(val uri: Uri, val name: String, val mime: String, val modified: Long, val size: Long, val cover: Uri? = null)

    fun scan(context: Context, folders: List<Uri>, files: List<Uri>, onProgress: (Int) -> Unit): List<Track> {
        val resolver = context.contentResolver
        val found = LinkedHashMap<String, Found>()
        for (tree in folders) {
            runCatching { walk(resolver, tree, DocumentsContract.getTreeDocumentId(tree), found, 0) }
            onProgress(found.size)
        }
        for (u in files) {
            if (found.containsKey(u.toString())) continue
            querySingle(resolver, u)?.let { found[u.toString()] = it }
        }
        onProgress(found.size)

        val cache = loadCache(context)
        val newCache = ConcurrentHashMap<String, JSONObject>()
        val artDir = File(context.cacheDir, "localart").apply { mkdirs() }
        val done = AtomicInteger(0)
        val pool = Executors.newFixedThreadPool(4)
        val tracks = try {
            found.values.map { f ->
                pool.submit<Track?> {
                    try { buildTrack(context, f, cache[f.uri.toString()], artDir, newCache) }
                    catch (_: Exception) { null }
                    finally { onProgress(done.incrementAndGet()) }
                }
            }.mapNotNull { runCatching { it.get() }.getOrNull() }
        } finally { pool.shutdown() }
        saveCache(context, newCache)

        return tracks.sortedWith(
            compareBy<Track>({ it.albumArtist.ifBlank { it.artist }.lowercase() }, { it.album.lowercase() }, { it.discNumber }, { it.trackNumber }, { it.title.lowercase() })
        )
    }

    private fun walk(resolver: ContentResolver, tree: Uri, docId: String, out: MutableMap<String, Found>, depth: Int) {
        if (depth > 12) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val media = mutableListOf<Found>()
        val dirs = mutableListOf<String>()
        val covers = mutableMapOf<String, Uri>()
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_SIZE
        )
        resolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val mime = c.getString(2).orEmpty()
                if (name.startsWith(".")) continue
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) { dirs.add(id); continue }
                val ext = name.substringAfterLast('.', "").lowercase()
                val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                if (mime.startsWith("audio/") || mime.startsWith("video/") || ext in AUDIO_EXT || ext in VIDEO_EXT) {
                    media.add(Found(docUri, name, mime, c.getLong(3), c.getLong(4)))
                } else if (ext in IMAGE_EXT) {
                    val base = name.substringBeforeLast('.').lowercase()
                    if (base in COVER_NAMES) covers[base] = docUri
                }
            }
        }
        val cover = COVER_NAMES.firstNotNullOfOrNull { covers[it] }
        media.forEach { out[it.uri.toString()] = it.copy(cover = cover) }
        dirs.forEach { walk(resolver, tree, it, out, depth + 1) }
    }

    private fun querySingle(resolver: ContentResolver, uri: Uri): Found? = runCatching {
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_SIZE
        )
        resolver.query(uri, cols, null, null, null)?.use { c ->
            if (!c.moveToFirst()) return@use null
            Found(uri, c.getString(0).orEmpty().ifBlank { uri.lastPathSegment.orEmpty() }, c.getString(1).orEmpty(), c.getLong(2), c.getLong(3))
        }
    }.getOrNull()

    private fun buildTrack(context: Context, f: Found, old: JSONObject?, artDir: File, newCache: MutableMap<String, JSONObject>): Track {
        val key = f.uri.toString()
        val ext = f.name.substringAfterLast('.', "").lowercase()
        val isVideo = f.mime.startsWith("video/") || (!f.mime.startsWith("audio/") && ext in VIDEO_EXT)
        val reusable = old != null && old.optLong("m") == f.modified && old.optLong("s") == f.size &&
            (old.optString("art").isEmpty() || File(old.optString("art")).exists())
        val e = if (reusable) old!! else readMeta(context, f, isVideo, artDir)
        newCache[key] = e
        val art = e.optString("art")
        val artwork = when {
            art.isNotEmpty() -> "file://$art"
            f.cover != null -> f.cover.toString()
            else -> ""
        }
        return Track(
            id = "local:$key",
            title = e.optString("t").ifBlank { f.name.substringBeforeLast('.') },
            artist = e.optString("a"),
            album = e.optString("al"),
            mime = f.mime.ifBlank { if (isVideo) "video/mp4" else "audio/mpeg" },
            streamPath = key,
            artworkPath = artwork,
            mediaType = if (isVideo) "video" else "audio",
            albumArtist = e.optString("aa"),
            trackNumber = e.optInt("tn"),
            discNumber = e.optInt("dn")
        )
    }

    private fun readMeta(context: Context, f: Found, isVideo: Boolean, artDir: File): JSONObject {
        val out = JSONObject().put("m", f.modified).put("s", f.size).put("art", "")
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, f.uri)
            fun tag(k: Int) = r.extractMetadata(k).orEmpty().trim()
            val artist = tag(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            val album = tag(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            val albumArtist = tag(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
            out.put("t", tag(MediaMetadataRetriever.METADATA_KEY_TITLE)).put("a", artist).put("al", album).put("aa", albumArtist)
                .put("tn", leadingInt(tag(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)))
                .put("dn", leadingInt(tag(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER)))
            if (isVideo) {
                val file = File(artDir, md5("v|${f.uri}") + ".jpg")
                if (!file.exists()) {
                    val frame = r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    if (frame != null) {
                        val w = 480
                        val h = (frame.height * w / frame.width.toFloat()).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(frame, w, h, true)
                        file.outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 82, it) }
                        if (scaled !== frame) frame.recycle()
                        scaled.recycle()
                    }
                }
                if (file.exists()) out.put("art", file.absolutePath)
            } else {
                val pic = r.embeddedPicture
                if (pic != null && pic.isNotEmpty()) {
                    // Songs from the same album share one cached image.
                    val artKey = if (album.isNotBlank()) "a|${albumArtist.ifBlank { artist }}|$album" else "u|${f.uri}"
                    val file = File(artDir, md5(artKey) + ".img")
                    if (!file.exists()) file.writeBytes(pic)
                    out.put("art", file.absolutePath)
                }
            }
        } catch (_: Exception) {
            // Unreadable tags: fall back to the file name.
        } finally {
            runCatching { r.release() }
        }
        return out
    }

    private fun leadingInt(s: String): Int = s.takeWhile { it.isDigit() }.toIntOrNull() ?: 0

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun cacheFile(context: Context) = File(context.filesDir, "local_index_v1.json")

    private fun loadCache(context: Context): Map<String, JSONObject> = runCatching {
        val root = JSONObject(cacheFile(context).readText())
        root.keys().asSequence().associateWith { root.getJSONObject(it) }
    }.getOrDefault(emptyMap())

    private fun saveCache(context: Context, cache: Map<String, JSONObject>) {
        runCatching {
            val root = JSONObject()
            cache.forEach { (k, v) -> root.put(k, v) }
            cacheFile(context).writeText(root.toString())
        }
    }
}
