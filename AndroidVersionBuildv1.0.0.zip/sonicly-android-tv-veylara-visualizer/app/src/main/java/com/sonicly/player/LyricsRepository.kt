package com.sonicly.player

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** A timed lyric line. [timestampMs] is the point at which this line becomes current. */
data class SoniclyLyricLine(
    val timestampMs: Long,
    val text: String
)

/** Lyrics returned by LRCLIB. A result may contain synced lyrics, plain lyrics, or both. */
data class SoniclyLyrics(
    val plainLyrics: String?,
    val syncedLyrics: List<SoniclyLyricLine>,
    val instrumental: Boolean,
    val matchedTitle: String = "",
    val matchedArtist: String = ""
)

/**
 * LRCLIB client. It does not need an API key. The exact metadata endpoint is tried first;
 * if it has no exact record, the search endpoint is used and results are filtered by title
 * and artist so Sonicly does not casually show lyrics for a different song.
 */
object LyricsRepository {
    private const val BASE_URL = "https://lrclib.net/api"
    private const val CLIENT_HEADER = "Sonicly/1.0.0 (https://xspraysyt.com/)"
    private var retryNotBeforeMs = 0L
    private var lastRequestAtMs = 0L
    private val cache = ConcurrentHashMap<String, SoniclyLyrics>()

    @Throws(IOException::class)
    fun lookup(
        title: String,
        artist: String,
        album: String,
        durationMs: Long
    ): SoniclyLyrics? {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return null
        val cacheKey = listOf(cleanTitle, artist.trim(), album.trim(), durationMs.toString()).joinToString("\u001F").lowercase()
        cache[cacheKey]?.let { return it }

        // /api/get requires both the title and artist. Duration is highly useful for
        // matching, so skip this endpoint when the player has not reported a duration yet.
        if (artist.isNotBlank() && durationMs >= 1_000L && durationMs < 3_600_000L) {
            val exactParams = buildList {
                add("track_name=${encode(cleanTitle)}")
                add("artist_name=${encode(artist.trim())}")
                if (album.isNotBlank()) add("album_name=${encode(album.trim())}")
                add("duration=${durationMs / 1000L}")
            }.joinToString("&")
            val exactResponse = request("$BASE_URL/get?$exactParams", allowNotFound = true)
            if (exactResponse != null) parse(exactResponse)?.let {
                cache[cacheKey] = it
                return it
            }
        }

        // LRCLIB requests clients to pace requests; do not immediately hammer the
        // service after an exact-match miss.
        val searchQuery = listOf(cleanTitle, artist.trim()).filter { it.isNotBlank() }.joinToString(" ")
        val searchJson = request("$BASE_URL/search?q=${encode(searchQuery)}", allowNotFound = true) ?: return null
        val results = JSONArray(searchJson)
        if (results.length() == 0) return null

        val normalizedTitle = normalize(cleanTitle)
        val normalizedArtist = normalize(artist)
        val candidates = (0 until results.length()).mapNotNull { index ->
            results.optJSONObject(index)?.let { json ->
                val candidateTitle = normalize(json.optString("trackName"))
                val candidateArtist = normalize(json.optString("artistName"))
                val titleMatch = candidateTitle == normalizedTitle
                val artistMatch = normalizedArtist.isBlank() || candidateArtist == normalizedArtist ||
                    candidateArtist.contains(normalizedArtist) || normalizedArtist.contains(candidateArtist)
                if (titleMatch && artistMatch) json else null
            }
        }
        val requestedSeconds = if (durationMs > 0L) durationMs / 1000L else 0L
        val normalizedAlbum = normalize(album)
        val best = candidates.minByOrNull { candidate ->
            val candidateDuration = candidate.optLong("duration", 0L)
            val durationPenalty = if (requestedSeconds == 0L || candidateDuration == 0L) 50_000L
                else kotlin.math.abs(candidateDuration - requestedSeconds) * 1_000L
            val albumPenalty = if (normalizedAlbum.isBlank() || normalize(candidate.optString("albumName")) == normalizedAlbum) 0L else 100L
            albumPenalty + durationPenalty
        } ?: return null
        val result = parse(best.toString()) ?: return null
        // The API search is broader; keep the metadata match strict and reject a
        // duration mismatch when both sides have one, rather than displaying a wrong recording.
        val resultDuration = best.optLong("duration", 0L)
        if (requestedSeconds > 0L && resultDuration > 0L && kotlin.math.abs(resultDuration - requestedSeconds) > 12L) return null
        cache[cacheKey] = result
        return result
    }

    @Synchronized
    private fun request(url: String, allowNotFound: Boolean): String? {
        val cooldownRemaining = retryNotBeforeMs - System.currentTimeMillis()
        if (cooldownRemaining > 0L) {
            throw IOException("LRCLIB asked Sonicly to slow down. Try again in ${(cooldownRemaining + 999L) / 1000L} seconds.")
        }
        // Keep sequential requests separated by a small, respectful interval.
        val waitMs = 300L - (System.currentTimeMillis() - lastRequestAtMs)
        if (waitMs > 0L) Thread.sleep(waitMs)
        lastRequestAtMs = System.currentTimeMillis()
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 10_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Lrclib-Client", CLIENT_HEADER)
            setRequestProperty("User-Agent", CLIENT_HEADER)
        }
        try {
            val status = connection.responseCode
            return when (status) {
                in 200..299 -> connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                404 -> if (allowNotFound) null else throw IOException("Lyrics were not found.")
                429 -> {
                    val retryAfterSeconds = connection.getHeaderField("Retry-After")?.trim()?.toLongOrNull()?.coerceIn(1L, 86_400L) ?: 60L
                    retryNotBeforeMs = System.currentTimeMillis() + retryAfterSeconds * 1000L
                    throw IOException("LRCLIB asked Sonicly to slow down. Try again in $retryAfterSeconds seconds.")
                }
                else -> {
                    val detail = runCatching {
                        connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    }.getOrNull().orEmpty()
                    throw IOException("LRCLIB returned HTTP $status${if (detail.isBlank()) "." else ": $detail"}")
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun parse(raw: String): SoniclyLyrics? {
        val json = JSONObject(raw)
        val plain = json.optString("plainLyrics").takeUnless { it == "null" || it.isBlank() }
        val syncedRaw = json.optString("syncedLyrics").takeUnless { it == "null" || it.isBlank() }
        val synced = syncedRaw?.let(::parseLrc).orEmpty()
        val instrumental = json.optBoolean("instrumental", false)
        if (plain == null && synced.isEmpty() && !instrumental) return null
        return SoniclyLyrics(
            plainLyrics = plain,
            syncedLyrics = synced,
            instrumental = instrumental,
            matchedTitle = json.optString("trackName"),
            matchedArtist = json.optString("artistName")
        )
    }

    /** Supports one or several timestamps on a single LRC line, and 1–3 decimal digits. */
    internal fun parseLrc(value: String): List<SoniclyLyricLine> {
        val timestampPattern = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")
        return buildList {
            value.lineSequence().forEach lineLoop@{ row ->
                val matches = timestampPattern.findAll(row).toList()
                if (matches.isEmpty()) return@lineLoop
                val text = timestampPattern.replace(row, "").trim()
                matches.forEach matchLoop@{ match ->
                    val minutes = match.groupValues[1].toLongOrNull() ?: return@matchLoop
                    val seconds = match.groupValues[2].toLongOrNull() ?: return@matchLoop
                    val fractionText = match.groupValues[3]
                    val fractionMs = when (fractionText.length) {
                        0 -> 0L
                        1 -> fractionText.toLongOrNull()?.times(100L) ?: 0L
                        2 -> fractionText.toLongOrNull()?.times(10L) ?: 0L
                        else -> fractionText.take(3).toLongOrNull() ?: 0L
                    }
                    add(SoniclyLyricLine((minutes * 60L + seconds) * 1000L + fractionMs, text))
                }
            }
        }.sortedBy { it.timestampMs }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
    private fun normalize(value: String): String = value.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}
