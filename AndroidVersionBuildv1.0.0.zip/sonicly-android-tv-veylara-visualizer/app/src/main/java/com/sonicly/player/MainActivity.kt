package com.sonicly.player

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Navy = Color(0xFF080B18)
private val Panel = Color(0xFF11182A)
private val Panel2 = Color(0xFF19243C)
private val Blue = Color(0xFF39B9F5)
private val Purple = Color(0xFF9460F5)

class MainActivity : ComponentActivity() {
    private var releaseController: (() -> Unit)? = null

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* playback works either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = PlayerHolder.get(this)
        // Bind to the playback service so it stays alive for background playback.
        val future = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        releaseController = { MediaController.releaseFuture(future) }
        // Android 13+ needs permission to show the media notification / lock-screen controls.
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val tv = (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION
        setContent { SoniclyApp(this, player, tv) }
    }

    // Music keeps playing in the background; only video pauses when the app is hidden.
    override fun onStop() { super.onStop(); if (PlayerHolder.video) PlayerHolder.get(this).pause() }
    override fun onDestroy() { releaseController?.invoke(); releaseController = null; super.onDestroy() }
}

@Composable
private fun SoniclyApp(context: Context, player: ExoPlayer, isTv: Boolean) {
    val prefs = remember { context.getSharedPreferences("sonicly", Context.MODE_PRIVATE) }
    val pairedStore = remember { PairedStore(prefs) }
    val localSources = remember { LocalSources(context, prefs) }
    var paired by remember { mutableStateOf(pairedStore.load()) }
    var localList by remember { mutableStateOf(localSources.list()) }
    var host by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var localMode by remember { mutableStateOf(false) }
    var connected by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Pick a computer to connect to.") }
    var libraryError by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf(emptyList<Track>()) }
    var selected by remember { mutableStateOf<Track?>(null) }
    var playing by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var found by remember { mutableStateOf(emptyList<DiscoveredHost>()) }
    var scanning by remember { mutableStateOf(false) }
    var pairing by remember { mutableStateOf<PairingTarget?>(null) }
    var pairCode by remember { mutableStateOf("") }
    var ipInput by remember { mutableStateOf("") }
    var scanCount by remember { mutableIntStateOf(0) }
    var launchDone by remember { mutableStateOf(false) }
    // Android TV never uses local files, so it always auto-loads the last computer.
    var autoLoad by remember { mutableStateOf(if (isTv) "lastComputer" else prefs.getString("autoLoad", "lastComputer") ?: "lastComputer") }
    var query by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("Home") }
    var videoToPlay by remember { mutableStateOf<Track?>(null) }
    val scope = rememberCoroutineScope()
    val client = remember(host, token, localMode) {
        if (localMode) SoniclyClient.local()
        else if (host.isNotBlank() && token.isNotBlank()) runCatching { SoniclyClient(host, token) }.getOrNull() else null
    }
    val folderPicker = rememberLauncherForActivityResult(PickFolder()) { uri ->
        if (uri != null) { localSources.add(uri, true); localList = localSources.list() }
    }
    val filesPicker = rememberLauncherForActivityResult(PickFiles()) { uris ->
        uris.forEach { localSources.add(it, false) }; localList = localSources.list()
    }

    // ---- source switching -------------------------------------------------------------------
    fun resetSource() {
        player.pause(); player.clearMediaItems()
        PlayerHolder.video = false
        selected = null; query = ""; section = "Home"
    }

    suspend fun scanNetwork() {
        scanning = true
        val hosts = withContext(Dispatchers.IO) { runCatching { SoniclyClient.discoverHosts() }.getOrDefault(emptyList()) }
        found = hosts
        // A paired computer that changed address keeps working: remember where it is now.
        hosts.forEach { h ->
            paired.firstOrNull { it.hostId.isNotBlank() && it.hostId == h.hostId && it.host != h.address }?.let { pairedStore.upsert(it.copy(host = h.address)) }
        }
        paired = pairedStore.load()
        if (!connected) status = if (hosts.isEmpty()) "No Sonicly computers found on this Wi-Fi. You can still connect by IP address." else "Choose a computer below."
        scanning = false
    }

    suspend fun openDesktop(pc: PairedComputer) {
        busy = true
        status = "Connecting to ${pc.name.ifBlank { "your computer" }}…"
        try {
            var target = pc
            var c = SoniclyClient(target.host, target.token)
            val msg = try {
                withContext(Dispatchers.IO) { c.checkConnection() }
            } catch (e: Exception) {
                val relocated = withContext(Dispatchers.IO) { SoniclyClient.findHost(pc.hostId) }
                if (relocated.isNullOrBlank()) throw IllegalStateException(
                    if (e.message?.contains("rejected") == true) "${pc.name} no longer accepts this device. Forget it and pair again."
                    else "${pc.name.ifBlank { "That computer" }} is not reachable. Make sure it is running on the same Wi-Fi."
                )
                target = pc.copy(host = relocated)
                c = SoniclyClient(relocated, pc.token)
                withContext(Dispatchers.IO) { c.checkConnection() }
            }
            val list = withContext(Dispatchers.IO) { c.library() }
            resetSource()
            pairedStore.upsert(target.copy(lastUsed = System.currentTimeMillis())); paired = pairedStore.load()
            localMode = false; host = target.host; token = target.token
            tracks = list; connected = true
            libraryError = if (list.isEmpty()) "Desktop connected, but its library is empty." else ""
            status = "$msg · ${list.size} media items"
        } catch (e: Exception) { status = e.message ?: "Could not connect." }
        busy = false
    }

    suspend fun beginPairing(address: String, name: String) {
        busy = true
        status = "Requesting a secure pairing code…"
        try {
            val result = withContext(Dispatchers.IO) { SoniclyClient.requestPair(address, android.os.Build.MODEL) }
            pairing = PairingTarget(address, name, result.optString("challengeId")); pairCode = ""
            status = "A 4-digit code is now shown on $name. Enter it within 2 minutes."
        } catch (e: Exception) { status = e.message ?: "Could not request pairing." }
        busy = false
    }

    suspend fun finishPairing() {
        val p = pairing ?: return
        busy = true
        status = "Verifying code…"
        try {
            val result = withContext(Dispatchers.IO) { SoniclyClient.completePair(p.address, p.challengeId, pairCode) }
            val newToken = result.getString("token")
            val c = SoniclyClient(p.address, newToken)
            val msg = withContext(Dispatchers.IO) { c.checkConnection() }
            val list = withContext(Dispatchers.IO) { c.library() }
            val pc = PairedComputer(result.optString("hostId").ifBlank { p.address }, p.name, p.address, newToken, result.optString("deviceId"), System.currentTimeMillis())
            resetSource()
            pairedStore.upsert(pc); paired = pairedStore.load()
            pairing = null; pairCode = ""
            localMode = false; host = p.address; token = newToken
            tracks = list; connected = true
            libraryError = if (list.isEmpty()) "Desktop connected, but its media library is empty." else ""
            status = "$msg · ${list.size} media items"
        } catch (e: Exception) { status = e.message ?: "Could not pair." }
        busy = false
    }

    suspend fun connectByIp() {
        val address = SoniclyClient.normalizeAddress(ipInput)
        if (address.isBlank()) return
        busy = true
        status = "Contacting $address…"
        val info = try { withContext(Dispatchers.IO) { SoniclyClient.probe(address) } } catch (_: Exception) { null }
        busy = false
        if (info == null) { status = "Couldn't find a Sonicly desktop at $address. Check the address and that Sonicly is running."; return }
        val existing = paired.firstOrNull { (info.hostId.isNotBlank() && it.hostId == info.hostId) || it.host == address }
        if (existing != null) openDesktop(existing.copy(host = address))
        else beginPairing(address, info.name.ifBlank { address.removePrefix("http://") })
    }

    suspend fun openLocal() {
        busy = true; scanCount = 0
        status = "Scanning files on this phone…"
        try {
            val folders = localSources.folders(); val files = localSources.files()
            val list = withContext(Dispatchers.IO) { LocalLibrary.scan(context, folders, files) { scanCount = it } }
            if (list.isEmpty()) status = "No music or video files were found in your local sources."
            else {
                resetSource()
                localMode = true; host = ""; token = ""
                tracks = list; connected = true; libraryError = ""
                status = "${list.size} local files"
            }
        } catch (e: Exception) { status = e.message ?: "Could not read local files." }
        busy = false
    }

    suspend fun refreshLibrary() {
        busy = true
        try {
            val latest = if (localMode) {
                val folders = localSources.folders(); val files = localSources.files()
                withContext(Dispatchers.IO) { LocalLibrary.scan(context, folders, files) { } }
            } else withContext(Dispatchers.IO) { client!!.library() }
            tracks = latest
            libraryError = if (latest.isEmpty()) (if (localMode) "No local media found. Check the folders you added." else "Desktop connected, but no media was returned. Check the desktop library folders and refresh.") else ""
            status = "Loaded ${latest.size} media items" + if (localMode) "" else " from desktop"
        } catch (e: Exception) { libraryError = e.message ?: "Library refresh failed"; status = "Library refresh failed" }
        busy = false
    }

    // Launch behaviour: auto-load the chosen source, then show who is on the network.
    LaunchedEffect(Unit) {
        if (autoLoad == "local" && !isTv && localSources.list().isNotEmpty()) openLocal()
        else if (autoLoad == "lastComputer") paired.maxByOrNull { it.lastUsed }?.let { openDesktop(it) }
        if (!connected) scanNetwork()
        launchDone = true
    }
    // Coming back to the connect screen later: look for computers again.
    LaunchedEffect(connected) { if (!connected && launchDone) scanNetwork() }

    val tracksState = rememberUpdatedState(tracks)
    DisposableEffect(player) {
        playing = player.isPlaying
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            // Queue auto-advance / notification next-previous: keep the UI's "now playing" in sync.
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val id = mediaItem?.mediaId.orEmpty()
                if (id.isNotEmpty()) tracksState.value.firstOrNull { it.id == id }?.let { selected = it }
            }
        }
        player.addListener(listener); onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(tracks) {
        if (selected == null) player.currentMediaItem?.mediaId?.takeIf { it.isNotEmpty() }?.let { id -> tracks.firstOrNull { it.id == id }?.let { selected = it } }
    }
    val filtered = tracks.filter { track ->
        val matchesQuery = listOf(track.title, track.artist, track.album).any { it.contains(query, true) }
        val matchesSection = when (section) {
            "Videos" -> track.mediaType == "video"
            "Music" -> track.mediaType != "video"
            "All Media", "Home", "Albums", "Artists" -> true
            else -> true
        }
        matchesQuery && matchesSection
    }.let { list ->
        when (section) {
            "Albums" -> list.sortedWith(compareBy<Track>({ it.album.ifBlank { "~" }.lowercase() }, { it.discNumber }, { it.trackNumber }, { it.title.lowercase() }))
            "Artists" -> list.sortedWith(compareBy<Track>({ it.artist.ifBlank { "~" }.lowercase() }, { it.album.lowercase() }, { it.discNumber }, { it.trackNumber }, { it.title.lowercase() }))
            else -> list
        }
    }
    fun playSelected(track: Track, queue: List<Track> = filtered) {
        if (track.mediaType == "video") { videoToPlay = track; PlayerHolder.video = true }
        else { PlayerHolder.video = false; playTrack(context, player, client!!, queue, track) }
        selected = track
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, onPrimary = Navy, secondary = Purple, onSecondary = Navy, background = Navy, onBackground = Color.White, surface = Panel, onSurface = Color.White, surfaceVariant = Panel2, onSurfaceVariant = Color(0xFFE2E8F0), primaryContainer = Color(0xFF153A5A), onPrimaryContainer = Color.White, secondaryContainer = Color(0xFF30204F), onSecondaryContainer = Color.White)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy, contentColor = Color.White) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10182B), Color(0xFF080B18), Color(0xFF090D1A))))) {
            if (!connected) {
                ConnectFlow(
                    ConnectState(isTv, paired, found, scanning, busy, status, pairing, pairCode, ipInput, localList, scanCount, autoLoad),
                    ConnectActions(
                        scan = { scope.launch { scanNetwork() } },
                        connectPaired = { pc -> scope.launch { openDesktop(pc) } },
                        forget = { pc -> pairedStore.remove(pc); paired = pairedStore.load() },
                        pairNew = { h -> scope.launch { beginPairing(h.address, h.name.ifBlank { "Sonicly desktop" }) } },
                        setIp = { ipInput = it },
                        connectIp = { scope.launch { connectByIp() } },
                        setCode = { pairCode = it.filter(Char::isDigit).take(4) },
                        verify = { scope.launch { finishPairing() } },
                        cancelPair = { pairing = null; pairCode = ""; status = "Pairing cancelled." },
                        addFolder = { folderPicker.launch(null) },
                        addFiles = { filesPicker.launch(arrayOf("audio/*", "video/*")) },
                        removeLocal = { src -> localSources.remove(src); localList = localSources.list() },
                        openLocal = { scope.launch { openLocal() } },
                        setAutoLoad = { v -> autoLoad = v; prefs.edit().putString("autoLoad", v).apply() }
                    )
                )
            } else if (isTv) {
                TvHome(
                    tracks, filtered, selected, playing, client!!, player, query, { query = it }, section, { section = it },
                    { t, q -> playSelected(t, q) },
                    { if (player.isPlaying) player.pause() else if (selected != null) player.play() },
                    { if (player.hasPreviousMediaItem() || player.currentPosition > 3000) player.seekToPrevious() },
                    { if (player.hasNextMediaItem()) player.seekToNext() },
                    { scope.launch { refreshLibrary() } },
                    libraryError
                )
            } else {
                MobileHome(
                    tracks, filtered, selected, playing, client!!, player, query, { query = it }, section, { section = it },
                    { t, q -> playSelected(t, q) },
                    { if (player.isPlaying) player.pause() else if (selected != null) player.play() },
                    { if (player.hasPreviousMediaItem() || player.currentPosition > 3000) player.seekToPrevious() },
                    { if (player.hasNextMediaItem()) player.seekToNext() },
                    { scope.launch { refreshLibrary() } },
                    { player.pause(); connected = false },
                    libraryError
                )
            }
            videoToPlay?.let { video ->
                androidx.compose.ui.window.Dialog(
                    onDismissRequest = {
                        scope.launch {
                            onPlayerApplicationThread(player) { player.pause() }
                            PlayerHolder.video = false
                            videoToPlay = null
                        }
                    },
                    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Column(Modifier.fillMaxSize().background(Color.Black), verticalArrangement = Arrangement.Center) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(video.title, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(onClick = {
                                scope.launch {
                                    onPlayerApplicationThread(player) { player.pause() }
                                    PlayerHolder.video = false
                                    videoToPlay = null
                                }
                            }) { Text("Close", color = Color.White) }
                        }
                        Box(Modifier.fillMaxWidth().weight(1f)) {
                            AndroidView(
                                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                                modifier = Modifier.fillMaxSize()
                            )
                            VideoLyricsOverlay(
                                track = video,
                                player = player,
                                isTv = isTv,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
                LaunchedEffect(video.id) {
                    val source = DefaultDataSource.Factory(context, DefaultHttpDataSource.Factory().setDefaultRequestProperties(client!!.authHeaders()))
                    val videoItem = MediaItem.Builder()
                        .setMediaId(video.id)
                        .setUri(client!!.streamUrl(video))
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(video.title)
                                .setArtist(video.artist.ifBlank { null })
                                .setAlbumTitle(video.album.ifBlank { null })
                                .build()
                        )
                        .build()
                    val mediaSource = DefaultMediaSourceFactory(source).createMediaSource(videoItem)
                    onPlayerApplicationThread(player) {
                        player.setMediaSource(mediaSource)
                        player.prepare()
                        player.play()
                    }
                }
            }
        }
        }
    }
}

/** Plays [track] and queues the rest of [queue] (audio only) so playback continues in the background. */
private fun playTrack(context: Context, player: ExoPlayer, client: SoniclyClient, queue: List<Track>, track: Track) {
    // DefaultDataSource handles http(s) from the desktop as well as content:// / file:// on this phone.
    val source = DefaultDataSource.Factory(context, DefaultHttpDataSource.Factory().setDefaultRequestProperties(client.authHeaders()))
    val factory = DefaultMediaSourceFactory(source)
    val list = queue.filter { it.mediaType != "video" }.let { if (it.any { t -> t.id == track.id }) it else listOf(track) }
    val sources = list.map { t ->
        factory.createMediaSource(
            MediaItem.Builder()
                .setMediaId(t.id)
                .setUri(client.streamUrl(t))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist.ifBlank { null }).setAlbumTitle(t.album.ifBlank { null })
                    .setArtworkUri(client.artworkUrl(t)?.takeIf { isLocalUri(it) }?.let { android.net.Uri.parse(it) }).build())
                .build()
        )
    }
    player.setMediaSources(sources, list.indexOfFirst { it.id == track.id }.coerceAtLeast(0), C.TIME_UNSET)
    player.prepare(); player.play()
}

@Composable internal fun Brand(tv: Boolean) {
    Text("Sonicly", fontSize = if (tv) 48.sp else 38.sp, fontWeight = FontWeight.Bold, style = LocalTextStyle.current.copy(brush = Brush.horizontalGradient(listOf(Blue, Purple))))
}

private data class MobileGroup(val kind: String, val name: String)

private fun sectionIcon(item: String): androidx.compose.ui.graphics.vector.ImageVector = when (item) {
    "Home" -> Icons.Default.Home
    "Albums" -> Icons.Default.Album
    "Artists" -> Icons.Default.People
    "Videos" -> Icons.Default.Movie
    "Music" -> Icons.Default.MusicNote
    else -> Icons.Default.VideoLibrary
}

@Composable
private fun MobileHome(
    all: List<Track>,
    tracks: List<Track>,
    selected: Track?,
    playing: Boolean,
    client: SoniclyClient,
    player: Player,
    query: String,
    onQuery: (String) -> Unit,
    section: String,
    onSection: (String) -> Unit,
    onPlay: (Track, List<Track>) -> Unit,
    onToggle: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRefresh: () -> Unit,
    onDisconnect: () -> Unit,
    libraryError: String
) {
    val menuItems = listOf("Home", "All Media", "Music", "Videos", "Albums", "Artists")
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var searching by remember { mutableStateOf(false) }
    var group by remember { mutableStateOf<MobileGroup?>(null) }
    val searchFocus = remember { FocusRequester() }
    LaunchedEffect(section) { group = null }
    LaunchedEffect(searching) { if (searching) runCatching { searchFocus.requestFocus() } }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(enabled = !drawerState.isOpen && group != null) { group = null }
    BackHandler(enabled = !drawerState.isOpen && group == null && searching) { onQuery(""); searching = false }

    val musicCount = all.count { it.mediaType != "video" }
    val videoCount = all.count { it.mediaType == "video" }
    val showGroups = (section == "Albums" || section == "Artists") && group == null
    fun keyOf(t: Track) = if (section == "Albums" || group?.kind == "Albums") t.album.ifBlank { "Unknown album" } else t.artist.ifBlank { "Unknown artist" }
    val groups = if (showGroups) tracks.filter { it.mediaType != "video" }.groupBy { keyOf(it) }.entries.sortedBy { it.key.lowercase() } else emptyList()
    val visible = if (group != null) {
        tracks.filter { keyOf(it) == group!!.name }
            .sortedWith(compareBy<Track>({ it.discNumber }, { it.trackNumber }, { it.title.lowercase() }))
    } else tracks
    val featured = selected ?: visible.firstOrNull { it.mediaType != "video" } ?: visible.firstOrNull()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Panel, drawerContentColor = Color.White) {
                Column(Modifier.fillMaxHeight().verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(vertical = 12.dp)) {
                    Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
                        Brand(false)
                        Text("YOUR MEDIA, EVERYWHERE", color = Color(0xFFB9C7DC), fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("$musicCount music  ·  $videoCount videos", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                    val colors = NavigationDrawerItemDefaults.colors(
                        selectedContainerColor = Color(0xFF203B60), unselectedContainerColor = Color.Transparent,
                        selectedIconColor = Blue, unselectedIconColor = Color(0xFFD8E2F0),
                        selectedTextColor = Color.White, unselectedTextColor = Color.White
                    )
                    menuItems.forEach { item ->
                        NavigationDrawerItem(
                            label = { Text(item) },
                            icon = { Icon(sectionIcon(item), null) },
                            selected = section == item,
                            onClick = { onSection(item); scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                            colors = colors
                        )
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp, horizontal = 24.dp), color = Color(0xFF293A55))
                    NavigationDrawerItem(
                        label = { Text("Refresh library") }, icon = { Icon(Icons.Default.Refresh, null) }, selected = false,
                        onClick = { onRefresh(); scope.launch { drawerState.close() } },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding), colors = colors
                    )
                    NavigationDrawerItem(
                        label = { Text("Change desktop") }, icon = { Icon(Icons.Default.LinkOff, null) }, selected = false,
                        onClick = { scope.launch { drawerState.close() }; onDisconnect() },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding), colors = colors
                    )
                }
            }
        }
    ) {
        Column(Modifier.fillMaxSize()) {
            // Top bar: hamburger (or back inside an album/artist), title, search.
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { if (group != null) group = null else scope.launch { drawerState.open() } }) {
                    Icon(if (group != null) Icons.Default.ArrowBack else Icons.Default.Menu, if (group != null) "Back" else "Open menu", tint = Color.White)
                }
                if (searching) {
                    OutlinedTextField(
                        query, onQuery,
                        modifier = Modifier.weight(1f).focusRequester(searchFocus),
                        placeholder = { Text("Search your library", color = Color(0xFFB9C7D9)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF52617A), cursorColor = Blue
                        )
                    )
                    IconButton(onClick = { onQuery(""); searching = false }) { Icon(Icons.Default.Close, "Close search", tint = Color.White) }
                } else {
                    Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                        Text(group?.name ?: section, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (showGroups) "${groups.size} ${section.lowercase()}" else "${visible.size} items", color = Color(0xFFB9C7D9), fontSize = 12.sp)
                    }
                    IconButton(onClick = { searching = true }) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                    IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Refresh", tint = Color.White) }
                }
            }

            // Tile grid: as many columns as fit (2 on most phones, more on tablets / landscape).
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (section == "Home" && group == null && query.isBlank() && featured != null) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                                .background(Brush.horizontalGradient(listOf(Color(0xFF183B62), Color(0xFF35225F))))
                                .clickable { onPlay(featured, visible) }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArt(featured, client, Modifier.size(96.dp))
                            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (selected != null) "NOW PLAYING" else "FEATURED", color = Blue, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Text(featured.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(featured.artist.ifBlank { "Sonicly library" }, color = Color(0xFFD6DEEA), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Icon(Icons.Default.PlayCircle, "Play", tint = Color.White, modifier = Modifier.size(44.dp))
                        }
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text("Recently available", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                if (visible.isEmpty() && !showGroups || showGroups && groups.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(if (section == "Videos") Icons.Default.Movie else Icons.Default.LibraryMusic, null, tint = Blue, modifier = Modifier.size(40.dp))
                            Text(if (section == "Videos") "No videos available" else "No music or media found", color = Color.White, fontWeight = FontWeight.Bold)
                            Text(libraryError.ifBlank { "Check your desktop library folders, then refresh." }, color = Color(0xFFCBD5E1), fontSize = 13.sp)
                            TextButton(onClick = onRefresh) { Text("Refresh library", color = Blue) }
                        }
                    }
                } else if (showGroups) {
                    gridItems(groups, key = { it.key }) { entry ->
                        MediaTile(
                            art = entry.value.firstOrNull { it.artworkPath.isNotBlank() } ?: entry.value.first(), client = client,
                            title = entry.key,
                            subtitle = (if (section == "Albums") entry.value.firstOrNull { it.albumArtist.isNotBlank() || it.artist.isNotBlank() }?.let { it.albumArtist.ifBlank { it.artist } }?.plus("  ·  ") ?: "" else "") +
                                "${entry.value.size} track${if (entry.value.size == 1) "" else "s"}",
                            selected = false, playingNow = false, isVideo = false,
                            onClick = { group = MobileGroup(section, entry.key) }
                        )
                    }
                } else {
                    gridItems(visible, key = { it.id }) { track ->
                        MediaTile(
                            art = track, client = client,
                            title = track.title,
                            subtitle = track.artist.ifBlank { track.album.ifBlank { if (track.mediaType == "video") "Video" else "Desktop library" } },
                            selected = selected?.id == track.id, playingNow = selected?.id == track.id && playing,
                            isVideo = track.mediaType == "video",
                            onClick = { onPlay(track, visible) }
                        )
                    }
                }
            }

            if (selected != null) MobilePlayerBar(selected, playing, player, client, onToggle, onPrev, onNext)
            else Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
private fun MediaTile(art: Track, client: SoniclyClient, title: String, subtitle: String, selected: Boolean, playingNow: Boolean, isVideo: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.clip(shape).background(if (selected) Panel2 else Panel)
            .border(if (selected) 2.dp else 1.dp, if (selected) Blue else Color(0xFF293A55), shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Box(Modifier.fillMaxWidth()) {
            AlbumArt(art, client, Modifier.fillMaxWidth().aspectRatio(1f))
            Box(
                Modifier.align(Alignment.BottomEnd).padding(6.dp).size(34.dp).clip(RoundedCornerShape(50)).background(Color(0xCC080B18)),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (playingNow) Icons.Default.GraphicEq else if (isVideo) Icons.Default.Movie else Icons.Default.PlayArrow, null, tint = Blue, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = Color(0xFFD1D9E6), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MobilePlayerBar(track: Track, playing: Boolean, player: Player, client: SoniclyClient, onToggle: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    var showLyrics by remember { mutableStateOf(false) }
    LaunchedEffect(playing, track.id) {
        while (true) {
            val snapshot = readPlayerSnapshot(player)
            progress = if (snapshot.durationMs > 0L)
                (snapshot.positionMs.toFloat() / snapshot.durationMs.toFloat()).coerceIn(0f, 1f)
            else 0f
            if (!playing || !snapshot.isPlaying) break
            delay(500)
        }
    }
    Column(Modifier.fillMaxWidth().background(Panel2).navigationBarsPadding()) {
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Blue, trackColor = Color(0xFF293A55))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(track, client, Modifier.size(48.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.artist.ifBlank { track.album.ifBlank { "Sonicly library" } }, color = Color(0xFFD0D9E7), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = { showLyrics = true }, enabled = track.mediaType != "video") {
                Icon(Icons.Default.MusicNote, "Lyrics", tint = if (track.mediaType == "video") Color.Gray else Blue)
            }
            IconButton(onClick = onPrev) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
            IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(32.dp)) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
        }
    }
    if (showLyrics && track.mediaType != "video") {
        PhoneLyricsDialog(track = track, player = player, onDismiss = { showLyrics = false })
    }
}

@Composable internal fun AlbumArt(track: Track?, client: SoniclyClient?, modifier: Modifier, corner: Dp = 12.dp) {
    val url = if (track != null && client != null) client.artworkUrl(track) else null
    val context = LocalContext.current
    // The desktop's /api/v1/artwork endpoint is token-protected, so the request must carry the pairing token.
    val request = remember(url, client) {
        url?.let { u ->
            ImageRequest.Builder(context).data(u).apply { client?.authHeaders()?.forEach { (k, v) -> addHeader(k, v) } }.crossfade(true).build()
        }
    }
    Box(modifier.clip(RoundedCornerShape(corner)).background(Brush.linearGradient(listOf(Color(0xFF244B76), Color(0xFF543477)))), contentAlignment = Alignment.Center) {
        // Placeholder stays underneath, so a missing/failed image still looks intentional.
        Icon(if (track?.mediaType == "video") Icons.Default.Movie else Icons.Default.Album, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.fillMaxSize(0.42f))
        if (request != null) AsyncImage(model = request, contentDescription = "Artwork for ${track?.title}", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    }
}
