package com.sonicly.player

import android.os.Handler
import android.os.Looper
import androidx.media3.common.Player
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Reads Media3 state on the player's application looper. ExoPlayer is created by the
 * Activity on the main thread today, but this helper keeps the contract explicit and
 * prevents future IO-dispatcher callers from touching Player off-thread.
 */
internal suspend fun <T> onPlayerApplicationThread(
    player: Player,
    action: () -> T
): T = suspendCancellableCoroutine { continuation ->
    val handler = Handler(player.applicationLooper)
    val task = Runnable {
        if (continuation.isActive) {
            try {
                continuation.resume(action())
            } catch (error: Throwable) {
                continuation.resumeWithException(error)
            }
        }
    }
    if (Looper.myLooper() == player.applicationLooper) task.run()
    else handler.post(task)
    continuation.invokeOnCancellation { handler.removeCallbacks(task) }
}

internal data class SoniclyPlayerSnapshot(
    val positionMs: Long,
    val durationMs: Long,
    val isPlaying: Boolean,
    val playbackState: Int,
    val mediaId: String?
)

internal suspend fun readPlayerSnapshot(player: Player): SoniclyPlayerSnapshot =
    onPlayerApplicationThread(player) {
        SoniclyPlayerSnapshot(
            positionMs = player.currentPosition.coerceAtLeast(0L),
            durationMs = player.duration.takeIf { it != androidx.media3.common.C.TIME_UNSET }?.coerceAtLeast(0L) ?: 0L,
            isPlaying = player.isPlaying,
            playbackState = player.playbackState,
            mediaId = player.currentMediaItem?.mediaId
        )
    }


/**
 * Wait briefly for the currently prepared item to publish its duration. This is used
 * once when starting a lyrics lookup, not as a continuous player polling loop.
 */
internal suspend fun awaitPlayerDuration(
    player: Player,
    expectedMediaId: String? = null,
    timeoutMs: Long = 6_000L
): Long {
    val duration = withTimeoutOrNull(timeoutMs) {
        suspendCancellableCoroutine { continuation ->
            val handler = Handler(player.applicationLooper)
            lateinit var listener: Player.Listener

            fun finishIfReady(): Boolean {
                val currentDuration = player.duration
                val mediaMatches = expectedMediaId == null || player.currentMediaItem?.mediaId == expectedMediaId
                if (mediaMatches && currentDuration > 0L && currentDuration != androidx.media3.common.C.TIME_UNSET &&
                    (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_ENDED)
                ) {
                    player.removeListener(listener)
                    if (continuation.isActive) continuation.resume(currentDuration)
                    return true
                }
                return false
            }

            listener = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) {
                    finishIfReady()
                }

                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    player.removeListener(this)
                    if (continuation.isActive) continuation.resume(0L)
                }
            }

            handler.post {
                if (!continuation.isActive) return@post
                if (!finishIfReady()) {
                    player.addListener(listener)
                    finishIfReady()
                }
            }
            continuation.invokeOnCancellation {
                handler.post { player.removeListener(listener) }
            }
        }
    }
    return duration ?: if (expectedMediaId == null) {
        readPlayerSnapshot(player).durationMs
    } else {
        // A timeout for a newly selected video must never reuse the previous media item's duration.
        0L
    }
}

/**
 * Emits only on actual Media3 playback/seek/state events. Lyrics timing code can sleep
 * until the next LRC boundary and wake immediately for pause, resume, or seek events,
 * instead of continuously polling Player.
 */
@Composable
internal fun rememberPlayerEventChannel(player: Player): ReceiveChannel<Unit> {
    val channel = remember(player) { Channel<Unit>(capacity = Channel.CONFLATED) }
    DisposableEffect(player, channel) {
        val handler = Handler(player.applicationLooper)
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                channel.trySend(Unit)
            }
        }
        handler.post {
            player.addListener(listener)
            channel.trySend(Unit)
        }
        onDispose {
            handler.post { player.removeListener(listener) }
            channel.close()
        }
    }
    return channel
}

/** Wait until an actual player event, or the next lyric line boundary, whichever comes first. */
internal suspend fun awaitPlayerEventOrDelay(
    events: ReceiveChannel<Unit>,
    timeoutMs: Long
): Boolean {
    if (timeoutMs == Long.MAX_VALUE) {
        return !events.receiveCatching().isClosed
    }
    return withTimeoutOrNull(timeoutMs.coerceAtLeast(1L)) {
        !events.receiveCatching().isClosed
    } ?: true
}
