package com.sonicly.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private val LyricsDialogBackground = Color(0xFF11182A)
private val LyricsTextMuted = Color(0xFFB9C7D9)
private val LyricsAccent = Color(0xFF39B9F5)

/** Lyrics UI is deliberately phone-only; TvUi.kt does not call this component. */
@Composable
internal fun PhoneLyricsDialog(
    track: Track,
    player: Player,
    onDismiss: () -> Unit
) {
    val listState = rememberLazyListState()
    var lyrics by remember(track.id) { mutableStateOf<SoniclyLyrics?>(null) }
    var loading by remember(track.id) { mutableStateOf(true) }
    var status by remember(track.id) { mutableStateOf("Looking up lyrics…") }
    var searchTitle by remember(track.id) { mutableStateOf(track.title) }
    var requestVersion by remember(track.id) { mutableIntStateOf(0) }
    var currentPositionMs by remember(track.id) { mutableLongStateOf(0L) }
    val playerEvents = rememberPlayerEventChannel(player)

    LaunchedEffect(track.id, requestVersion) {
        val query = searchTitle.trim()
        if (query.isBlank()) {
            lyrics = null
            loading = false
            status = "Enter a song title to search."
        } else {
            loading = true
            lyrics = null
            status = "Looking up lyrics…"
            try {
                val durationMs = awaitPlayerDuration(player)
                val found = withContext(Dispatchers.IO) {
                    LyricsRepository.lookup(query, track.artist, track.album, durationMs)
                }
                lyrics = found
                status = when {
                    found == null -> "No matching lyrics found. Try another title."
                    found.instrumental -> "This track is marked as instrumental."
                    found.syncedLyrics.isNotEmpty() -> "Synchronized lyrics"
                    !found.plainLyrics.isNullOrBlank() -> "Plain lyrics"
                    else -> "No lyrics found."
                }
                loading = false
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lyrics = null
                status = error.message ?: "The lyrics service is unavailable."
                loading = false
            }
        }
    }
    val currentLyrics = lyrics
    val timedLines = currentLyrics?.syncedLyrics.orEmpty()
    // Only observe playback while timed lyrics exist. Reads happen on Media3's
    // application looper, and Compose state is changed only when the active line moves.
    LaunchedEffect(track.id, timedLines) {
        if (timedLines.isEmpty()) return@LaunchedEffect
        var lastIndex = Int.MIN_VALUE
        while (isActive) {
            val snapshot = readPlayerSnapshot(player)
            val nextIndex = timedLines.indexOfLast { it.timestampMs <= snapshot.positionMs }
            if (nextIndex != lastIndex) {
                currentPositionMs = snapshot.positionMs
                lastIndex = nextIndex
            }
            val nextBoundary = timedLines.getOrNull(nextIndex + 1)?.timestampMs
            val waitMs = when {
                !snapshot.isPlaying -> Long.MAX_VALUE
                nextBoundary != null -> (nextBoundary - snapshot.positionMs).coerceAtLeast(25L)
                else -> 30_000L
            }
            if (!awaitPlayerEventOrDelay(playerEvents, waitMs)) return@LaunchedEffect
        }
    }
    val activeIndex = timedLines.indexOfLast { it.timestampMs <= currentPositionMs }

    LaunchedEffect(activeIndex, timedLines.size) {
        if (activeIndex >= 0 && timedLines.isNotEmpty()) {
            listState.animateScrollToItem(activeIndex)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = LyricsDialogBackground,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = LyricsAccent)
                    Spacer(Modifier.size(8.dp))
                    Text("Lyrics", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Text(
                    "${track.title} · ${track.artist.ifBlank { "Unknown artist" }}",
                    color = LyricsTextMuted,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = searchTitle,
                        onValueChange = { searchTitle = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Search song title") },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (!loading) requestVersion += 1 })
                    )
                    IconButton(
                        onClick = { requestVersion += 1 },
                        enabled = !loading && searchTitle.isNotBlank()
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search lyrics", tint = LyricsAccent)
                    }
                }
                when {
                    loading -> Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = LyricsAccent)
                    }
                    timedLines.isNotEmpty() -> LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        itemsIndexed(timedLines) { index, line ->
                            Text(
                                text = line.text.ifBlank { "♪" },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                                color = when {
                                    index == activeIndex -> LyricsAccent
                                    index < activeIndex -> LyricsTextMuted.copy(alpha = 0.55f)
                                    else -> Color.White.copy(alpha = 0.85f)
                                },
                                fontSize = if (index == activeIndex) 19.sp else 16.sp,
                                fontWeight = if (index == activeIndex) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                    !currentLyrics?.plainLyrics.isNullOrBlank() -> LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp)
                    ) {
                        item {
                            Text(
                                text = currentLyrics?.plainLyrics.orEmpty(),
                                color = Color.White,
                                fontSize = 15.sp,
                                lineHeight = 25.sp
                            )
                        }
                    }
                    else -> Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                        Text(status, color = LyricsTextMuted)
                    }
                }
                Text("Lyrics provided by LRCLIB", color = LyricsTextMuted.copy(alpha = 0.7f), fontSize = 10.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = LyricsAccent) }
        }
    )
}
