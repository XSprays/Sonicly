package com.sonicly.player

import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * One ExoPlayer shared by the UI and the background service, so playback keeps going
 * (with a notification + lock-screen controls) when the app is minimised or the screen is off.
 */
object PlayerHolder {
    @Volatile private var player: ExoPlayer? = null

    /** True while the full-screen video dialog is the active media; video pauses when the app is hidden. */
    @Volatile var video: Boolean = false

    fun get(context: Context): ExoPlayer = player ?: synchronized(this) {
        // Use Media3's stock renderers and audio sink. The TV visualizer must never
        // be able to interrupt the shared playback pipeline.
        player ?: ExoPlayer.Builder(context.applicationContext)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)          // pause when headphones unplug
            .setWakeMode(C.WAKE_MODE_NETWORK)           // keep CPU + Wi-Fi awake while streaming
            .build()
            .also { player = it }
    }

    fun release() {
        player?.release()
        player = null
        video = false
    }
}

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        session = MediaSession.Builder(this, PlayerHolder.get(this)).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    // Swiping the app away: keep going if music is playing, otherwise shut down.
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        PlayerHolder.release()
        super.onDestroy()
    }
}
