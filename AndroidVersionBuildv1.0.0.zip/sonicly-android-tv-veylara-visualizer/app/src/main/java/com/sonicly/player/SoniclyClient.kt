package com.sonicly.player

import okhttp3.OkHttpClient
import android.util.Base64
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** A desktop Sonicly found on the local network. [name] may be blank if the desktop doesn't report one. */
data class DiscoveredHost(val address: String, val hostId: String, val name: String)

internal fun isLocalUri(path: String) = path.startsWith("content://") || path.startsWith("file://")

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val mime: String,
    val streamPath: String,
    val artworkPath: String,
    val mediaType: String,
    val albumArtist: String = "",
    val trackNumber: Int = 0,
    val discNumber: Int = 0
)

class SoniclyClient(baseUrl: String, private val token: String = "") {
    private val base = baseUrl.trim().trimEnd('/')
    private val http = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private fun get(path: String): String {
        val request = Request.Builder()
            .url(base + path)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException(
                when (response.code) {
                    401 -> "Pairing token was rejected. Check the token in desktop Sonicly."
                    404 -> "Desktop endpoint not found. Update Sonicly on your PC."
                    else -> "Desktop returned HTTP ${response.code}."
                }
            )
            return response.body?.string() ?: "{}"
        }
    }

    fun post(path: String, payload: JSONObject, authenticated: Boolean = false): JSONObject {
        val builder = Request.Builder().url(base + path).post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Accept", "application/json")
        if (authenticated && token.isNotBlank()) builder.header("Authorization", "Bearer $token")
        http.newCall(builder.build()).execute().use { response ->
            val body = JSONObject(response.body?.string() ?: "{}")
            if (!response.isSuccessful) throw IllegalStateException(body.optString("error", "Desktop returned HTTP ${response.code}."))
            return body
        }
    }

    companion object {
        fun requestPair(baseUrl: String, deviceName: String): JSONObject =
            SoniclyClient(baseUrl).post("/api/v1/pair/request", JSONObject().put("deviceName", deviceName).put("platform", "android"))
        fun completePair(baseUrl: String, challengeId: String, code: String): JSONObject =
            SoniclyClient(baseUrl).post("/api/v1/pair/complete", JSONObject().put("challengeId", challengeId).put("code", code))
        fun findHost(hostId: String): String? {
            if (hostId.isBlank()) return null
            return discoverHosts().firstOrNull { it.hostId == hostId }?.address
        }

        /** Accepts "192.168.1.20", "192.168.1.20:47831" or a full http:// address. */
        fun normalizeAddress(input: String): String {
            var s = input.trim().trimEnd('/')
            if (s.isEmpty()) return ""
            if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
            if (!s.substringAfter("://").contains(':')) s += ":47831"
            return s
        }

        private fun hostLabel(json: JSONObject): String =
            listOf("hostName", "computerName", "hostname", "deviceName", "machineName")
                .map { json.optString(it) }.firstOrNull { it.isNotBlank() }.orEmpty()

        /** Asks one address whether a compatible Sonicly desktop lives there. Throws if unreachable. */
        fun probe(address: String): DiscoveredHost? {
            val request = Request.Builder().url("$address/api/v1/discover").get().build()
            return OkHttpClient.Builder().connectTimeout(2500, TimeUnit.MILLISECONDS).readTimeout(2500, TimeUnit.MILLISECONDS)
                .build().newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@use null
                    val json = JSONObject(response.body?.string() ?: "{}")
                    if (json.optString("name") != "Sonicly") null
                    else DiscoveredHost(address, json.optString("hostId"), hostLabel(json))
                }
        }

        fun discover(): List<String> = discoverHosts().map { it.address }

        /** Scans the current Wi-Fi /24 for Sonicly desktop discovery endpoints. */
        fun discoverHosts(): List<DiscoveredHost> {
            val found = Collections.synchronizedList(mutableListOf<DiscoveredHost>())
            val addresses = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            val subnet = addresses.asSequence().flatMap { it.interfaceAddresses.asSequence() }
                .mapNotNull { it.address as? InetAddress }
                .firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress && it.hostAddress?.startsWith("169.254.") != true }
                ?.hostAddress ?: return emptyList()
            val prefix = subnet.substringBeforeLast('.')
            val pool = java.util.concurrent.Executors.newFixedThreadPool(32)
            try {
                (1..254).forEach { last -> pool.submit {
                    val candidate = "http://$prefix.$last:47831"
                    try {
                        val request = Request.Builder().url("$candidate/api/v1/discover").get().build()
                        OkHttpClient.Builder().connectTimeout(350, TimeUnit.MILLISECONDS).readTimeout(350, TimeUnit.MILLISECONDS).build().newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val json = JSONObject(response.body?.string() ?: "{}")
                                if (json.optString("name") == "Sonicly") found.add(DiscoveredHost(candidate, json.optString("hostId"), hostLabel(json)))
                            }
                        }
                    } catch (_: Exception) { }
                } }
            } finally { pool.shutdown(); pool.awaitTermination(5, TimeUnit.SECONDS) }
            return found.toList().sortedBy { it.address }
        }

        /** A client for on-phone files: no server, so stream/artwork paths are used as-is. */
        fun local() = SoniclyClient("http://127.0.0.1")
    }

    fun checkConnection(): String {
        val json = JSONObject(get("/api/v1/status"))
        if (json.optString("name") != "Sonicly" || json.optInt("protocol") != 1) {
            throw IllegalStateException("This desktop server is not a compatible Sonicly host.")
        }
        return "Connected to Sonicly ${json.optString("version", "")}".trim()
    }

    fun library(): List<Track> {
        val root = JSONObject(get("/api/v1/library"))
        // Accept the current desktop schema and common aliases so a minor
        // server response variation cannot silently produce an empty screen.
        val array = root.optJSONArray("tracks")
            ?: root.optJSONArray("media")
            ?: root.optJSONArray("items")
            ?: root.optJSONObject("library")?.optJSONArray("tracks")
            ?: throw IllegalStateException(
                "The desktop connected, but its library response did not contain a tracks list. Rebuild the Sonicly desktop media-bridge update."
            )
        if (array.length() == 0) return emptyList()
        val parsed = buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val mime = item.optString("mime").ifBlank { item.optString("mimeType") }
                val fileName = item.optString("fileName").ifBlank { item.optString("name") }
                val title = item.optString("title").ifBlank {
                    fileName.substringAfterLast('/').substringBeforeLast('.').ifBlank { "Unknown media" }
                }
                val id = item.optString("id").ifBlank { item.optString("mediaId") }
                val rawPath = item.optString("streamPath").ifBlank {
                    item.optString("streamUrl").ifBlank {
                        item.optString("url").ifBlank { if (id.isNotBlank()) "/api/v1/stream/$id" else "" }
                    }
                }
                if (rawPath.isBlank()) continue
                val ext = (fileName.ifBlank { title }).substringAfterLast('.', "").lowercase()
                val isVideo = mime.startsWith("video/") ||
                    ext in setOf("mp4", "m4v", "webm", "mkv", "avi", "mov", "mpeg", "mpg", "ogv") ||
                    item.optString("mediaType").equals("video", true) ||
                    item.optString("type").equals("video", true)
                add(Track(
                    id = id.ifBlank { rawPath },
                    title = title,
                    artist = item.optString("artist"),
                    album = item.optString("album"),
                    mime = mime.ifBlank { if (isVideo) "video/mp4" else "audio/mpeg" },
                    streamPath = rawPath,
                    artworkPath = item.optString("artworkPath").ifBlank {
                        item.optString("artworkUrl").ifBlank { item.optString("coverArt") }
                    },
                    mediaType = if (isVideo) "video" else "audio",
                    albumArtist = item.optString("albumArtist"),
                    trackNumber = item.optInt("trackNumber", 0),
                    discNumber = item.optInt("discNumber", 0)
                ))
            }
        }
        if (parsed.isEmpty()) {
            throw IllegalStateException("The desktop returned ${array.length()} library entries, but none included a usable stream path. Refresh the desktop library and reconnect.")
        }
        return parsed
    }

    fun streamUrl(track: Track): String = if (isLocalUri(track.streamPath)) track.streamPath else base + track.streamPath
    fun artworkUrl(track: Track): String? = track.artworkPath.takeIf { it.isNotBlank() }?.let { if (it.startsWith("http") || isLocalUri(it)) it else base + if (it.startsWith("/")) it else "/$it" }

    /** Loads album artwork for the native visualizer without exposing the paired desktop token to the UI layer. */
    fun artworkDataUri(track: Track): String? {
        val url = artworkUrl(track) ?: return null
        if (isLocalUri(url)) return null
        return runCatching {
            val requestBuilder = Request.Builder().url(url).get()
            if (url.startsWith(base, ignoreCase = true)) requestBuilder.header("Authorization", "Bearer $token")
            val request = requestBuilder.build()
            http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val body = response.body ?: return@use null
                val declaredLength = response.header("Content-Length")?.toLongOrNull() ?: -1L
                if (declaredLength > 3L * 1024L * 1024L) return@use null
                val bytes = body.bytes()
                if (bytes.isEmpty() || bytes.size > 3 * 1024 * 1024) return@use null
                val mime = response.header("Content-Type")?.substringBefore(';')?.takeIf { it.startsWith("image/") } ?: "image/jpeg"
                "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        }.getOrNull()
    }

    fun authHeaders(): Map<String, String> = mapOf("Authorization" to "Bearer $token")
}
