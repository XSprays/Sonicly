package com.sonicly.player

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.media3.common.Player
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private val VizNavy = Color(0xFF030712)
private val VizBlue = Color(0xFF60A5FA)
private val VizIndigo = Color(0xFF818CF8)
private val VizPurple = Color(0xFFA78BFA)
private val VizCyan = Color(0xFF38BDF8)
private val VizWhite = Color(0xFFE0E7FF)

private data class VisualizerThemeChoice(val id: String, val label: String, val glyph: String)
private val visualizerThemeChoices = listOf(
    VisualizerThemeChoice("ring", "Ring", "◉"),
    VisualizerThemeChoice("blobs", "Blobs", "●"),
    VisualizerThemeChoice("solar", "Solar", "☼"),
    VisualizerThemeChoice("vinyl", "Vinyl", "◎"),
    VisualizerThemeChoice("ducks", "Ducks", "♧"),
    VisualizerThemeChoice("cat", "Cat", "♡")
)

private data class VeylaraMotion(
    val phase: Float,
    val flowLevel: Float,
    val flowBass: Float,
    val flowTreble: Float,
    val beatEnergy: Float,
    val crazy: Float
)

@Composable
internal fun SoniclyVisualizerScreen(
    track: Track?,
    player: Player,
    client: SoniclyClient,
    onPrevious: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("sonicly_visualizer", Context.MODE_PRIVATE) }
    var themeId by remember { mutableStateOf(prefs.getString("theme", "ring") ?: "ring") }
    var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sensitivity", 1f).coerceIn(.4f, 3f)) }
    var artMode by remember { mutableStateOf(prefs.getString("vinylArt", "full") ?: "full") }
    var volume by remember { mutableFloatStateOf((player.volume * 100f).coerceIn(0f, 100f)) }
    var phase by remember { mutableFloatStateOf(0f) }
    var flowLevel by remember { mutableFloatStateOf(.04f) }
    var flowBass by remember { mutableFloatStateOf(.05f) }
    var flowTreble by remember { mutableFloatStateOf(.03f) }

    val audioTrack = track?.takeIf { it.mediaType != "video" }
    val isPlaying = player.isPlaying && audioTrack != null

    // Original Veylara visualizer's "Connect" fallback: a musical pulse, bass envelope
    // and treble shimmer when direct output capture is unavailable. This is visual-only;
    // it does not capture the microphone or modify Sonicly's Media3 audio pipeline.
    LaunchedEffect(isPlaying, sensitivity) {
        var clock = 0f
        while (true) {
            val dt = .033f
            clock += dt
            phase = (phase + dt * (if (isPlaying) 1f else .28f)) % (2f * PI.toFloat())
            if (isPlaying) {
                val beat = .55f + .45f * sin(clock * 4.2f)
                val bassPulse = .4f + .6f * max(0f, sin(clock * 2.1f))
                val treblePulse = .3f + .5f * abs(sin(clock * 6.5f + 1.2f))
                val grid = if (sin(clock * (2f * PI.toFloat()) * 1.15f) > .85f) 1.15f else 1f
                val targetL = min(1.4f, (.35f + beat * .55f) * grid * sensitivity)
                val targetB = min(1.5f, (.3f + bassPulse * .7f) * grid * sensitivity)
                val targetT = min(1.3f, (.25f + treblePulse * .55f) * sensitivity)
                flowLevel += (targetL - flowLevel) * .12f
                flowBass += (targetB - flowBass) * .14f
                flowTreble += (targetT - flowTreble) * .10f
            } else {
                flowLevel += (.04f - flowLevel) * .02f
                flowBass += (.05f - flowBass) * .02f
                flowTreble += (.03f - flowTreble) * .02f
            }
            delay(33L)
        }
    }

    var veylaraLogo by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(Unit) {
        veylaraLogo = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open("veylara/veylara-logo.png").use {
                    BitmapFactory.decodeStream(it)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }

    var coverArt by remember(audioTrack?.id, audioTrack?.artworkPath) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(audioTrack?.id, audioTrack?.artworkPath, themeId) {
        val current = audioTrack
        coverArt = null
        if (current != null && themeId == "vinyl") {
            coverArt = withContext(Dispatchers.IO) {
                runCatching {
                    val url = client.artworkUrl(current)
                    if (!url.isNullOrBlank() && isLocalUri(url)) {
                        context.contentResolver.openInputStream(Uri.parse(url))?.use { stream ->
                            BitmapFactory.decodeStream(stream)?.asImageBitmap()
                        }
                    } else {
                        val dataUri = client.artworkDataUri(current) ?: return@runCatching null
                        val encoded = dataUri.substringAfter(',', "")
                        if (encoded.isBlank()) return@runCatching null
                        val bytes = Base64.decode(encoded, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                    }
                }.getOrNull()
            }
        }
    }

    Column(Modifier.fillMaxSize().background(VizNavy)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 42.dp, end = 42.dp, top = 16.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GraphicEq, null, tint = VizCyan, modifier = Modifier.size(27.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("SONICLY VISUALIZER", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                }
                Text(
                    if (audioTrack != null) "Playing ${audioTrack.title} · ${audioTrack.artist.ifBlank { "Unknown artist" }}"
                    else "Choose music to bring Veylara's visuals to life",
                    color = Color(0xFFAAB8D0), fontSize = 14.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 37.dp, top = 3.dp)
                )
            }
            Row(
                modifier = Modifier.clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF111C34))
                    .border(1.dp, Color(0xFF4964A5).copy(alpha = .5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("SENSITIVITY", color = Color(0xFF9CB5DF), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                VisualizerControlButton("−", false) {
                    sensitivity = (sensitivity - .1f).coerceAtLeast(.4f)
                    prefs.edit().putFloat("sensitivity", sensitivity).apply()
                }
                Text("${String.format("%.1f", sensitivity)}×", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                VisualizerControlButton("+", true) {
                    sensitivity = (sensitivity + .1f).coerceAtMost(3f)
                    prefs.edit().putFloat("sensitivity", sensitivity).apply()
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            visualizerThemeChoices.forEach { choice ->
                VisualizerThemeButton(
                    choice = choice,
                    selected = themeId == choice.id,
                    modifier = Modifier.weight(1f)
                ) {
                    themeId = choice.id
                    prefs.edit().putString("theme", choice.id).apply()
                }
            }
        }

        if (themeId == "vinyl") {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 42.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC101A30))
                    .border(1.dp, Color(0x334D84C8), RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.VolumeDown, null, tint = VizBlue, modifier = Modifier.size(19.dp))
                VisualizerControlButton("−", false) {
                    volume = (volume - 5f).coerceAtLeast(0f)
                    player.volume = volume / 100f
                }
                Text("${volume.toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                VisualizerControlButton("+", false) {
                    volume = (volume + 5f).coerceAtMost(100f)
                    player.volume = volume / 100f
                }
                Icon(Icons.Default.VolumeUp, null, tint = VizBlue, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(18.dp))
                VisualizerControlButton("PREVIOUS", false, onPrevious)
                VisualizerControlButton("PLAY / PAUSE", true, onToggle)
                VisualizerControlButton("NEXT", false, onNext)
                Spacer(Modifier.width(18.dp))
                Text("RECORD ART", color = Color(0xFFAAB8D0), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.width(8.dp))
                VisualizerControlButton("FULL DISC", artMode == "full") {
                    artMode = "full"
                    prefs.edit().putString("vinylArt", artMode).apply()
                }
                VisualizerControlButton("CENTER LABEL", artMode == "center") {
                    artMode = "center"
                    prefs.edit().putString("vinylArt", artMode).apply()
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 42.dp).padding(bottom = 16.dp)
                .clip(RoundedCornerShape(22.dp)).background(Color(0xFF030712))
                .border(1.dp, Color(0xFF263D68), RoundedCornerShape(22.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val beatEnergy = flowLevel * .5f + flowBass * .9f
                val crazyNow = ((beatEnergy - .2f) / .4f).coerceAtLeast(0f)
                drawVeylaraScene(
                    themeId = themeId,
                    phase = phase,
                    flowLevel = flowLevel,
                    flowBass = flowBass,
                    flowTreble = flowTreble,
                    beatEnergy = beatEnergy,
                    crazy = crazyNow,
                    playing = isPlaying,
                    logo = veylaraLogo,
                    cover = coverArt,
                    artMode = artMode
                )
            }

            if (audioTrack == null) {
                Column(
                    Modifier.align(Alignment.Center).clip(RoundedCornerShape(16.dp))
                        .background(Color(0xD90C1425)).border(1.dp, Color(0x555C8DDC), RoundedCornerShape(16.dp))
                        .padding(horizontal = 28.dp, vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.MusicNote, null, tint = VizPurple, modifier = Modifier.size(32.dp))
                    Text("Choose a song", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("The Veylara scene will animate with Sonicly playback.", color = Color(0xFFB7C3D8), fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun VisualizerThemeButton(
    choice: VisualizerThemeChoice,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier = modifier.height(52.dp).onFocusChanged { focused = it.isFocused }
            .graphicsLayer { scaleX = if (focused) 1.045f else 1f; scaleY = if (focused) 1.045f else 1f }
            .clip(RoundedCornerShape(15.dp))
            .background(
                when {
                    focused -> Brush.horizontalGradient(listOf(Color(0xFF236FAE), Color(0xFF7145B6)))
                    selected -> Brush.horizontalGradient(listOf(Color(0xFF174D78), Color(0xFF40296D)))
                    else -> Brush.horizontalGradient(listOf(Color(0xFF111C31), Color(0xFF19182D)))
                }
            )
            .border(
                width = if (focused) 3.dp else if (selected) 2.dp else 1.dp,
                color = if (focused) Color(0xFFB4E7FF) else if (selected) VizCyan else Color.White.copy(alpha = .15f),
                shape = RoundedCornerShape(15.dp)
            )
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(choice.glyph, color = if (selected || focused) Color.White else Color(0xFF8EA7D0), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(choice.label, color = Color.White, fontSize = 15.sp, fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium)
        }
    }
}

@Composable
private fun VisualizerControlButton(label: String, active: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.height(36.dp).clip(RoundedCornerShape(10.dp))
            .background(
                when {
                    focused -> Brush.horizontalGradient(listOf(Color(0xFF2778BC), Color(0xFF7048B7)))
                    active -> Brush.horizontalGradient(listOf(Color(0xFF245B91), Color(0xFF563A8D)))
                    else -> Brush.horizontalGradient(listOf(Color(0xFF1A2842), Color(0xFF211D3A)))
                }
            )
            .border(if (focused) 2.dp else 1.dp, if (focused) Color.White else Color(0x446B9BCF), RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

private fun DrawScope.drawVeylaraScene(
    themeId: String,
    phase: Float,
    flowLevel: Float,
    flowBass: Float,
    flowTreble: Float,
    beatEnergy: Float,
    crazy: Float,
    playing: Boolean,
    logo: ImageBitmap?,
    cover: ImageBitmap?,
    artMode: String
) {
    drawRect(VizNavy)
    val w = size.width
    val h = size.height
    val e = beatEnergy.coerceIn(0f, 1.5f)
    when (themeId) {
        "ring" -> drawVeylaraRing(w, h, phase, flowLevel, flowBass, e, crazy, logo)
        "blobs" -> drawVeylaraBlobs(w, h, phase, flowLevel, flowBass, flowTreble, e)
        "solar" -> drawVeylaraSolar(w, h, phase, flowLevel, flowBass, flowTreble, e, crazy)
        "ducks" -> drawVeylaraDucks(w, h, phase, flowLevel, flowBass, flowTreble, e, crazy)
        "cat" -> drawVeylaraCat(w, h, phase, flowLevel, flowBass, flowTreble, e)
        "vinyl" -> drawVeylaraVinyl(w, h, phase, flowLevel, flowBass, e, crazy, playing, cover, artMode)
        else -> drawVeylaraRing(w, h, phase, flowLevel, flowBass, e, crazy, logo)
    }
}

private fun DrawScope.drawVeylaraRing(
    w: Float, h: Float, t: Float, level: Float, bass: Float, energy: Float, crazy: Float, logo: ImageBitmap?
) {
    val cx = w * .5f; val cy = h * .46f; val base = min(w, h)
    val rx = base * (.26f + level * .05f + energy * .03f)
    val ry = rx * .70f
    drawCircle(Brush.radialGradient(listOf(Color(0x664C1D95), Color(0x333B82F6), Color.Transparent), Offset(cx, cy), rx * 1.9f), rx * 1.9f, Offset(cx, cy))
    val midY = h * .78f
    val amp = h * (.055f + level * .14f + bass * .08f)
    val floor = Path().apply {
        moveTo(0f, h)
        for (i in 0..100) {
            val x = w * i / 100f
            val nx = x / w
            val y = midY - (sin(nx * PI.toFloat() * 2f * 1.2f - t * .9f) + sin(nx * PI.toFloat() * 2f * .55f - t * .45f) * .5f) * amp
            lineTo(x, y)
        }
        lineTo(w, h); close()
    }
    drawPath(floor, Brush.verticalGradient(listOf(Color(0xBFA78BFA), Color(0x777C83F5), Color(0x663B5EB7)), midY - 50f, h))
    val ring = blobPath(cx, cy, rx, ry, t * 1.4f, energy, 0f)
    drawPath(ring, Color(0x66818CF8), style = Stroke(width = 31f + level * 15f, cap = StrokeCap.Round))
    drawPath(ring, Brush.linearGradient(listOf(Color(0xFFF0F9FF), Color(0xFF93C5FD), Color(0xFFA78BFA), Color(0xFFC084FC)), Offset(cx-rx,cy-ry), Offset(cx+rx,cy+ry)), style = Stroke(width = max(14f, 17f+level*17f+bass*16f+energy*7f), cap = StrokeCap.Round))
    drawPath(ring, Color(0x99F5F3FF), style = Stroke(width = max(2f, rx*.045f), cap = StrokeCap.Round))
    val ripple = blobPath(cx, cy, rx * 1.2f, ry * 1.2f, t * .7f, energy * .5f, 2f)
    drawPath(ripple, Color(0x558E9CFB), style = Stroke(width = 2.5f))
    val cloudX = cx + cos(-PI.toFloat()*.65f + sin(t*.4f)*.1f) * rx * .78f
    val cloudY = cy + sin(-PI.toFloat()*.65f + sin(t*.4f)*.1f) * ry * .72f
    val cloudR = base * (.1f + level*.04f + bass*.035f) * (1f + .04f*sin(t*2f))
    drawCircle(Brush.radialGradient(listOf(Color(0x99C4B5FD), Color(0x667C3AED), Color.Transparent), Offset(cloudX,cloudY), cloudR*2f), cloudR*2f, Offset(cloudX,cloudY))
    val cloud = blobPath(cloudX,cloudY,cloudR,cloudR*.86f,t*1.2f,energy,1f)
    drawPath(cloud,Brush.linearGradient(listOf(Color(0xFFEDE9FE),Color(0xFFC4B5FD),Color(0xFF818CF8),Color(0xFF6366F1)),Offset(cloudX-cloudR,cloudY-cloudR),Offset(cloudX+cloudR,cloudY+cloudR)))
    logo?.let {
        val side = (min(rx,ry)*.4f).toInt().coerceAtLeast(1)
        drawImage(it, IntOffset((cx-side/2).toInt(),(cy-side/2).toInt()), IntSize(side,side), alpha=.78f)
    } ?: drawEqBars(cx,cy,base*.10f,Color.White)
    if (energy > .3f) {
        for (i in 0..2) {
            val p = ((t*1.25f + i*.4f) % 1.2f) / 1.2f
            val rr = base*(.08f + p*.24f)
            drawCircle(Color(0x558EA2FF).copy(alpha=(1f-p)*.7f), rr, Offset(cx,cy), style=Stroke(width=2f+energy*2f))
        }
    }
}

private fun DrawScope.drawVeylaraBlobs(w: Float,h: Float,t: Float,level: Float,bass: Float,treble: Float,energy: Float) {
    val base=min(w,h); val cx=w*.5f; val cy=h*.42f
    val leftX=w*.22f+sin(t*.4f)*base*.012f; val leftY=cy+cos(t*.35f)*base*.018f
    val rightX=w*.78f+sin(t*.38f+1f)*base*.012f; val rightY=cy+cos(t*.42f+.5f)*base*.016f
    val midX=cx+sin(t*.25f)*base*.008f; val midY=cy+cos(t*.3f)*base*.01f
    val pulse=.92f+.08f*(.5f+.5f*sin(t*1.8f))+bass*.14f+level*.06f
    val lR=base*(.11f+level*.025f+bass*.02f)*pulse
    val rR=base*(.105f+level*.022f+treble*.02f)*pulse
    val mR=base*(.20f+level*.04f+bass*.035f)*pulse
    fun paintBlob(x:Float,y:Float,r:Float,seed:Float,alpha:Float) {
        drawCircle(Brush.radialGradient(listOf(Color(0x553B82F6),Color(0x223B82F6),Color.Transparent),Offset(x,y),r*2.5f),r*2.5f,Offset(x,y))
        val p=blobPath(x,y,r, r*.92f, t*.65f,energy,seed)
        drawPath(p,Brush.radialGradient(listOf(Color(0x99C4B5FD),Color(0x66818CF8),Color.Transparent),Offset(x-r*.18f,y-r*.2f),r*1.55f),alpha=alpha)
        drawPath(p,Brush.linearGradient(listOf(Color(0xFFE9D5FF),Color(0xFF93C5FD),Color(0xFF818CF8),Color(0xFF4F46E5)),Offset(x-r,y-r),Offset(x+r,y+r)),alpha=alpha)
        drawPath(p,Color(0x66E0E7FF),style=Stroke(width=1.5f),alpha=alpha)
    }
    paintBlob(leftX,leftY,lR,.3f,.92f)
    paintBlob(rightX,rightY,rR,1.1f,.92f)
    paintBlob(midX,midY,mR,.7f,1f)
    drawEqBars(midX,midY,mR*.55f,Color(0xFFE0E7FF))
    if (energy>.35f) for(i in 0 until 12) {
        val a=i*2f*PI.toFloat()/12f+t*.8f
        val r=mR*(1.15f+.25f*sin(t*2f+i))
        val p=Offset(midX+cos(a)*r,midY+sin(a)*r*.9f)
        drawCircle(Color(0x88C7D2FE),2.5f+energy*2f,p)
    }
}

private fun DrawScope.drawVeylaraSolar(w:Float,h:Float,t:Float,level:Float,bass:Float,treble:Float,energy:Float,crazy:Float) {
    val cx=w*.5f; val cy=h*.46f; val scale=min(w,h)
    val planetR=scale*(.16f+bass*.035f+level*.025f)*( .93f + .09f*(.5f+.5f*sin(t*2f)))
    drawCircle(Brush.radialGradient(listOf(Color(0x664C1D95),Color(0x223B82F6),Color.Transparent),Offset(cx,cy),scale*.65f),scale*.65f,Offset(cx,cy))
    for(c in 3 downTo 1) {
        val ar=planetR*(1.25f+c*.45f+energy*.12f)
        val p=blobPath(cx,cy,ar,ar*.93f,t*.25f,energy,.15f*c)
        drawPath(p,Brush.radialGradient(listOf(Color(0x337C3AED),Color(0x226366F1),Color.Transparent),Offset(cx,cy),ar*1.15f))
    }
    val planet=blobPath(cx,cy,planetR,planetR*.93f,t*.5f,energy,.4f)
    drawPath(planet,Brush.linearGradient(listOf(Color(0xFFEDE9FE),Color(0xFFC4B5FD),Color(0xFF818CF8),Color(0xFF4F46E5)),Offset(cx-planetR,cy-planetR),Offset(cx+planetR,cy+planetR)))
    drawPath(planet,Color(0x66E0E7FF),style=Stroke(width=2f))
    drawPath(blobPath(cx-planetR*.45f,cy+planetR*.25f,planetR*.38f,planetR*.34f,t+1.2f,energy,1.1f),Color(0x7793C5FD))
    drawPath(blobPath(cx+planetR*.4f,cy-planetR*.2f,planetR*.32f,planetR*.30f,t+2f,energy,2f),Color(0x66A78BFA))
    val orbitR=planetR*(2.15f+level*.15f)
    val orbit=ellipsePath(cx,cy,orbitR,orbitR*.55f,.15f)
    drawPath(orbit,Color(0x448DBBF7),style=Stroke(width=1.5f))
    val orbitAngle=t*(1.4f+level*4.5f+bass*3.5f+treble*2f+crazy*2.5f)
    val ox=cx+cos(orbitAngle)*orbitR; val oy=cy+sin(orbitAngle)*orbitR*.55f
    val trail=Path()
    for(i in 0..18) {
        val a=orbitAngle-i*(.12f+.018f*energy)
        val x=cx+cos(a)*orbitR; val y=cy+sin(a)*orbitR*.55f
        if(i==0)trail.moveTo(x,y) else trail.lineTo(x,y)
    }
    drawPath(trail,Color(0x887C6CEB),style=Stroke(width=3f))
    val orbR=scale*(.035f+treble*.015f+level*.01f)
    drawCircle(Brush.radialGradient(listOf(Color(0x88C4B5FD),Color(0x447C3AED),Color.Transparent),Offset(ox,oy),orbR*2.8f),orbR*2.8f,Offset(ox,oy))
    val orb=blobPath(ox,oy,orbR,orbR*.9f,t*1.4f+orbitAngle,energy,3.5f)
    drawPath(orb,Brush.linearGradient(listOf(Color(0xFFE0E7FF),Color(0xFF93C5FD),Color(0xFF6366F1)),Offset(ox-orbR,oy-orbR),Offset(ox+orbR,oy+orbR)))
    if(energy>.5f) {
        val p=(t*1.7f%1.25f)/1.25f
        if(p<1f) drawPath(blobPath(cx,cy,planetR*(1.4f+p*3.5f),planetR*(1.3f+p*3.1f),t+p,energy,8f),Color(0x447C3AED).copy(alpha=(1f-p)*.8f),style=Stroke(width=2f+energy*2f))
    }
}

private fun DrawScope.drawVeylaraDucks(w:Float,h:Float,t:Float,level:Float,bass:Float,treble:Float,energy:Float,crazy:Float) {
    val midY=h*.58f
    val amp=h*(.06f+level*.1f+bass*.06f)
    fun surface(nx:Float):Float = midY-(sin(nx*2f*PI.toFloat()*1.4f-t*.9f)+sin(nx*2f*PI.toFloat()*.7f-t*.55f)*.55f+sin(nx*2f*PI.toFloat()*2.3f+t*.35f)*.25f)*amp
    val water=Path().apply {
        moveTo(0f,h)
        for(i in 0..100){val x=w*i/100f;lineTo(x,surface(x/w))}
        lineTo(w,h);close()
    }
    drawRect(Brush.radialGradient(listOf(Color(0x334C1D95),Color(0x223B82F6),Color.Transparent),Offset(w*.5f,h*.3f),max(w,h)*.7f))
    drawPath(water,Brush.verticalGradient(listOf(Color(0x8893C5FD),Color(0x777C83F5),Color(0x77301B75)),midY-amp-20f,h))
    val wave=Path().apply { for(i in 0..100){val x=w*i/100f;val y=surface(x/w);if(i==0)moveTo(x,y)else lineTo(x,y)} }
    drawPath(wave,Color(0x99E0E7FF),style=Stroke(width=2f))
    if(energy>.25f) for(i in 0..100 step 4){val nx=i/100f;val local=abs(sin(nx*PI.toFloat()*4-t));if(local>.85f)drawCircle(Color(0x88FFFFFF),2f+energy*2f,Offset(nx*w,surface(nx)-2f))}
    val duckBase=min(w,h)*.055f
    for(i in 0 until 7) {
        val x=((i*.173f + t*(.025f+level*.012f))%1.18f-.08f)*w
        val nx=(x/w).coerceIn(-.1f,1.1f)
        val y=surface(nx)-duckBase*(.22f+sin(t*1.4f+i*1.7f)*.08f)
        val s=duckBase*(.78f+.16f*sin(i*3.1f))
        val facing=if(i%3==0)-1f else 1f
        drawDuck(x,y,s,facing,t+i)
    }
    // Reflections and small ripples make the water feel like the original scene.
    for(i in 0 until 18) {
        val x=((i*.071f+t*.012f)%1f)*w
        val y=midY+h*.12f+(i%4)*h*.035f
        val rw=10f+(i%5)*5f+energy*5f
        drawLine(Color(0x448DBCFB),Offset(x-rw,y),Offset(x+rw,y+sin(t*2f+i)*2f),2f)
    }
}

private fun DrawScope.drawDuck(x:Float,y:Float,s:Float,facing:Float,phase:Float) {
    scale(scaleX=facing,scaleY=1f,pivot=Offset(x,y)) {
        drawOval(Brush.linearGradient(listOf(Color(0xFFFFF3A6),Color(0xFFFFC928),Color(0xFFE89A12)),Offset(x-s,y-s*.4f),Offset(x+s,y+s*.4f)),topLeft=Offset(x-s*.55f,y-s*.38f),size=Size(s*1.1f,s*.76f))
        drawCircle(Brush.linearGradient(listOf(Color(0xFFFFF6BA),Color(0xFFFFD43B),Color(0xFFEFA91A)),Offset(x+s*.25f,y-s*.55f),Offset(x+s*.65f,y)),s*.29f,Offset(x+s*.42f,y-s*.28f))
        val beak=Path().apply{moveTo(x+s*.62f,y-s*.28f);lineTo(x+s*.95f,y-s*.22f);lineTo(x+s*.62f,y-s*.15f);close()}
        drawPath(beak,Color(0xFFFF8733))
        drawCircle(Color(0xFF1F2937),max(1.8f,s*.055f),Offset(x+s*.50f,y-s*.34f))
        drawOval(Color(0x66FFFFFF),topLeft=Offset(x-s*.27f,y-s*.05f),size=Size(s*.42f,s*.24f))
        drawOval(Color(0x223B2B05),topLeft=Offset(x-s*.45f,y+s*.18f),size=Size(s*.7f,s*.13f))
    }
}

private fun DrawScope.drawVeylaraCat(w:Float,h:Float,t:Float,level:Float,bass:Float,treble:Float,energy:Float) {
    val floorY=h*.88f
    drawRect(Brush.radialGradient(listOf(Color(0x554C1D95),Color(0x223B82F6),Color.Transparent),Offset(w*.5f,h*.3f),max(w,h)*.8f))
    val floor=Path().apply{moveTo(0f,h);lineTo(0f,floorY);for(i in 0..40){val nx=i/40f;lineTo(nx*w,floorY+sin(nx*2f*PI.toFloat()-t*.5f)*(6f+level*12f))};lineTo(w,h);close()}
    drawPath(floor,Brush.verticalGradient(listOf(Color(0x66A78BFA),Color(0x99301B75)),floorY-20f,h))
    val bounce=abs(sin(t*2.8f))
    val cx=w*(.5f+.13f*sin(t*.55f))
    val cy=h*(.64f-.06f*bounce)
    val s=min(w,h)*.43f*(1f+bass*.04f)
    val headR=s*.36f
    // Tail and body.
    val tail=Path().apply{moveTo(cx+s*.20f,cy+s*.24f);cubicTo(cx+s*.58f,cy+s*.30f,cx+s*.58f,cy-s*.05f,cx+s*.42f,cy-s*.10f)}
    drawPath(tail,Color(0xFFFF9F43),style=Stroke(width=s*.10f,cap=StrokeCap.Round))
    drawOval(Brush.linearGradient(listOf(Color(0xFFFFC36A),Color(0xFFFF8A2B),Color(0xFFB84B1D)),Offset(cx-s*.3f,cy),Offset(cx+s*.3f,cy+s*.55f)),Offset(cx-s*.29f,cy+s*.03f),Size(s*.58f,s*.43f))
    // Head with triangular ears.
    val hx=cx; val hy=cy-s*.18f
    val ears=Path().apply{
        moveTo(hx-headR*.78f,hy-headR*.15f);lineTo(hx-headR*.64f,hy-headR*1.18f);lineTo(hx-headR*.08f,hy-headR*.65f)
        lineTo(hx+headR*.18f,hy-headR*.62f);lineTo(hx+headR*.78f,hy-headR*1.05f);lineTo(hx+headR*.68f,hy-headR*.1f)
        cubicTo(hx+headR*.92f,hy+headR*.85f,hx-headR*.8f,hy+headR*.9f,hx-headR*.78f,hy-headR*.15f);close()
    }
    drawPath(ears,Brush.linearGradient(listOf(Color(0xFFFFBE68),Color(0xFFEA7626),Color(0xFFB94C1D)),Offset(hx-headR,hy-headR),Offset(hx+headR,hy+headR)))
    drawPath(ears,Color(0xFF211B24),style=Stroke(width=s*.035f))
    val innerL=Path().apply{moveTo(hx-headR*.62f,hy-headR*.28f);lineTo(hx-headR*.60f,hy-headR*.95f);lineTo(hx-headR*.23f,hy-headR*.43f);close()}
    val innerR=Path().apply{moveTo(hx+headR*.35f,hy-headR*.42f);lineTo(hx+headR*.68f,hy-headR*.89f);lineTo(hx+headR*.58f,hy-headR*.26f);close()}
    drawPath(innerL,Color(0xFFFFA0AA));drawPath(innerR,Color(0xFFFFA0AA))
    val head=Path().apply{moveTo(hx-headR*.78f,hy-headR*.15f);cubicTo(hx-headR*.92f,hy+headR*.75f,hx+headR*.9f,hy+headR*.78f,hx+headR*.68f,hy-headR*.12f);cubicTo(hx+headR*.42f,hy-headR*.58f,hx-headR*.35f,hy-headR*.60f,hx-headR*.78f,hy-headR*.15f);close()}
    drawPath(head,Brush.radialGradient(listOf(Color(0xFFFFC879),Color(0xFFFF983B),Color(0xFFB84B1D)),Offset(hx-headR*.25f,hy-headR*.25f),headR*1.5f))
    drawPath(head,Color(0xFF211B24),style=Stroke(width=s*.035f))
    drawOval(Color(0xFFFFE8CF),Offset(hx-headR*.42f,hy+headR*.12f),Size(headR*.84f,headR*.60f))
    // Eyes with glints.
    for(side in listOf(-1f,1f)){
        val ex=hx+side*headR*.30f;val ey=hy-headR*.05f
        drawOval(Color.White,Offset(ex-headR*.16f,ey-headR*.20f),Size(headR*.32f,headR*.40f))
        drawCircle(Color(0xFF201927),headR*.10f,Offset(ex+headR*.02f,ey))
        drawCircle(Color.White,headR*.035f,Offset(ex-headR*.015f,ey-headR*.07f))
    }
    val nose=Path().apply{moveTo(hx+headR*.05f,hy+headR*.22f);lineTo(hx-headR*.1f,hy+headR*.38f);lineTo(hx+headR*.2f,hy+headR*.38f);close()}
    drawPath(nose,Color(0xFFEF7D9B))
    drawLine(Color(0xFF271B24),Offset(hx+headR*.05f,hy+headR*.38f),Offset(hx+headR*.05f,hy+headR*.5f),s*.018f)
    drawLine(Color(0xFF271B24),Offset(hx+headR*.05f,hy+headR*.5f),Offset(hx-headR*.16f,hy+headR*.45f),s*.018f)
    drawLine(Color(0xFF271B24),Offset(hx+headR*.05f,hy+headR*.5f),Offset(hx+headR*.26f,hy+headR*.45f),s*.018f)
    for(i in -1..1){
        drawLine(Color(0xDDEFFFFF),Offset(hx-headR*.2f,hy+headR*.32f+i*headR*.14f),Offset(hx-headR*1.12f,hy+headR*.1f+i*headR*.25f),s*.014f)
        drawLine(Color(0xDDEFFFFF),Offset(hx+headR*.35f,hy+headR*.32f+i*headR*.14f),Offset(hx+headR*1.15f,hy+headR*.1f+i*headR*.25f),s*.014f)
    }
    // Feet and dancing music sparks.
    drawOval(Color(0xFFE57B2F),Offset(cx-s*.18f,cy+s*.37f),Size(s*.17f,s*.11f))
    drawOval(Color(0xFFE57B2F),Offset(cx+s*.02f,cy+s*.37f),Size(s*.17f,s*.11f))
    for(i in 0..4){
        val a=t*2.2f+i*1.2f
        val x=cx+cos(a)*s*1.05f
        val y=cy-s*.82f-sin(t*3f+i)*s*.22f
        drawCircle(Color(0x88FDBA74),3f+i%3,Offset(x,y))
    }
}

private fun DrawScope.drawVeylaraVinyl(
    w:Float,h:Float,t:Float,level:Float,bass:Float,energy:Float,crazy:Float,
    playing:Boolean,cover:ImageBitmap?,artMode:String
) {
    val cx=w*.42f;val cy=h*.47f;val scale=min(w,h);val discR=scale*.36f
    // Deep atmospheric glow.
    drawCircle(Brush.radialGradient(listOf(Color(0x664C1D95),Color(0x333B82F6),Color.Transparent),Offset(cx,cy),scale*.75f),scale*.75f,Offset(cx,cy))
    // Turntable plinth.
    val px=w*.09f;val py=h*.14f;val pw=w*.78f;val ph=h*.72f
    drawRoundRect(Brush.linearGradient(listOf(Color(0xFF29365D),Color(0xFF10182E),Color(0xFF080E1D)),Offset(px,py),Offset(px+pw,py+ph)),Offset(px,py),Size(pw,ph),cornerRadius=androidx.compose.ui.geometry.CornerRadius(24f))
    drawRoundRect(Color(0xFF8397D5).copy(alpha=.22f),Offset(px,py),Size(pw,ph),cornerRadius=androidx.compose.ui.geometry.CornerRadius(24f),style=Stroke(width=3f))
    val matR=discR*1.10f
    drawCircle(Color(0xFF201B4E),matR,Offset(cx,cy))
    drawCircle(Color(0x887C70E8),matR,Offset(cx,cy),style=Stroke(width=3f))
    // Subtle orbital particles around the platter.
    for(i in 0..3){
        val a=t*(.35f+i*.12f)+i*PI.toFloat()/2f
        val r=discR*(1.42f+i*.12f)
        drawCircle(Color(0x667DB7FF),3f+i%2,Offset(cx+cos(a)*r,cy+sin(a)*r*.62f))
    }
    // Record and grooves spin continuously like the original Veylara platter.
    val spin=t*(.55f+level*2f+bass*1.4f+crazy)
    rotate(spin * 42f, pivot=Offset(cx,cy)) {
    drawCircle(Brush.radialGradient(listOf(Color(0xFF38318B),Color(0xFF1E1B4B),Color(0xFF312E81),Color(0xFF0F172A)),Offset(cx,cy),discR),discR,Offset(cx,cy))
    for(i in 1..18){
        val r=discR*(.22f+i*.041f)
        drawCircle(if(i%2==0)Color(0x447E87D8)else Color(0x334B5597),r,Offset(cx,cy),style=Stroke(width=1f))
    }
    val recordCircle=Path().apply{addOval(androidx.compose.ui.geometry.Rect(cx-discR,cy-discR,cx+discR,cy+discR))}
    if(cover!=null){
        if(artMode=="center"){
            drawCircle(Color(0xFF141B30),discR*.43f,Offset(cx,cy))
            val label=Path().apply{addOval(androidx.compose.ui.geometry.Rect(cx-discR*.39f,cy-discR*.39f,cx+discR*.39f,cy+discR*.39f))}
            clipPath(label){drawImage(cover,IntOffset((cx-discR*.39f).toInt(),(cy-discR*.39f).toInt()),IntSize((discR*.78f).toInt().coerceAtLeast(1),(discR*.78f).toInt().coerceAtLeast(1)))}
            drawCircle(Color(0x88C4B5FD),discR*.39f,Offset(cx,cy),style=Stroke(width=2f))
        }else{
            clipPath(recordCircle){drawImage(cover,IntOffset((cx-discR).toInt(),(cy-discR).toInt()),IntSize((discR*2).toInt().coerceAtLeast(1),(discR*2).toInt().coerceAtLeast(1)))}
            for(i in 1..9)drawCircle(Color(0x226B68C0),discR*(.39f+i*.06f),Offset(cx,cy),style=Stroke(width=1f))
        }
    } else {
        drawCircle(Brush.sweepGradient(listOf(Color(0xFF26334D),Color(0xFF090D18),Color(0xFF303D5C),Color(0xFF090D18))),discR*.31f,Offset(cx,cy))
        drawEqBars(cx,cy,discR*.22f,Color(0xFFE0E7FF))
    }
    drawCircle(Color(0x88C4B5FD),discR,Offset(cx,cy),style=Stroke(width=2.5f))
    drawCircle(Color(0xFF0F172A),discR*.045f,Offset(cx,cy))
    }
    // Tonearm anchored on the top-right, like the original Veylara deck.
    val pivot=Offset(cx+discR*1.28f,cy-discR*.72f)
    drawCircle(Color(0xFFC4B5FD),scale*.022f,pivot)
    drawCircle(Color(0xFFE0E7FF),scale*.022f,pivot,style=Stroke(width=2f))
    val armAngle=.25f+sin(t*.7f)*.018f
    val armLen=discR*1.42f
    val end=Offset(pivot.x+cos(armAngle)*armLen,pivot.y+sin(armAngle)*armLen)
    drawLine(Color(0x99000000),Offset(pivot.x+2f,pivot.y+4f),Offset(end.x+2f,end.y+4f),7f,StrokeCap.Round)
    drawLine(Color(0xFFE0E7FF),pivot,end,5f,StrokeCap.Round)
    drawLine(Color(0xFFA78BFA),pivot,end,2f,StrokeCap.Round)
    drawCircle(Color(0xFF818CF8),9f,end)
    // Deck's softly lit floor shadow.
    drawOval(Color(0x337C83F5),Offset(cx-discR*1.3f,h*.79f),Size(discR*2.6f,discR*.36f))
    if(playing){
        val burst=(t*1.7f%1.3f)/1.3f
        drawCircle(Color(0x557C3AED).copy(alpha=(1f-burst)*.75f),discR*(1.2f+burst*2.4f),Offset(cx,cy),style=Stroke(width=2f+energy*2f))
    }
}

private fun DrawScope.blobPath(cx:Float,cy:Float,rx:Float,ry:Float,phase:Float,energy:Float,seed:Float):Path {
    val p=Path()
    val steps=64
    for(i in 0..steps){
        val a=i*2f*PI.toFloat()/steps
        val puff=.74f+.15f*sin(a*2.4f+phase+seed)+.11f*sin(a*3.9f-phase*1.15f+seed*.7f)+.08f*sin(a*5.2f+phase*.6f)+.06f*sin(a*7.1f-phase*1.7f)*(.4f+energy)
        val x=cx+cos(a)*rx*puff
        val y=cy+sin(a)*ry*puff
        if(i==0)p.moveTo(x,y)else p.lineTo(x,y)
    }
    p.close()
    return p
}

private fun DrawScope.ellipsePath(cx:Float,cy:Float,rx:Float,ry:Float,rotation:Float):Path {
    val p=Path()
    for(i in 0..100){
        val a=i*2f*PI.toFloat()/100f
        val x=cos(a)*rx;val y=sin(a)*ry
        val px=cx+x*cos(rotation)-y*sin(rotation)
        val py=cy+x*sin(rotation)+y*cos(rotation)
        if(i==0)p.moveTo(px,py)else p.lineTo(px,py)
    }
    p.close();return p
}

private fun DrawScope.drawEqBars(cx:Float,cy:Float,size:Float,color:Color) {
    val fractions=listOf(.36f,.68f,1f,.54f,.82f)
    val barW=size*.105f;val gap=size*.06f
    val total=barW*5f+gap*4f
    val x0=cx-total/2f
    fractions.forEachIndexed { i,f ->
        val bh=size*.52f*f
        drawRoundRect(color,Offset(x0+i*(barW+gap),cy-bh/2f),Size(barW,bh),cornerRadius=androidx.compose.ui.geometry.CornerRadius(barW*.35f))
    }
}
