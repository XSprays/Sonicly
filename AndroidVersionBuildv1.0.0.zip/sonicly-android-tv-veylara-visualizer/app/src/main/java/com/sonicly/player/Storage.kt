package com.sonicly.player

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject

/** A desktop Sonicly this device has been paired with. */
data class PairedComputer(
    val hostId: String,
    val name: String,
    val host: String,
    val token: String,
    val deviceId: String,
    val lastUsed: Long = 0L
)

/** Remembers every paired computer (not just one). Migrates the old single-pairing prefs on first use. */
class PairedStore(private val prefs: SharedPreferences) {
    fun load(): List<PairedComputer> {
        val raw = prefs.getString(KEY, null)
        if (raw == null) {
            val host = prefs.getString("host", "").orEmpty()
            val token = prefs.getString("token", "").orEmpty()
            if (host.isNotBlank() && token.isNotBlank()) {
                val legacy = PairedComputer(
                    hostId = prefs.getString("hostId", "").orEmpty(),
                    name = "Sonicly desktop",
                    host = host, token = token,
                    deviceId = prefs.getString("deviceId", "").orEmpty(),
                    lastUsed = 1L
                )
                save(listOf(legacy))
                return listOf(legacy)
            }
            return emptyList()
        }
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PairedComputer(o.optString("hostId"), o.optString("name"), o.optString("host"), o.optString("token"), o.optString("deviceId"), o.optLong("lastUsed"))
            }
        }.getOrDefault(emptyList())
    }

    fun save(list: List<PairedComputer>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("hostId", it.hostId).put("name", it.name).put("host", it.host)
                .put("token", it.token).put("deviceId", it.deviceId).put("lastUsed", it.lastUsed))
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun upsert(pc: PairedComputer) = save(load().filterNot { same(it, pc) } + pc)
    fun remove(pc: PairedComputer) = save(load().filterNot { same(it, pc) })

    private fun same(a: PairedComputer, b: PairedComputer) =
        if (a.hostId.isNotBlank() && b.hostId.isNotBlank()) a.hostId == b.hostId else a.host == b.host

    private companion object { const val KEY = "pairedComputers" }
}

/** A folder (tree) or single file on this phone the user added for local playback. */
data class LocalSource(val uri: String, val isFolder: Boolean, val name: String)

class LocalSources(private val context: Context, private val prefs: SharedPreferences) {
    fun list(): List<LocalSource> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                LocalSource(o.optString("uri"), o.optBoolean("folder"), o.optString("name"))
            }
        }.getOrDefault(emptyList())
    }

    fun folders(): List<Uri> = list().filter { it.isFolder }.map { Uri.parse(it.uri) }
    fun files(): List<Uri> = list().filterNot { it.isFolder }.map { Uri.parse(it.uri) }

    fun add(uri: Uri, isFolder: Boolean) {
        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        val current = list()
        if (current.any { it.uri == uri.toString() }) return
        save(current + LocalSource(uri.toString(), isFolder, queryName(uri, isFolder)))
    }

    fun remove(source: LocalSource) {
        runCatching { context.contentResolver.releasePersistableUriPermission(Uri.parse(source.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        save(list().filterNot { it.uri == source.uri })
    }

    private fun save(list: List<LocalSource>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("uri", it.uri).put("folder", it.isFolder).put("name", it.name)) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private fun queryName(uri: Uri, isFolder: Boolean): String {
        val target = if (isFolder) DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri)) else uri
        return runCatching {
            context.contentResolver.query(target, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull() ?: uri.lastPathSegment ?: "Local source"
    }

    private companion object { const val KEY = "localSources" }
}

/** Same as the stock pickers, but asks for a permission that survives app restarts. */
class PickFolder : ActivityResultContracts.OpenDocumentTree() {
    override fun createIntent(context: Context, input: Uri?): Intent =
        super.createIntent(context, input).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
}

class PickFiles : ActivityResultContracts.OpenMultipleDocuments() {
    override fun createIntent(context: Context, input: Array<String>): Intent =
        super.createIntent(context, input).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
}
