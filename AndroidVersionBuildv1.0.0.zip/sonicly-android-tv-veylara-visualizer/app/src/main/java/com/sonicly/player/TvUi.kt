package com.sonicly.player

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.media3.common.Player
import kotlinx.coroutines.delay

/* ------------------------------------------------------------------------------------------
 * Sonicly TV - Netflix-style browse experience.
 *   - Top navigation bar (Search / Home / Music / Videos / Albums / Artists / All Media)
 *   - Full-width hero billboard with Play / Shuffle
 *   - Horizontal rows of poster tiles (albums, artists, songs, videos)
 *   - Whatever is focused scales up and gets an animated blue -> purple gradient border
 * ------------------------------------------------------------------------------------------ */

private val TvBg = Color(0xFF07070D)
private val TvBlue = Color(0xFF39B9F5)
private val TvIndigo = Color(0xFF5F7BFF)
private val TvPurple = Color(0xFF9460F5)
private val TvMuted = Color(0xFFB4BCCB)
private val TvCard = Color(0xFF16161F)

private val GlowColors = intArrayOf(TvBlue.toArgb(), TvIndigo.toArgb(), TvPurple.toArgb(), TvIndigo.toArgb(), TvBlue.toArgb())
private val GlowStops = floatArrayOf(0f, .25f, .5f, .75f, 1f)

private val TvTabs = listOf("Search", "Home", "Music", "Videos", "Albums", "Artists", "All Media", "Visualizer")

private data class TvGroup(val kind: String, val name: String)

/* ---------------------------------- animated gradient border --------------------------------- */

private fun sweepBrush(angle: Float) = object : ShaderBrush() {
    override fun createShader(size: Size): android.graphics.Shader {
        val cx = size.width / 2f
        val cy = size.height / 2f
        return android.graphics.SweepGradient(cx, cy, GlowColors, GlowStops).also {
            it.setLocalMatrix(android.graphics.Matrix().apply { setRotate(angle, cx, cy) })
        }
    }
}

/**
 * When [focused], draws a rotating blue/purple gradient border (plus a soft glow) on top of the
 * content. The rotation only touches the draw phase, so it never triggers recomposition.
 */
private fun Modifier.glowBorder(focused: Boolean, corner: Dp, width: Dp = 4.dp, idleBorder: Boolean = true): Modifier = composed {
    if (!focused && !idleBorder) {
        Modifier
    } else if (!focused) {
        Modifier.drawWithContent {
            drawContent()
            val r = corner.toPx()
            drawRoundRect(Color(0x22FFFFFF), cornerRadius = CornerRadius(r), style = Stroke(1.dp.toPx()))
        }
    } else {
        val transition = rememberInfiniteTransition(label = "tvGlow")
        val angle by transition.animateFloat(
            initialValue = 0f, targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
            label = "tvGlowAngle"
        )
        Modifier.drawWithContent {
            drawContent()
            val w = width.toPx()
            val r = corner.toPx()
            val brush = sweepBrush(angle)
            // Soft outer glow: a few wide, faint strokes growing outwards.
            for (k in 3 downTo 1) {
                val grow = k * 3.dp.toPx()
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(-grow, -grow),
                    size = Size(size.width + grow * 2, size.height + grow * 2),
                    cornerRadius = CornerRadius(r + grow),
                    alpha = 0.20f / k,
                    style = Stroke(3.dp.toPx())
                )
            }
            // The crisp animated border, drawn just inside the tile edge.
            drawRoundRect(
                brush = brush,
                topLeft = Offset(w / 2, w / 2),
                size = Size(size.width - w, size.height - w),
                cornerRadius = CornerRadius((r - w / 2).coerceAtLeast(0f)),
                style = Stroke(w)
            )
        }
    }
}

/** Every focusable thing on the TV screen: scales up and shows the animated gradient border. */
@Composable
private fun TvFocusable(
    modifier: Modifier = Modifier,
    corner: Dp = 14.dp,
    focusScale: Float = 1.08f,
    idleBorder: Boolean = true,
    focusRequester: FocusRequester? = null,
    onFocus: () -> Unit = {},
    onClick: () -> Unit,
    content: @Composable BoxScope.(focused: Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusScale else 1f, tween(170), label = "tvScale")
    val source = remember { MutableInteractionSource() }
    Box(
        modifier
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { focused = it.hasFocus; if (it.hasFocus) onFocus() }
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .glowBorder(focused, corner, idleBorder = idleBorder)
            .clip(RoundedCornerShape(corner))
    ) { content(focused) }
}

private suspend fun FocusRequester.requestWhenReady() {
    repeat(14) {
        if (runCatching { requestFocus() }.isSuccess) return
        delay(60)
    }
}

/* ------------------------------------------------ building blocks --------------------------------------- */

@Composable
private fun TvButton(label: String, icon: ImageVector, primary: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, focusRequester: FocusRequester? = null) {
    TvFocusable(modifier.height(52.dp), corner = 10.dp, focusScale = 1.07f, focusRequester = focusRequester, onClick = onClick) { _ ->
        Row(
            Modifier.fillMaxHeight().background(if (primary) Color.White else Color(0xDD2B2B3A)).padding(horizontal = 26.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, null, tint = if (primary) Color.Black else Color.White, modifier = Modifier.size(28.dp))
            Text(label, color = if (primary) Color.Black else Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TvRoundButton(icon: ImageVector, description: String, onClick: () -> Unit, size: Dp = 52.dp, primary: Boolean = false) {
    TvFocusable(Modifier.size(size), corner = size / 2, focusScale = 1.12f, idleBorder = false, onClick = onClick) { _ ->
        Box(Modifier.fillMaxSize().background(if (primary) Color.White else Color(0xFF242433)), contentAlignment = Alignment.Center) {
            Icon(icon, description, tint = if (primary) Color.Black else Color.White, modifier = Modifier.size(size * 0.54f))
        }
    }
}

@Composable
private fun TvLogo() {
    Text(
        "SONICLY", fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
        style = LocalTextStyle.current.copy(brush = Brush.horizontalGradient(listOf(TvBlue, TvPurple)))
    )
}

@Composable
private fun TvTopBar(section: String, requesters: Map<String, FocusRequester>, onTab: (String) -> Unit, onRefresh: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF000000), TvBg))).padding(horizontal = 40.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TvLogo()
        Spacer(Modifier.width(34.dp))
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TvTabs.forEach { tab ->
                val active = section == tab
                TvFocusable(focusRequester = requesters[tab], corner = 50.dp, focusScale = 1.05f, idleBorder = false, onClick = { onTab(tab) }) { focused ->
                    Column(
                        Modifier.background(if (focused) Color(0x33FFFFFF) else Color.Transparent).padding(horizontal = 18.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (tab == "Search") Icon(Icons.Default.Search, "Search", tint = if (active || focused) Color.White else TvMuted, modifier = Modifier.size(26.dp))
                        else Text(tab, color = if (active || focused) Color.White else TvMuted, fontSize = 18.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                        Box(
                            Modifier.padding(top = 4.dp).height(3.dp).width(if (active) 26.dp else 0.dp)
                                .clip(RoundedCornerShape(2.dp)).background(Brush.horizontalGradient(listOf(TvBlue, TvPurple)))
                        )
                    }
                }
            }
        }
        TvRoundButton(Icons.Default.Refresh, "Refresh library", onRefresh, size = 46.dp)
    }
}

/* -------------------------------------------------- tiles --------------------------------------------------- */

@Composable
private fun TvMediaTile(
    art: Track, client: SoniclyClient, title: String, subtitle: String,
    selected: Boolean, playingNow: Boolean, isVideo: Boolean, wide: Boolean,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    TvFocusable(modifier.aspectRatio(if (wide) 16f / 9f else 1f), corner = 14.dp, onClick = onClick) { focused ->
        AlbumArt(art, client, Modifier.fillMaxSize(), corner = 0.dp)
        // Netflix-style title scrim along the bottom.
        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
                .padding(start = 12.dp, end = 12.dp, top = 34.dp, bottom = 10.dp)
        ) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (focused) Text(subtitle, color = TvMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (isVideo) {
            Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(18.dp))
        }
        if (selected || playingNow) {
            Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(28.dp).clip(CircleShape).background(Color(0xCC000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, "Now playing", tint = TvBlue, modifier = Modifier.size(18.dp))
            }
        }
        if (focused) {
            Box(Modifier.align(Alignment.Center).size(56.dp).clip(CircleShape).background(Color(0xB3000000)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(36.dp))
            }
        }
    }
}

private fun trackSubtitle(t: Track) = t.artist.ifBlank { t.album.ifBlank { if (t.mediaType == "video") "Video" else "Desktop library" } }

private fun groupSubtitle(kind: String, list: List<Track>): String {
    val count = "${list.size} track${if (list.size == 1) "" else "s"}"
    if (kind != "Albums") return count
    val who = list.firstOrNull { it.albumArtist.isNotBlank() || it.artist.isNotBlank() }?.let { it.albumArtist.ifBlank { it.artist } }
    return if (who != null) "$who  ·  $count" else count
}

private fun groupArt(list: List<Track>): Track = list.firstOrNull { it.artworkPath.isNotBlank() } ?: list.first()

@Composable
private fun TvRowTitle(title: String, count: Int? = null) {
    Row(Modifier.padding(start = 48.dp, top = 12.dp), verticalAlignment = Alignment.Bottom) {
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (count != null) {
            Spacer(Modifier.width(12.dp))
            Text("$count", color = TvMuted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}

@Composable
private fun TvTrackRow(
    title: String, list: List<Track>, client: SoniclyClient, selected: Track?, playing: Boolean, wide: Boolean,
    onPlay: (Track, List<Track>) -> Unit
) {
    Column {
        TvRowTitle(title, list.size)
        LazyRow(
            contentPadding = PaddingValues(start = 48.dp, end = 48.dp, top = 22.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            items(list, key = { it.id }) { t ->
                TvMediaTile(
                    art = t, client = client, title = t.title, subtitle = trackSubtitle(t),
                    selected = selected?.id == t.id, playingNow = selected?.id == t.id && playing,
                    isVideo = t.mediaType == "video", wide = wide,
                    modifier = Modifier.width(if (wide) 290.dp else 192.dp),
                    onClick = { onPlay(t, list) }
                )
            }
        }
    }
}

@Composable
private fun TvGroupRow(title: String, kind: String, groups: List<Pair<String, List<Track>>>, client: SoniclyClient, onOpen: (TvGroup) -> Unit) {
    Column {
        TvRowTitle(title, groups.size)
        LazyRow(
            contentPadding = PaddingValues(start = 48.dp, end = 48.dp, top = 22.dp, bottom = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            items(groups, key = { it.first }) { (name, list) ->
                TvMediaTile(
                    art = groupArt(list), client = client, title = name, subtitle = groupSubtitle(kind, list),
                    selected = false, playingNow = false, isVideo = false, wide = false,
                    modifier = Modifier.width(192.dp),
                    onClick = { onOpen(TvGroup(kind, name)) }
                )
            }
        }
    }
}

/* ------------------------------------------------------ hero ---------------------------------------------------- */

@Composable
private fun TvHero(
    track: Track, client: SoniclyClient, isCurrent: Boolean, playing: Boolean, musicCount: Int, videoCount: Int,
    playRequester: FocusRequester, onPlay: () -> Unit, onShuffle: () -> Unit
) {
    Box(Modifier.fillMaxWidth().height(380.dp)) {
        AlbumArt(track, client, Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(0.62f), corner = 0.dp)
        // Fade the artwork into the page on the left and bottom, like a streaming billboard.
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to TvBg, 0.38f to TvBg, 0.80f to TvBg.copy(alpha = 0.35f), 1f to Color.Transparent)))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to TvBg)))
        Column(
            Modifier.align(Alignment.CenterStart).fillMaxWidth(0.52f).padding(start = 48.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                if (isCurrent) "NOW PLAYING" else "FEATURED",
                color = TvBlue, fontSize = 13.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold
            )
            Text(track.title, color = Color.White, fontSize = 46.sp, lineHeight = 50.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(track.artist, track.album).filter { it.isNotBlank() }.joinToString("  ·  ").ifBlank { "From your desktop library" },
                color = Color(0xFFE3E8F1), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("$musicCount songs  ·  $videoCount videos", color = TvMuted, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                TvButton(
                    if (isCurrent && playing) "Pause" else "Play",
                    if (isCurrent && playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    primary = true, onClick = onPlay, focusRequester = playRequester
                )
                TvButton("Shuffle", Icons.Default.Shuffle, primary = false, onClick = onShuffle)
            }
        }
    }
}

/* ------------------------------------------------ now playing bar ------------------------------------------------ */

@Composable
private fun TvNowPlayingBar(track: Track, playing: Boolean, player: Player, client: SoniclyClient, onToggle: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing, track.id) {
        while (true) {
            val snapshot = readPlayerSnapshot(player)
            progress = if (snapshot.durationMs > 0L)
                (snapshot.positionMs.toFloat() / snapshot.durationMs.toFloat()).coerceIn(0f, 1f)
            else 0f
            if (!playing || !snapshot.isPlaying) break
            delay(500)
        }
    }
    Column(Modifier.fillMaxWidth().background(Color(0xF2101019))) {
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF2A2A3A))) {
            Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Brush.horizontalGradient(listOf(TvBlue, TvPurple))))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(track, client, Modifier.size(60.dp), corner = 8.dp)
            Column(Modifier.weight(1f).padding(horizontal = 18.dp)) {
                Text(track.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(trackSubtitle(track), color = TvMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                TvRoundButton(Icons.Default.SkipPrevious, "Previous", onPrev, size = 48.dp)
                TvRoundButton(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", onToggle, size = 56.dp, primary = true)
                TvRoundButton(Icons.Default.SkipNext, "Next", onNext, size = 48.dp)
            }
        }
    }
}

/* ------------------------------------------------- sections --------------------------------------------------- */

@Composable
private fun TvSearchField(query: String, onQuery: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().height(64.dp).glowBorder(focused, 14.dp).clip(RoundedCornerShape(14.dp)).background(TvCard)) {
        TextField(
            value = query, onValueChange = onQuery, singleLine = true,
            modifier = Modifier.fillMaxSize().onFocusChanged { focused = it.hasFocus },
            placeholder = { Text("Search titles, artists and albums", fontSize = 18.sp) },
            leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(28.dp)) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = TvCard, unfocusedContainerColor = TvCard,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = TvBlue,
                focusedPlaceholderColor = TvMuted, unfocusedPlaceholderColor = TvMuted,
                focusedLeadingIconColor = TvBlue, unfocusedLeadingIconColor = TvMuted
            )
        )
    }
}

@Composable
private fun TvSectionHeader(title: String, subtitle: String) {
    Column(Modifier.padding(top = 10.dp, bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = TvMuted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TvTrackGrid(
    tracks: List<Track>, client: SoniclyClient, selected: Track?, playing: Boolean, wide: Boolean, emptyText: String,
    onPlay: (Track) -> Unit, header: @Composable () -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(if (wide) 270.dp else 190.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 48.dp, end = 48.dp, top = 8.dp, bottom = 40.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { header() }
        if (tracks.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(emptyText, color = TvMuted, fontSize = 18.sp, modifier = Modifier.padding(vertical = 24.dp))
            }
        } else {
            gridItems(tracks, key = { it.id }) { t ->
                TvMediaTile(
                    art = t, client = client, title = t.title, subtitle = trackSubtitle(t),
                    selected = selected?.id == t.id, playingNow = selected?.id == t.id && playing,
                    isVideo = t.mediaType == "video", wide = wide,
                    modifier = Modifier.fillMaxWidth(), onClick = { onPlay(t) }
                )
            }
        }
    }
}

@Composable
private fun TvGroupGrid(kind: String, groups: List<Pair<String, List<Track>>>, client: SoniclyClient, onOpen: (TvGroup) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(190.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 48.dp, end = 48.dp, top = 8.dp, bottom = 40.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { TvSectionHeader(kind, "${groups.size} ${kind.lowercase()}") }
        gridItems(groups, key = { it.first }) { (name, list) ->
            TvMediaTile(
                art = groupArt(list), client = client, title = name, subtitle = groupSubtitle(kind, list),
                selected = false, playingNow = false, isVideo = false, wide = false,
                modifier = Modifier.fillMaxWidth(), onClick = { onOpen(TvGroup(kind, name)) }
            )
        }
    }
}

/* -------------------------------------------------------- screen ------------------------------------------------- */

@Composable
internal fun TvHome(
    all: List<Track>,
    tracks: List<Track>,
    selected: Track?,
    playing: Boolean,
    client: SoniclyClient,
    player: Player,
    query: String,
    onQuery: (String) -> Unit,
    section: String,
    onSection: (String) -> Unit,
    onPlay: (Track, List<Track>) -> Unit,
    onToggle: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onRefresh: () -> Unit,
    libraryError: String
) {
    val music = remember(all) { all.filter { it.mediaType != "video" } }
    val videos = remember(all) { all.filter { it.mediaType == "video" } }
    val albums = remember(music) {
        music.groupBy { it.album.ifBlank { "Unknown album" } }.entries.sortedBy { it.key.lowercase() }.map { it.key to it.value }
    }
    val artists = remember(music) {
        music.groupBy { it.artist.ifBlank { "Unknown artist" } }.entries.sortedBy { it.key.lowercase() }.map { it.key to it.value }
    }

    var group by remember { mutableStateOf<TvGroup?>(null) }
    val tabRequesters = remember { TvTabs.associateWith { FocusRequester() } }
    val heroPlay = remember { FocusRequester() }
    val groupPlay = remember { FocusRequester() }
    var firstRun by remember { mutableStateOf(true) }

    BackHandler(enabled = group != null) { group = null }

    // Put focus somewhere useful as soon as the screen opens / a detail view opens or closes.
    LaunchedEffect(group) {
        val g = group
        when {
            g != null -> groupPlay.requestWhenReady()
            firstRun -> {
                firstRun = false
                if (section == "Home" && all.isNotEmpty()) heroPlay.requestWhenReady() else tabRequesters[section]?.requestWhenReady()
            }
            else -> tabRequesters[section]?.requestWhenReady()
        }
    }

    val featured = selected ?: music.firstOrNull() ?: all.firstOrNull()

    fun playQueueFor(t: Track, list: List<Track>) = onPlay(t, if (t.mediaType == "video") listOf(t) else list)

    Column(Modifier.fillMaxSize().background(TvBg)) {
        TvTopBar(
            section = section, requesters = tabRequesters,
            onTab = { tab -> group = null; if (tab != "Search") onQuery(""); onSection(tab) },
            onRefresh = onRefresh
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val g = group
            when {
                all.isEmpty() -> Column(
                    Modifier.align(Alignment.Center).padding(48.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(Icons.Default.LibraryMusic, null, tint = TvBlue, modifier = Modifier.size(56.dp))
                    Text("Nothing in your library yet", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(libraryError.ifBlank { "Add music or videos on your desktop, then refresh." }, color = TvMuted, fontSize = 16.sp)
                    TvButton("Refresh library", Icons.Default.Refresh, primary = true, onClick = onRefresh)
                }

                section == "Visualizer" -> SoniclyVisualizerScreen(
                    track = selected?.takeIf { it.mediaType != "video" },
                    player = player,
                    client = client,
                    onPrevious = onPrev,
                    onToggle = onToggle,
                    onNext = onNext
                )

                g != null -> {
                    val list = if (g.kind == "Albums")
                        music.filter { it.album.ifBlank { "Unknown album" } == g.name }
                            .sortedWith(compareBy<Track>({ it.discNumber }, { it.trackNumber }, { it.title.lowercase() }))
                    else
                        music.filter { it.artist.ifBlank { "Unknown artist" } == g.name }
                            .sortedWith(compareBy<Track>({ it.album.lowercase() }, { it.discNumber }, { it.trackNumber }, { it.title.lowercase() }))
                    TvTrackGrid(list, client, selected, playing, wide = false, emptyText = "No tracks found.", onPlay = { playQueueFor(it, list) }) {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                            TvSectionHeader(g.name, groupSubtitle(g.kind, list))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                TvButton("Play all", Icons.Default.PlayArrow, primary = true, focusRequester = groupPlay, onClick = { list.firstOrNull()?.let { playQueueFor(it, list) } })
                                TvButton("Shuffle", Icons.Default.Shuffle, primary = false, onClick = { if (list.isNotEmpty()) { val q = list.shuffled(); playQueueFor(q.first(), q) } })
                            }
                        }
                    }
                }

                section == "Home" -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 36.dp)) {
                    if (featured != null) item(key = "hero") {
                        TvHero(
                            track = featured, client = client,
                            isCurrent = selected?.id == featured.id, playing = playing,
                            musicCount = music.size, videoCount = videos.size, playRequester = heroPlay,
                            onPlay = { if (selected?.id == featured.id) onToggle() else playQueueFor(featured, music) },
                            onShuffle = { val pool = music.ifEmpty { all }.shuffled(); playQueueFor(pool.first(), pool) }
                        )
                    }
                    item(key = "recent") { TvTrackRow("Recently Available", all.take(24), client, selected, playing, wide = false, onPlay = ::playQueueFor) }
                    if (albums.isNotEmpty()) item(key = "albums") { TvGroupRow("Albums", "Albums", albums.take(30), client) { group = it } }
                    if (videos.isNotEmpty()) item(key = "videos") { TvTrackRow("Videos", videos.take(30), client, selected, playing, wide = true, onPlay = ::playQueueFor) }
                    if (artists.isNotEmpty()) item(key = "artists") { TvGroupRow("Artists", "Artists", artists.take(30), client) { group = it } }
                    if (music.isNotEmpty()) item(key = "music") { TvTrackRow("All Songs", music.take(60), client, selected, playing, wide = false, onPlay = ::playQueueFor) }
                }

                section == "Albums" -> TvGroupGrid("Albums", albums, client) { group = it }
                section == "Artists" -> TvGroupGrid("Artists", artists, client) { group = it }

                section == "Search" -> TvTrackGrid(
                    tracks, client, selected, playing, wide = false,
                    emptyText = "No results for \"$query\".", onPlay = { playQueueFor(it, tracks) }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 10.dp, bottom = 8.dp)) {
                        TvSearchField(query, onQuery)
                        Text(if (query.isBlank()) "Browse everything" else "Results for \"$query\"", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }

                else -> {
                    val list = when (section) { "Music" -> music; "Videos" -> videos; else -> all }
                    TvTrackGrid(
                        list, client, selected, playing, wide = section == "Videos",
                        emptyText = if (section == "Videos") "No videos were returned by your desktop library." else "Nothing to show here yet.",
                        onPlay = { playQueueFor(it, list) }
                    ) { TvSectionHeader(section, "${list.size} items") }
                }
            }
        }
        if (selected != null) TvNowPlayingBar(selected, playing, player, client, onToggle, onPrev, onNext)
    }
}
