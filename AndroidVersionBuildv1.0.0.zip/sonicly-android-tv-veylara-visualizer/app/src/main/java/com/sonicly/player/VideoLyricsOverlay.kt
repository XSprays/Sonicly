package com.sonicly.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.Player
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private val VideoLyricsBlue = Color(0xFF39B9F5)
private val VideoLyricsPurple = Color(0xFF9460F5)
private val VideoLyricsMuted = Color(0xFFD1D9E6)

/**
 * Video lyrics are drawn in Compose above the existing PlayerView. This component
 * never creates or owns a player; it observes the Player passed in by SoniclyApp.
 */
@Composable
internal fun VideoLyricsOverlay(
    track: Track,
    player: Player,
    isTv: Boolean,
    modifier: Modifier = Modifier
) {
    var lyrics by remember(track.id) { mutableStateOf<SoniclyLyrics?>(null) }
    var loading by remember(track.id) { mutableStateOf(true) }
    var status by remember(track.id) { mutableStateOf("Finding lyrics…") }
    var showOverlay by remember(track.id) { mutableStateOf(false) }
    var showFullscreen by remember(track.id) { mutableStateOf(false) }
    var activeIndex by remember(track.id) { mutableIntStateOf(-1) }
    val playerEvents = rememberPlayerEventChannel(player)

    LaunchedEffect(track.id) {
        lyrics = null
        loading = true
        status = "Finding lyrics…"
        activeIndex = -1
        showOverlay = false
        showFullscreen = false
        try {
            // Read duration on Media3's application looper BEFORE switching to IO.
            // LRCLIB lookup itself is blocking network work and stays off the player thread.
            val durationMs = awaitPlayerDuration(player, expectedMediaId = track.id)
            val found = withContext(Dispatchers.IO) {
                LyricsRepository.lookup(track.title, track.artist, track.album, durationMs)
            }
            lyrics = found
            when {
                found == null -> status = "Lyrics not found for this video."
                found.instrumental -> status = "This track is instrumental."
                found.syncedLyrics.isNotEmpty() -> {
                    status = "Synchronized lyrics"
                    showOverlay = true
                }
                !found.plainLyrics.isNullOrBlank() -> status = "Plain lyrics available"
                else -> status = "Lyrics not available."
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            status = error.message ?: "Lyrics service unavailable."
        } finally {
            loading = false
        }
    }

    val timedLines = lyrics?.syncedLyrics.orEmpty()
    // The loop runs only while a lyrics surface is visible. Player getters are marshalled
    // to player.applicationLooper and Compose state changes only when the active line changes.
    LaunchedEffect(track.id, timedLines, showOverlay, showFullscreen) {
        if (timedLines.isEmpty() || (!showOverlay && !showFullscreen)) return@LaunchedEffect
        var lastIndex = Int.MIN_VALUE
        while (isActive) {
            val snapshot = readPlayerSnapshot(player)
            val nextIndex = timedLines.indexOfLast { it.timestampMs <= snapshot.positionMs }
            if (nextIndex != lastIndex) {
                activeIndex = nextIndex
                lastIndex = nextIndex
            }
            val nextBoundary = timedLines.getOrNull(nextIndex + 1)?.timestampMs
            val waitMs = when {
                !snapshot.isPlaying -> Long.MAX_VALUE
                nextBoundary != null -> (nextBoundary - snapshot.positionMs).coerceAtLeast(25L)
                else -> 30_000L
            }
            if (!awaitPlayerEventOrDelay(playerEvents, waitMs)) return@LaunchedEffect
        }
    }

    Box(modifier.fillMaxSize()) {
        // These actions are in the safe top area, well away from PlayerView's bottom controls.
        Row(
            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LyricsActionButton(
                label = if (showOverlay) "Hide lyrics" else "Lyrics",
                enabled = lyrics?.let { it.syncedLyrics.isNotEmpty() || !it.plainLyrics.isNullOrBlank() } == true,
                onClick = { showOverlay = !showOverlay },
                isTv = isTv
            )
            LyricsActionButton(
                label = "Fullscreen",
                enabled = lyrics?.let { it.syncedLyrics.isNotEmpty() || !it.plainLyrics.isNullOrBlank() } == true,
                onClick = { showFullscreen = true },
                isTv = isTv,
                icon = true
            )
        }

        if (loading || (timedLines.isEmpty() && lyrics?.plainLyrics.isNullOrBlank() && status.isNotBlank())) {
            Text(
                text = if (loading) "Finding lyrics…" else status,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = if (isTv) 17.sp else 12.sp,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 14.dp, top = 18.dp)
                    .clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
            )
        }

        if (showOverlay && timedLines.isNotEmpty()) {
            val centerIndex = activeIndex.coerceIn(0, timedLines.lastIndex)
            val previous = timedLines.getOrNull(centerIndex - 1)
            val current = timedLines.getOrNull(centerIndex)
            val next = timedLines.getOrNull(centerIndex + 1)
            Column(
                modifier = Modifier.align(Alignment.BottomCenter)
                    .padding(
                        start = if (isTv) 42.dp else 14.dp,
                        end = if (isTv) 42.dp else 14.dp,
                        bottom = if (isTv) 148.dp else 112.dp
                    )
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(if (isTv) 20.dp else 16.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(if (isTv) 20.dp else 16.dp))
                    .padding(horizontal = if (isTv) 26.dp else 16.dp, vertical = if (isTv) 15.dp else 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(if (isTv) 6.dp else 3.dp)
            ) {
                if (previous != null) {
                    Text(previous.text.ifBlank { "♪" }, color = VideoLyricsMuted.copy(alpha = 0.58f),
                        fontSize = if (isTv) 17.sp else 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (current != null) {
                    Text(
                        current.text.ifBlank { "♪" },
                        color = Color.Unspecified,
                        fontSize = if (isTv) 27.sp else 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = androidx.compose.ui.text.TextStyle(
                            brush = Brush.horizontalGradient(listOf(VideoLyricsBlue, VideoLyricsPurple))
                        )
                    )
                }
                if (next != null) {
                    Text(next.text.ifBlank { "♪" }, color = VideoLyricsMuted.copy(alpha = 0.72f),
                        fontSize = if (isTv) 17.sp else 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        if (lyrics?.syncedLyrics.isNullOrEmpty() && !lyrics?.plainLyrics.isNullOrBlank() && showOverlay) {
            Text(
                "Plain lyrics · open Fullscreen to read",
                modifier = Modifier.align(Alignment.BottomCenter)
                    .padding(bottom = if (isTv) 148.dp else 112.dp)
                    .clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                color = Color.White, fontSize = if (isTv) 18.sp else 13.sp
            )
        }
    }

    if (showFullscreen) {
        FullscreenVideoLyrics(
            track = track,
            lyrics = lyrics,
            status = status,
            activeIndex = activeIndex,
            isTv = isTv,
            onClose = { showFullscreen = false }
        )
    }
}

@Composable
private fun LyricsActionButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    isTv: Boolean,
    icon: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .onFocusChanged { focused = it.isFocused }
            .clip(RoundedCornerShape(12.dp))
            .background(if (focused) VideoLyricsBlue.copy(alpha = 0.28f) else Color.Black.copy(alpha = 0.66f))
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) VideoLyricsBlue else Color.White.copy(alpha = 0.34f),
                shape = RoundedCornerShape(12.dp)
            ),
        contentPadding = PaddingValues(horizontal = if (isTv) 18.dp else 12.dp, vertical = if (isTv) 12.dp else 7.dp)
    ) {
        if (icon) {
            Icon(Icons.Default.Fullscreen, contentDescription = null, tint = if (enabled) Color.White else Color.Gray, modifier = Modifier.size(if (isTv) 22.dp else 18.dp))
        } else {
            Icon(Icons.Default.Subtitles, contentDescription = null, tint = if (enabled) Color.White else Color.Gray, modifier = Modifier.size(if (isTv) 22.dp else 18.dp))
        }
        Spacer(Modifier.size(5.dp))
        Text(label, color = if (enabled) Color.White else Color.Gray, fontSize = if (isTv) 16.sp else 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FullscreenVideoLyrics(
    track: Track,
    lyrics: SoniclyLyrics?,
    status: String,
    activeIndex: Int,
    isTv: Boolean,
    onClose: () -> Unit
) {
    val listState = rememberLazyListState()
    BackHandler(enabled = true, onBack = onClose)
    LaunchedEffect(activeIndex, lyrics?.syncedLyrics?.size) {
        if (!lyrics?.syncedLyrics.isNullOrEmpty() && activeIndex >= 0) {
            listState.animateScrollToItem(activeIndex)
        }
    }
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xF20A1020), Color(0xF20A0D18), Color(0xF2361D4D))))
                .padding(horizontal = if (isTv) 72.dp else 20.dp, vertical = if (isTv) 44.dp else 24.dp)
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(if (isTv) 22.dp else 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Subtitles, null, tint = VideoLyricsBlue, modifier = Modifier.size(if (isTv) 34.dp else 25.dp))
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text("Sonicly Lyrics", color = Color.White, fontSize = if (isTv) 28.sp else 20.sp, fontWeight = FontWeight.Bold)
                        Text("${track.title} · ${track.artist}", color = VideoLyricsMuted, fontSize = if (isTv) 17.sp else 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    LyricsActionButton("Back to video", true, onClose, isTv, icon = true)
                }
                when {
                    lyrics?.syncedLyrics?.isNotEmpty() == true -> LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(if (isTv) 18.dp else 12.dp)
                    ) {
                        itemsIndexed(lyrics.syncedLyrics) { index, line ->
                            Text(
                                text = line.text.ifBlank { "♪" },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).focusable(),
                                color = if (index == activeIndex) Color.Unspecified else VideoLyricsMuted.copy(alpha = if (index < activeIndex) 0.38f else 0.76f),
                                fontSize = if (index == activeIndex) { if (isTv) 34.sp else 25.sp } else { if (isTv) 25.sp else 18.sp },
                                fontWeight = if (index == activeIndex) FontWeight.Bold else FontWeight.Medium,
                                style = if (index == activeIndex) androidx.compose.ui.text.TextStyle(
                                    brush = Brush.horizontalGradient(listOf(VideoLyricsBlue, VideoLyricsPurple))
                                ) else androidx.compose.ui.text.TextStyle.Default
                            )
                        }
                    }
                    !lyrics?.plainLyrics.isNullOrBlank() -> {
                        val plainLines = lyrics?.plainLyrics.orEmpty().lines().filter { it.isNotBlank() }
                        LazyColumn(
                            Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(if (isTv) 12.dp else 8.dp)
                        ) {
                            itemsIndexed(plainLines) { _, line ->
                                Text(
                                    text = line,
                                    modifier = Modifier.fillMaxWidth().focusable(),
                                    color = Color.White,
                                    fontSize = if (isTv) 25.sp else 18.sp,
                                    lineHeight = if (isTv) 38.sp else 29.sp
                                )
                            }
                        }
                    }
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            if (lyrics == null && status.startsWith("Finding")) CircularProgressIndicator(color = VideoLyricsBlue)
                            Text(status, color = VideoLyricsMuted, fontSize = if (isTv) 22.sp else 16.sp)
                        }
                    }
                }
            }
        }
    }
}
