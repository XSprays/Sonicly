# Changelog

## 1.0.2 — Metadata and artwork support

- Added a dependency-free Node.js metadata reader for MP3/AAC ID3, FLAC Vorbis comments and PICTURE blocks, Ogg Vorbis/Opus comments and embedded pictures, M4A/MP4-family iTunes atoms, and basic WAV/AIFF INFO/ID3 chunks.
- The library now returns artist, album, album artist, track/disc numbers and totals, year, and genre when available.
- Embedded front-cover artwork is served from the authenticated `/api/v1/artwork/:id` endpoint.
- Added same-basename and common folder-cover fallbacks, including `cover.jpg`, `folder.jpg`, `front.jpg`, `album.jpg`, `artwork.jpg`, and `poster.jpg`.
- Added `Artist/Album/Track` folder-name inference when tags are missing.
- Added metadata caching by file size and modification time, with bounded embedded-artwork memory use.
- Preserved the v1 API response shape, per-device pairing, and existing device-token state.
- Added integration tests for MP3, FLAC, M4A/MP4, Ogg, artwork streaming, and folder inference.

## 1.0.1 — Per-device pairing codes

- Generate separate, short-lived pairing codes for each new device request.
- Preserve already-paired devices when pairing a new device.
