# Sonicly Dedicated Media Server

**Release:** v1.0.2

A self-hosted Node.js media server for Sonicly desktop, Android, and Android TV clients. It runs as a small HTTP API and does not ship a website or web administration panel.

- **Runtime:** Node.js 20 or newer
- **Dependencies:** Node.js built-ins only; no `npm install` packages are required
- **Default port:** `47831` (matches Sonicly Android's current LAN discovery port)
- **Protocol:** Sonicly API v1

## What it does

- Serves music, videos, and photos from separate configurable folders.
- Reads embedded music metadata and album artwork directly from supported media files.
- Serves embedded artwork first, then same-name or folder-level cover images as a fallback.
- Streams audio, video, photos, and sidecar cover artwork without loading whole files into memory.
- Supports HTTP byte-range requests for playback seeking and video playback.
- Generates a separate, one-time four-digit pairing code for every new device request and prints it in the server console.
- Issues a separate bearer token to each paired device.
- Persists device tokens as SHA-256 hashes; raw tokens are only returned once during pairing.
- Allows individual devices to be revoked from the command line.
- Exposes a JSON API for desktop, Android, and Android TV clients. There is no web panel.

## Quick start

```bash
# 1. Extract the project and enter its directory
cd sonicly-media-server

# 2. Start the server (config.json is created automatically on first run)
node server.js
```

The first startup creates `config.json` and the default media folders:

```text
media/
├── music/
├── videos/
└── photos/
```

Copy files into those folders using SFTP, your VPS file manager, or another file-transfer method. The media API scans subfolders recursively. Hidden files and symbolic links are ignored.

A pairing code is generated when a new device requests pairing—not when the server starts. The server console prints a unique four-digit code next to that device request and its challenge ID. Enter that code in that device's Sonicly app within two minutes. Codes are not returned by the public API. Each active pairing request has its own code; requesting a code for a new device does not change or revoke any already-paired device.

## Configuration

Edit `config.json` and restart the server. `config.example.json` documents all available options.

```json
{
  "host": "0.0.0.0",
  "port": 47831,
  "serverName": "Sonicly",
  "version": "1.0.2",
  "dataDirectory": "./data",
  "directories": {
    "music": ["./media/music"],
    "videos": ["./media/videos"],
    "photos": ["./media/photos"]
  },
  "pairing": {
    "challengeTtlSeconds": 120,
    "maxRequestsPerMinute": 10,
    "maxFailedAttempts": 5,
    "failedAttemptWindowMinutes": 15
  },
  "library": {
    "cacheSeconds": 15,
    "maxFiles": 50000
  },
  "cors": {
    "allowedOrigins": ["*"]
  },
  "security": {
    "trustProxy": false
  }
}
```

Each media directory accepts either one path or an array of paths. Absolute paths are supported. Relative paths are resolved from the directory containing `config.json`.

### Environment variable overrides

Environment variables override the JSON configuration. This supports Pterodactyl eggs and other container hosts.

| Variable | Purpose | Default |
|---|---|---|
| `SONICLY_HOST` | Bind address | `0.0.0.0` |
| `SONICLY_PORT` | Listen port | config `port` |
| `PORT` | Alternate listen port override | config `port` |
| `SERVER_PORT` | Pterodactyl allocation port override | config `port` |
| `SONICLY_DATA_DIR` | Device and server state directory | `./data` |
| `SONICLY_MUSIC_DIR` | Music folder override | `./media/music` |
| `SONICLY_VIDEO_DIR` | Video folder override | `./media/videos` |
| `SONICLY_PHOTO_DIR` | Photo folder override | `./media/photos` |
| `SONICLY_CORS_ORIGINS` | Comma-separated allowed browser origins | `*` |
| `SONICLY_TRUST_PROXY` | Trust first `X-Forwarded-For` address (`true`/`false`) | `false` |
| `SONICLY_CONFIG` | Config file path | `./config.json` |

The API version is controlled by the installed server release, so an old `version` field in an existing `config.json` will not mask an upgrade.

Pairing codes are always generated per pairing request. Older `pairingCode` entries in `config.json` and the legacy `SONICLY_PAIRING_CODE` environment variable are ignored; remove them from your configuration. Existing paired-device records in `data/server-state.json` are retained during upgrades.

## Pterodactyl / Node.js egg

1. Create a server using a Node.js 20 or 22 egg/image.
2. Upload the contents of this repository into the server's working directory.
3. Set the startup command to `node server.js`.
4. Allocate the server's port in the panel. The process reads `SERVER_PORT` automatically; otherwise set `SONICLY_PORT` or `port` in `config.json`.
5. Start the server once to generate `config.json` and the media directories.
6. Put media in `media/music`, `media/videos`, and `media/photos`, or configure custom paths.
7. For each device, start pairing in that client and read its matching one-time code from the server console. Codes are generated separately for each request; already-paired devices remain paired.

The process binds to `0.0.0.0` by default. Make sure the allocated port is reachable from the clients. For clients outside the VPS's LAN, use a DNS name and HTTPS reverse proxy. Do not expose unauthenticated HTTP pairing or bearer-token traffic directly to the public internet.

## Connecting clients

### Android and Android TV

The API implements the Android project's existing v1 pairing flow and library shape:

- `GET /api/v1/discover`
- `POST /api/v1/pair/request`
- `POST /api/v1/pair/complete`
- `GET /api/v1/status`
- `GET /api/v1/library`
- `GET /api/v1/stream/:id`

The default port is intentionally `47831`, which the current Android discovery scan checks. A public VPS is not on the phone's local Wi-Fi subnet, so LAN auto-discovery will not find it; enter the VPS IP or DNS name manually in Connect by IP. If you change the port, include it explicitly, for example `media.example.net:50000`; automatic LAN scanning still checks `47831` until the Android app's discovery port is made configurable.

The Android project's current `Track` parser handles music and video through `/api/v1/library`. Photos are available through the new `/api/v1/photos` and `/api/v1/media?type=photo` endpoints; the Android app will need a photo-library UI/API call to display them.

### Desktop / Electron

A small Node.js client helper is included at `client/sonicly-client.cjs`. It provides discovery, pairing, library, photo, media, URL, and media-fetch methods. See [Client integration](docs/CLIENT-INTEGRATION.md) for an Electron main-process example.

## Device management

List paired devices:

```bash
npm run devices
```

Revoke a device:

```bash
node client/manage-devices.cjs revoke DEVICE_ID
```

The device ID is shown by the `devices` command. Revocation immediately invalidates that device's bearer token.

## API overview

All protected routes use:

```http
Authorization: Bearer YOUR_DEVICE_TOKEN
```

The legacy `X-Sonicly-Token` header is also accepted. Do not put tokens in URLs.

| Method | Endpoint | Authentication | Purpose |
|---|---|---:|---|
| `GET` | `/api/v1/health` | No | Basic process health |
| `GET` | `/api/v1/discover` | No | Host ID, name, version, port and pairing-required flag |
| `POST` | `/api/v1/pair/request` | No | Start a short-lived pairing challenge |
| `POST` | `/api/v1/pair/complete` | No | Exchange pairing code for a device token |
| `GET` | `/api/v1/status` | Yes | Verify the Sonicly API and protocol version |
| `GET` | `/api/v1/library` | Yes | Music and video tracks for the current Android client |
| `GET` | `/api/v1/photos` | Yes | Photo library |
| `GET` | `/api/v1/media?type=all` | Yes | Unified music, video and photo library |
| `GET` | `/api/v1/stream/:id` | Yes | Audio/video stream with byte-range support |
| `GET` | `/api/v1/photo/:id` | Yes | Photo stream |
| `GET` | `/api/v1/artwork/:id` | Yes | Embedded cover art or nearby sidecar artwork for a track or video |

### Music metadata and album art

The library reads tags locally on the VPS; it does not depend on a third-party metadata service or an internet lookup.

Supported embedded metadata:

- **MP3:** ID3v2.2/v2.3/v2.4 and ID3v1 tags, including APIC cover images.
- **FLAC:** Vorbis comments and embedded PICTURE blocks.
- **Ogg Vorbis / Opus:** Vorbis comments and `METADATA_BLOCK_PICTURE` images.
- **M4A / M4B / MP4 / M4V / MOV / 3GP:** common iTunes-style atoms, including `covr` artwork.
- **WAV / AIFF:** basic INFO/ID3 metadata chunks.

The library exposes `artist`, `album`, `albumArtist`, `trackNumber`, `trackTotal`, `discNumber`, `discTotal`, `year`, `genre`, `hasArtwork`, `artworkMime`, and `artworkPath`. Artwork priority is embedded front-cover art, then an image with the same base filename, then a folder image such as `cover.jpg`, `folder.jpg`, `front.jpg`, `album.jpg`, `artwork.jpg`, or `poster.jpg`. When file tags are missing and folders use the common `Artist/Album/Track` layout, the server also infers artist and album names from the folder structure (and ignores simple `CD 1` / `Disc 1` subfolders).

Tag and cover parsing uses Node.js built-ins only. Metadata is cached by file path, size, and modification time. Embedded image caching is bounded to avoid unbounded memory use on large libraries. If a file has no embedded tags or adjacent cover image, the server cannot invent missing album information; add tags or a sidecar cover image to that file's folder.

More request and response examples are in [API reference](docs/API.md).

## Security notes

- Discovery reveals public server metadata only. It never reveals the pairing code or access tokens.
- Each new pairing challenge receives a random four-digit code, unique among active challenges, and is bound to the requesting IP. It expires after two minutes.
- Failed pairing attempts are throttled per IP (five failures per configured window by default).
- Device tokens are random 256-bit values. Only SHA-256 hashes are persisted in `data/server-state.json`.
- Each device has its own token and can be revoked without re-pairing other devices. Adding a device never rotates existing device tokens.
- The server ignores symlinks while scanning media folders and clients never submit filesystem paths.
- The server has no upload endpoint, remote file browser, or web panel.
- Use HTTPS for connections over the internet. For public VPS hosting, put Node behind a TLS reverse proxy or VPN and restrict direct access to the Node port. Keep `trustProxy` false unless a trusted reverse proxy is directly in front of Node.

## Development and tests

No package install is needed.

```bash
npm test
npm start
```

The test suite uses Node's built-in test runner and starts temporary server instances with sample media files.
