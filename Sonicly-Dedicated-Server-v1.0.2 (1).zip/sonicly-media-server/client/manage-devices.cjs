'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { loadConfig } = require('../src/config.cjs');

function readState(stateFile) {
  if (!fs.existsSync(stateFile)) return { hostId: '', devices: [] };
  const state = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
  return { hostId: state.hostId || '', devices: Array.isArray(state.devices) ? state.devices : [] };
}

function writeState(stateFile, state) {
  const temporary = `${stateFile}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(state, null, 2), { mode: 0o600 });
  fs.renameSync(temporary, stateFile);
  try { fs.chmodSync(stateFile, 0o600); } catch { /* Windows may not support chmod semantics */ }
}

function main() {
  const config = loadConfig();
  fs.mkdirSync(config.dataDirectory, { recursive: true });
  const state = readState(config.stateFile);
  const [command = 'list', deviceId] = process.argv.slice(2);

  if (command === 'list') {
    if (!state.devices.length) {
      console.log('No paired devices.');
      return;
    }
    console.log('Paired Sonicly devices:');
    for (const device of state.devices) {
      console.log(`- ${device.name || 'Unnamed device'} | ${device.platform || 'unknown'} | ${device.id} | paired ${device.createdAt || 'at unknown time'}`);
    }
    return;
  }

  if (command === 'revoke') {
    if (!deviceId) throw new Error('Usage: node client/manage-devices.cjs revoke <device-id>');
    const initialCount = state.devices.length;
    state.devices = state.devices.filter((device) => device.id !== deviceId);
    if (state.devices.length === initialCount) throw new Error(`No paired device found with ID ${deviceId}`);
    writeState(config.stateFile, state);
    console.log(`Revoked device ${deviceId}. It can no longer access this server.`);
    return;
  }

  throw new Error('Unknown command. Use "list" or "revoke <device-id>".');
}

try { main(); }
catch (error) { console.error(`[Sonicly] ${error.message}`); process.exitCode = 1; }
