'use strict';

class SoniclyClient {
  constructor(baseUrl, token = '', options = {}) {
    if (typeof baseUrl !== 'string' || !baseUrl.trim()) throw new TypeError('A Sonicly server URL is required.');
    this.baseUrl = baseUrl.trim().replace(/\/+$/, '');
    this.token = token;
    this.fetch = options.fetch || globalThis.fetch;
    if (typeof this.fetch !== 'function') throw new Error('SoniclyClient requires Node.js 20+ with global fetch support.');
  }

  async request(path, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('accept', 'application/json');
    if (this.token) headers.set('authorization', `Bearer ${this.token}`);
    const response = await this.fetch(`${this.baseUrl}${path}`, { ...options, headers });
    const contentType = response.headers.get('content-type') || '';
    if (!response.ok) {
      let details = {};
      if (contentType.includes('application/json')) {
        try { details = await response.json(); } catch { /* keep default error */ }
      }
      const error = new Error(details.message || details.error || `Sonicly returned HTTP ${response.status}.`);
      error.status = response.status;
      throw error;
    }
    return response;
  }

  async discover() {
    return (await this.request('/api/v1/discover')).json();
  }

  async requestPair(deviceName, platform = 'desktop') {
    const response = await this.request('/api/v1/pair/request', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ deviceName, platform }),
    });
    return response.json();
  }

  async completePair(challengeId, code) {
    const response = await this.request('/api/v1/pair/complete', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ challengeId, code }),
    });
    return response.json();
  }

  async status() {
    return (await this.request('/api/v1/status')).json();
  }

  async library() {
    return (await this.request('/api/v1/library')).json();
  }

  async media(type = 'all', options = {}) {
    const query = new URLSearchParams({ type });
    if (options.query) query.set('q', options.query);
    if (options.limit !== undefined) query.set('limit', String(options.limit));
    if (options.offset !== undefined) query.set('offset', String(options.offset));
    return (await this.request(`/api/v1/media?${query}`)).json();
  }

  async photos(options = {}) {
    const query = new URLSearchParams();
    if (options.query) query.set('q', options.query);
    if (options.limit !== undefined) query.set('limit', String(options.limit));
    if (options.offset !== undefined) query.set('offset', String(options.offset));
    const suffix = query.size ? `?${query}` : '';
    return (await this.request(`/api/v1/photos${suffix}`)).json();
  }

  mediaUrl(item) {
    if (!item || typeof item.streamPath !== 'string') throw new TypeError('A media item with streamPath is required.');
    return new URL(item.streamPath, `${this.baseUrl}/`).toString();
  }

  artworkUrl(item) {
    if (!item || typeof item.artworkPath !== 'string' || !item.artworkPath) return null;
    return new URL(item.artworkPath, `${this.baseUrl}/`).toString();
  }

  async fetchMedia(item, options = {}) {
    const headers = new Headers(options.headers || {});
    if (this.token) headers.set('authorization', `Bearer ${this.token}`);
    return this.fetch(this.mediaUrl(item), { ...options, headers });
  }
}

module.exports = { SoniclyClient };
