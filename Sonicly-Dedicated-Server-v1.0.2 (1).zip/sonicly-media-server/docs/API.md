# Sonicly API v1

Base URL examples: `http://192.168.1.50:47831` or an HTTPS URL terminated by a reverse proxy.

Protected routes require `Authorization: Bearer <device-token>`. The server also accepts `X-Sonicly-Token` for compatibility. Do not include a token in a query string.

## Discovery

`GET /api/v1/discover` — no authentication.

```json
{
  "name": "Sonicly",
  "version": "1.0.2",
  "protocol": 1,
  "port": 47831,
  "hostId": "stable-server-id",
  "hostName": "media-host",
  "computerName": "media-host",
  "pairingRequired": true,
  "serverType": "dedicated"
}
```

The response intentionally contains no secret. Keep the protocol identifier `name` as `Sonicly`; the current Android probe checks that exact value. A public VPS will not appear in a phone's local-subnet scan, so remote clients should enter the server's public DNS name or IP manually.

## Pairing

Each `pair/request` call generates its own random four-digit, one-time code. The code is printed only to the server console next to the device name and challenge ID; it is not included in the HTTP response. Codes are unique among currently active challenges and expire after the configured TTL (120 seconds by default).

1. `POST /api/v1/pair/request`

```json
{ "deviceName": "Sonicly Desktop", "platform": "windows" }
```

Response:

```json
{ "challengeId": "opaque-random-challenge", "expiresIn": 120, "pairingRequired": true }
```

2. `POST /api/v1/pair/complete`

```json
{ "challengeId": "opaque-random-challenge", "code": "1234" }
```

Response:

```json
{
  "token": "random-device-bearer-token",
  "deviceId": "device-uuid",
  "hostId": "stable-server-id"
}
```

The token is only returned once. Store it securely in the client. The server stores only its SHA-256 hash. Pairing is throttled and challenges are bound to the IP that requested them. Every new device request gets a different active code. Pairing another device appends a new device record and does not rotate or revoke tokens for devices that are already paired.

## Authenticated status

`GET /api/v1/status`

Returns `name`, `version`, `protocol: 1`, `streaming`, `photos`, `serverType`, and `hostId`.

## Legacy-compatible music/video library

`GET /api/v1/library`

The response keeps the `tracks` array expected by the existing Android `SoniclyClient.kt`:

```json
{
  "tracks": [
    {
      "id": "24-character-media-id",
      "title": "Track title",
      "artist": "Example Artist",
      "album": "Example Album",
      "albumArtist": "Example Album Artist",
      "trackNumber": 1,
      "trackTotal": 12,
      "discNumber": 1,
      "discTotal": 1,
      "year": 2024,
      "genre": "Electronic",
      "hasArtwork": true,
      "artworkMime": "image/jpeg",
      "fileName": "Track title.flac",
      "folder": "music",
      "path": "Artist/Album/Track title.flac",
      "size": 123456,
      "modifiedAt": 1793560000000,
      "mime": "audio/flac",
      "mediaType": "audio",
      "type": "audio",
      "streamPath": "/api/v1/stream/24-character-media-id",
      "artworkPath": "/api/v1/artwork/24-character-media-id"
    }
  ],
  "count": 1,
  "musicCount": 1,
  "videoCount": 0,
  "photosCount": 0,
  "truncated": false
}
```

Metadata is read directly from supported media tags: MP3/AAC ID3v2/ID3v1, FLAC Vorbis comments and PICTURE blocks, Ogg Vorbis/Opus comments and metadata-block pictures, common M4A/MP4 iTunes atoms, and basic WAV/AIFF INFO or ID3 chunks. The server returns artist, album, album artist, track/disc numbers and totals, year, and genre when present. Filename-derived titles are used only when a title tag is missing.

The `artworkPath` is populated when the media has embedded cover art or a matching sidecar image. Embedded front-cover images are preferred, followed by an image with the same base filename, then a same-folder image named `cover`, `folder`, `front`, `album`, `artwork`, `art`, or `poster` (supported image extensions). `GET /api/v1/artwork/:id` serves embedded artwork or the sidecar image and supports authenticated `HEAD`, byte ranges, and ETags. When tags are absent, common `Artist/Album/Track` folder layouts can supply the artist and album names. The server does not call an external metadata provider; missing tags must be embedded in the media file or added through a sidecar cover image.

## Photos

`GET /api/v1/photos`

Returns `{ "photos": [...], "count": n, "total": n, "offset": 0, "nextOffset": null }`.

Each photo item includes `id`, `title`, `fileName`, `path`, `size`, `modifiedAt`, `mime`, `mediaType: "photo"`, and `streamPath` such as `/api/v1/photo/:id`.

## Unified media library

`GET /api/v1/media?type=all`

Supported `type` values: `all`, `audio`, `video`, and `photo` (aliases `music`, `videos`, `photos`, `image`, and `images` are accepted).

Returns `{ "items": [...], "count": n, "total": n, "offset": 0, "nextOffset": null, "type": "all" }`.

Optional query parameters:

- `q`: case-insensitive substring search over title, file name, folder and relative path.
- `limit`: page size, capped at 2000.
- `offset`: zero-based page offset.

When neither `limit` nor `offset` is present, the endpoint returns the full matching list.

## Streaming

- `GET /api/v1/stream/:id` — audio or video.
- `GET /api/v1/photo/:id` — photo.
- `GET /api/v1/artwork/:id` — associated cover art.

All three support `HEAD`, `Range: bytes=start-end`, and suffix ranges such as `Range: bytes=-500`. Successful range responses use HTTP `206 Partial Content` and include `Content-Range` and `Accept-Ranges`. Invalid ranges return `416 Range Not Satisfiable`.

## Status and errors

JSON errors use an `error` key. Common status codes:

- `400`: malformed JSON, invalid pairing challenge, or invalid media type.
- `401`: missing/invalid bearer token or incorrect pairing code.
- `404`: unknown API endpoint or media ID.
- `413`: request body too large.
- `429`: pairing request/attempt limit exceeded.
- `500`: unexpected server error.
