# Desktop / Electron client integration

The server is a standalone process. A desktop app connects to it over HTTP(S) using the same v1 protocol as the Android client.

A CommonJS Node.js helper is included at `client/sonicly-client.cjs`. In an Electron main process:

```js
const { SoniclyClient } = require('./sonicly-client.cjs');

async function connectSoniclyServer({ address, deviceName, pairingCode }) {
  // address example: https://media.example.net
  const unauthenticated = new SoniclyClient(address);
  const discovered = await unauthenticated.discover();
  if (discovered.name !== 'Sonicly' || discovered.protocol !== 1) {
    throw new Error('This is not a compatible Sonicly server.');
  }

  // The server console prints a fresh code for this device request. Prompt the user to enter that code.
  const challenge = await unauthenticated.requestPair(deviceName, 'desktop');
  const paired = await unauthenticated.completePair(challenge.challengeId, pairingCode);

  // Store paired.token in Electron's secure credential storage. Do not store it in a URL.
  const client = new SoniclyClient(address, paired.token);
  await client.status();
  const library = await client.library();
  return { client, paired, library };
}
```

After pairing, persist the token in the desktop app's secure storage (for example, an OS credential vault). The sample intentionally does not choose a storage solution or write a token to a plain-text settings file.

## Loading photos and the unified library

```js
const photoLibrary = await client.photos();
const allMedia = await client.media('all');
const videos = await client.media('video');
```

## Playback and artwork URLs

```js
const mediaUrl = client.mediaUrl(track);
const coverUrl = client.artworkUrl(track);
```

For a renderer that fetches media directly, attach the token header:

```js
const response = await fetch(mediaUrl, {
  headers: { Authorization: `Bearer ${token}` },
});
if (!response.ok) throw new Error(`Media request failed: ${response.status}`);
```

Use the same authorization header for artwork and photos. For audio/video playback, send Range requests when the playback engine supports them. Do not put the token in the URL.

## Desktop app UI flow suggestion

1. Server address field, such as `https://media.example.net:47831`.
2. Connect / Discover action.
3. Four-digit pairing-code prompt.
4. Save the returned token securely, plus `hostId` and `deviceId` for this server connection.
5. Use `/api/v1/library` for the existing audio/video model and `/api/v1/photos` for the gallery. Alternatively use `/api/v1/media?type=all` for a unified browser.
6. Offer a disconnect/forget action that deletes the locally stored token. Server-side revocation is done by the server owner with `node client/manage-devices.cjs revoke <device-id>`.
