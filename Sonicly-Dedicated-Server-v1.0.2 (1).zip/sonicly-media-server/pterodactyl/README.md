# Pterodactyl notes

This v1.0.2 repository is compatible with a standard Node.js 20+ egg. Use the Node.js 20 or Node.js 22 image, upload the project into the server working directory, and set the startup command to:

```bash
node server.js
```

Allocate one port in the panel. The server uses the `SERVER_PORT` environment variable when present, so the configured port matches the allocation automatically. Otherwise set `SONICLY_PORT`.

Suggested variables:

| Name | Default | Notes |
|---|---|---|
| `SONICLY_DATA_DIR` | `./data` | Keep this on persistent server storage |
| `SONICLY_MUSIC_DIR` | `./media/music` | Optional media path override |
| `SONICLY_VIDEO_DIR` | `./media/videos` | Optional media path override |
| `SONICLY_PHOTO_DIR` | `./media/photos` | Optional media path override |
| `SONICLY_CORS_ORIGINS` | `*` | Restrict to known app origins if using browser-based clients |

Music tags and embedded cover art are read by the Node.js server without npm dependencies. MP3/AAC, FLAC, Ogg/Opus, M4A/MP4-family, WAV, and AIFF metadata formats are supported; common `Artist/Album/Track` folders are also used as a fallback when tags are missing.

Each device starts its own pairing request in Sonicly; the server prints that request's one-time four-digit code in the egg console. Existing paired devices remain paired when another device is added. The legacy `SONICLY_PAIRING_CODE` variable is ignored and should be removed.

Do not use an ephemeral container filesystem for the media folders or `data/server-state.json`. Configure persistent storage/volume mounts for them.

For public-internet access, terminate TLS using a trusted reverse proxy and do not expose the unencrypted Node port directly to the internet. Set `security.trustProxy` to `true` only when the Node service is reachable exclusively through that trusted proxy.
