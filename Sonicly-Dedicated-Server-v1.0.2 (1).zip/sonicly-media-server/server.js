'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { loadConfig } = require('./src/config.cjs');
const { createPairingManager, findDeviceByToken } = require('./src/pairing.cjs');
const { MediaLibrary } = require('./src/media-library.cjs');

function normalizeIp(value) {
  const ip = String(value || 'unknown');
  return ip.startsWith('::ffff:') ? ip.slice(7) : ip;
}

function getClientIp(req, trustProxy) {
  if (trustProxy) {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string' && forwarded.trim()) return normalizeIp(forwarded.split(',')[0].trim());
  }
  return normalizeIp(req.socket.remoteAddress);
}

function json(res, statusCode, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(statusCode, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    ...extraHeaders,
  });
  if (res.req && res.req.method === 'HEAD') res.end();
  else res.end(body);
}

async function readJsonBody(req, maxBytes = 32 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) {
      const error = new Error('request_body_too_large');
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  if (size === 0) return {};
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('JSON body must be an object.');
    return parsed;
  } catch {
    const error = new Error('invalid_json_body');
    error.statusCode = 400;
    throw error;
  }
}

function filenameHeader(filename) {
  const ascii = String(filename || 'media').replace(/[\r\n"\\]/g, '_').replace(/[^\x20-\x7E]/g, '_');
  const encoded = encodeURIComponent(String(filename || 'media')).replace(/['()]/g, escape).replace(/\*/g, '%2A');
  return `inline; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}

function streamFile(req, res, file) {
  const stat = file.currentStat || fs.statSync(file.absolutePath);
  const size = stat.size;
  const modifiedMs = Math.floor(stat.mtimeMs / 1000) * 1000;
  const etag = `W/"${size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
  const baseHeaders = {
    'content-type': file.mime || 'application/octet-stream',
    'accept-ranges': 'bytes',
    'cache-control': 'private, max-age=300',
    'last-modified': new Date(modifiedMs).toUTCString(),
    etag,
    'content-disposition': filenameHeader(path.basename(file.absolutePath)),
    'x-content-type-options': 'nosniff',
  };

  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, baseHeaders);
    res.end();
    return;
  }

  let start = 0;
  let end = Math.max(0, size - 1);
  let statusCode = 200;
  const rangeHeader = req.headers.range;
  if (rangeHeader) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(String(rangeHeader).trim());
    if (!match || size === 0) {
      res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
      res.end();
      return;
    }
    if (match[1] === '') {
      const suffixLength = Number(match[2]);
      if (!Number.isSafeInteger(suffixLength) || suffixLength <= 0) {
        res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
        res.end();
        return;
      }
      start = Math.max(0, size - suffixLength);
    } else {
      start = Number(match[1]);
      end = match[2] === '' ? size - 1 : Number(match[2]);
    }
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= size || end < start) {
      res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
      res.end();
      return;
    }
    end = Math.min(end, size - 1);
    statusCode = 206;
    baseHeaders['content-range'] = `bytes ${start}-${end}/${size}`;
  }

  const contentLength = size === 0 ? 0 : end - start + 1;
  baseHeaders['content-length'] = contentLength;
  res.writeHead(statusCode, baseHeaders);
  if (req.method === 'HEAD' || contentLength === 0) {
    res.end();
    return;
  }

  const fileStream = fs.createReadStream(file.absolutePath, { start, end });
  fileStream.on('error', () => {
    if (!res.headersSent) json(res, 404, { error: 'media_file_unavailable' });
    else res.destroy();
  });
  fileStream.pipe(res);
}


function streamBuffer(req, res, file) {
  const buffer = file.buffer;
  const size = buffer.length;
  const etag = file.etag || `"${crypto.createHash('sha1').update(buffer).digest('hex')}"`;
  const baseHeaders = {
    'content-type': file.mime || 'application/octet-stream',
    'accept-ranges': 'bytes',
    'cache-control': 'private, max-age=3600',
    etag,
    'content-disposition': filenameHeader(file.fileName || 'artwork'),
    'x-content-type-options': 'nosniff',
  };
  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, baseHeaders);
    res.end();
    return;
  }

  let start = 0;
  let end = Math.max(0, size - 1);
  let statusCode = 200;
  const rangeHeader = req.headers.range;
  if (rangeHeader) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(String(rangeHeader).trim());
    if (!match || size === 0) {
      res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
      res.end();
      return;
    }
    if (match[1] === '') {
      const suffixLength = Number(match[2]);
      if (!Number.isSafeInteger(suffixLength) || suffixLength <= 0) {
        res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
        res.end();
        return;
      }
      start = Math.max(0, size - suffixLength);
    } else {
      start = Number(match[1]);
      end = match[2] === '' ? size - 1 : Number(match[2]);
    }
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= size || end < start) {
      res.writeHead(416, { ...baseHeaders, 'content-range': `bytes */${size}`, 'content-length': 0 });
      res.end();
      return;
    }
    end = Math.min(end, size - 1);
    statusCode = 206;
    baseHeaders['content-range'] = `bytes ${start}-${end}/${size}`;
  }

  const contentLength = size === 0 ? 0 : end - start + 1;
  baseHeaders['content-length'] = contentLength;
  res.writeHead(statusCode, baseHeaders);
  if (req.method === 'HEAD' || contentLength === 0) {
    res.end();
    return;
  }
  res.end(buffer.subarray(start, end + 1));
}

function matchesQuery(item, query) {
  if (!query) return true;
  const haystack = [item.title, item.artist, item.album, item.fileName, item.folder, item.path]
    .join(' ').toLowerCase();
  return haystack.includes(query.toLowerCase());
}

function paginate(items, url) {
  const offsetRaw = url.searchParams.get('offset');
  const limitRaw = url.searchParams.get('limit');
  if (offsetRaw === null && limitRaw === null) return { items, offset: 0, total: items.length, nextOffset: null };
  const offset = Math.max(0, Number.parseInt(offsetRaw || '0', 10) || 0);
  const requestedLimit = Math.max(1, Number.parseInt(limitRaw || '500', 10) || 500);
  const limit = Math.min(2000, requestedLimit);
  const sliced = items.slice(offset, offset + limit);
  const nextOffset = offset + sliced.length < items.length ? offset + sliced.length : null;
  return { items: sliced, offset, total: items.length, nextOffset };
}

async function loadState(config) {
  await fs.promises.mkdir(config.dataDirectory, { recursive: true });
  try {
    const parsed = JSON.parse(await fs.promises.readFile(config.stateFile, 'utf8'));
    return {
      hostId: typeof parsed.hostId === 'string' && parsed.hostId ? parsed.hostId : crypto.randomUUID(),
      devices: Array.isArray(parsed.devices) ? parsed.devices.filter((device) => device && typeof device.tokenHash === 'string') : [],
    };
  } catch (error) {
    if (error.code !== 'ENOENT') throw new Error(`Could not read server state: ${error.message}`);
    return { hostId: crypto.randomUUID(), devices: [] };
  }
}

function createStateWriter(config, state) {
  let queue = Promise.resolve();
  return function persistState() {
    const snapshot = JSON.stringify({
      hostId: state.hostId,
      devices: state.devices,
    }, null, 2);
    queue = queue.catch(() => {}).then(async () => {
      const temporaryPath = `${config.stateFile}.tmp`;
      await fs.promises.writeFile(temporaryPath, snapshot, { mode: 0o600 });
      await fs.promises.rename(temporaryPath, config.stateFile);
      try { await fs.promises.chmod(config.stateFile, 0o600); } catch { /* Windows may not support chmod semantics */ }
    });
    return queue;
  };
}

async function createSoniclyServer(config, options = {}) {
  const logger = options.logger || console;
  const state = options.state || await loadState(config);
  const persistState = createStateWriter(config, state);
  await persistState();

  for (const directoryList of Object.values(config.directories)) {
    for (const directory of directoryList) await fs.promises.mkdir(directory, { recursive: true });
  }

  const mediaLibrary = new MediaLibrary(config, logger);
  const pairing = createPairingManager({
    ttlSeconds: config.pairing.challengeTtlSeconds,
    maxRequestsPerMinute: config.pairing.maxRequestsPerMinute,
    maxFailedAttempts: config.pairing.maxFailedAttempts,
    failedWindowMinutes: config.pairing.failedAttemptWindowMinutes,
    state,
  });

  const server = http.createServer(async (req, res) => {
    res.req = req;
    res.setHeader('x-content-type-options', 'nosniff');
    res.setHeader('referrer-policy', 'no-referrer');
    res.setHeader('x-frame-options', 'DENY');

    const origin = req.headers.origin;
    const allowedOrigins = config.cors.allowedOrigins;
    const originAllowed = !origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin);
    if (origin && originAllowed) {
      res.setHeader('access-control-allow-origin', allowedOrigins.includes('*') ? '*' : origin);
      res.setHeader('vary', 'Origin');
    }
    res.setHeader('access-control-allow-methods', 'GET, HEAD, POST, OPTIONS');
    res.setHeader('access-control-allow-headers', 'Authorization, Content-Type, X-Sonicly-Token, Range, If-None-Match, If-Range');
    res.setHeader('access-control-expose-headers', 'Accept-Ranges, Content-Length, Content-Range, ETag, Last-Modified');

    if (req.method === 'OPTIONS') {
      if (!originAllowed) return json(res, 403, { error: 'origin_not_allowed' });
      res.writeHead(204, { 'content-length': 0 });
      return res.end();
    }

    let url;
    try { url = new URL(req.url || '/', 'http://sonicly.local'); }
    catch { return json(res, 400, { error: 'invalid_url' }); }

    if (!url.pathname.startsWith('/api/v1/')) return json(res, 404, { error: 'not_found', message: 'Sonicly has no web panel. Use the client application API.' });

    try {
      const ip = getClientIp(req, config.security.trustProxy);

      if (url.pathname === '/api/v1/health' && req.method === 'GET') {
        return json(res, 200, { ok: true, name: config.serverName, version: config.version });
      }

      if (url.pathname === '/api/v1/discover' && req.method === 'GET') {
        return json(res, 200, {
          name: config.serverName,
          version: config.version,
          protocol: 1,
          port: config.port,
          hostId: state.hostId,
          hostName: os.hostname(),
          computerName: os.hostname(),
          pairingRequired: true,
          serverType: 'dedicated',
        });
      }

      if (url.pathname === '/api/v1/pair/request' && req.method === 'POST') {
        const body = await readJsonBody(req);
        const result = pairing.request({ ip, deviceName: body.deviceName, platform: body.platform });
        if (!result.ok) return json(res, result.status, { error: result.error });
        logger.info?.(`[Sonicly] Pairing code for ${result.deviceName} (${result.platform}) from ${ip}, challenge ${result.challengeId}: ${result.code} (expires in ${result.expiresIn}s).`);
        return json(res, 200, { challengeId: result.challengeId, expiresIn: result.expiresIn, pairingRequired: true });
      }

      if (url.pathname === '/api/v1/pair/complete' && req.method === 'POST') {
        const body = await readJsonBody(req);
        const result = pairing.complete({ ip, challengeId: body.challengeId, code: body.code });
        if (!result.ok) return json(res, result.status, { error: result.error });
        try {
          await persistState();
        } catch (error) {
          state.devices = state.devices.filter((device) => device.id !== result.deviceId);
          return json(res, 500, { error: 'could_not_save_device', message: error.message });
        }
        logger.info?.(`[Sonicly] Paired ${result.deviceName} (${result.deviceId}).`);
        return json(res, 200, { token: result.token, deviceId: result.deviceId, hostId: state.hostId });
      }

      const authorization = req.headers.authorization || '';
      const bearer = authorization.startsWith('Bearer ') ? authorization.slice(7) : req.headers['x-sonicly-token'];
      const device = findDeviceByToken(state, bearer);
      if (!device) return json(res, 401, { error: 'unauthorized', message: 'This device has not been paired with this Sonicly server.' });

      if (url.pathname === '/api/v1/status' && (req.method === 'GET' || req.method === 'HEAD')) {
        return json(res, 200, {
          name: config.serverName,
          version: config.version,
          protocol: 1,
          streaming: true,
          photos: true,
          serverType: 'dedicated',
          hostId: state.hostId,
        });
      }

      if (url.pathname === '/api/v1/library' && (req.method === 'GET' || req.method === 'HEAD')) {
        const library = await mediaLibrary.scan();
        return json(res, 200, {
          tracks: library.tracks,
          count: library.tracks.length,
          musicCount: library.music.length,
          videoCount: library.videos.length,
          photosCount: library.photos.length,
          truncated: library.truncated,
        });
      }

      if (url.pathname === '/api/v1/photos' && (req.method === 'GET' || req.method === 'HEAD')) {
        const library = await mediaLibrary.scan();
        const q = (url.searchParams.get('q') || '').trim();
        const filtered = library.photos.filter((item) => matchesQuery(item, q));
        const page = paginate(filtered, url);
        return json(res, 200, {
          photos: page.items,
          count: page.items.length,
          total: page.total,
          offset: page.offset,
          nextOffset: page.nextOffset,
          truncated: library.truncated,
        });
      }

      if (url.pathname === '/api/v1/media' && (req.method === 'GET' || req.method === 'HEAD')) {
        const library = await mediaLibrary.scan();
        const type = (url.searchParams.get('type') || 'all').toLowerCase();
        const sources = {
          all: library.all,
          audio: library.music,
          music: library.music,
          video: library.videos,
          videos: library.videos,
          photo: library.photos,
          photos: library.photos,
          image: library.photos,
          images: library.photos,
        };
        if (!Object.hasOwn(sources, type)) return json(res, 400, { error: 'invalid_media_type', allowed: ['all', 'audio', 'video', 'photo'] });
        const q = (url.searchParams.get('q') || '').trim();
        const filtered = sources[type].filter((item) => matchesQuery(item, q));
        const page = paginate(filtered, url);
        return json(res, 200, {
          items: page.items,
          count: page.items.length,
          total: page.total,
          offset: page.offset,
          nextOffset: page.nextOffset,
          type,
          truncated: library.truncated,
        });
      }

      const streamMatch = /^\/api\/v1\/stream\/([a-f0-9]{24})$/.exec(url.pathname);
      if (streamMatch && (req.method === 'GET' || req.method === 'HEAD')) {
        const file = await mediaLibrary.get(streamMatch[1]);
        if (!file || file.mediaType === 'photo') return json(res, 404, { error: 'media_not_found' });
        return streamFile(req, res, file);
      }

      const photoMatch = /^\/api\/v1\/photo\/([a-f0-9]{24})$/.exec(url.pathname);
      if (photoMatch && (req.method === 'GET' || req.method === 'HEAD')) {
        const file = await mediaLibrary.get(photoMatch[1], 'photo');
        if (!file) return json(res, 404, { error: 'photo_not_found' });
        return streamFile(req, res, file);
      }

      const artworkMatch = /^\/api\/v1\/artwork\/([a-f0-9]{24})$/.exec(url.pathname);
      if (artworkMatch && (req.method === 'GET' || req.method === 'HEAD')) {
        const file = await mediaLibrary.getArtwork(artworkMatch[1]);
        if (!file) return json(res, 404, { error: 'artwork_not_found' });
        return file.buffer ? streamBuffer(req, res, file) : streamFile(req, res, file);
      }

      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return json(res, 405, { error: 'method_not_allowed' }, { allow: 'GET, HEAD, POST, OPTIONS' });
      }
      return json(res, 404, { error: 'endpoint_not_found' });
    } catch (error) {
      if (res.headersSent) {
        res.destroy();
        return;
      }
      logger.error?.(`[Sonicly] Request failed: ${error.stack || error.message}`);
      return json(res, error.statusCode || 500, {
        error: error.statusCode === 413 ? 'request_body_too_large' : 'internal_server_error',
      });
    }
  });

  return {
    server,
    state,
    mediaLibrary,
    async listen() {
      await new Promise((resolve, reject) => {
        const onError = (error) => {
          server.off('listening', onListening);
          reject(error);
        };
        const onListening = () => {
          server.off('error', onError);
          resolve();
        };
        server.once('error', onError);
        server.once('listening', onListening);
        server.listen(config.port, config.host);
      });
      const address = server.address();
      logger.info?.(`[Sonicly] Media server listening on ${config.host}:${address.port}`);
      return address;
    },
    async close() {
      if (!server.listening) return;
      await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    },
  };
}

async function main() {
  const config = loadConfig();
  const app = await createSoniclyServer(config);
  await app.listen();
  if (config.legacyPairingCodeConfigured) {
    console.warn('[Sonicly] A legacy fixed pairing code setting was found and is now ignored. Codes are generated per device request.');
  }
  console.log('');
  console.log('=================================================');
  console.log(' SONICLY DEDICATED MEDIA SERVER');
  console.log('=================================================');
  console.log(' Pairing codes: generated separately for each new device request');
  console.log(' Existing paired devices and their tokens are preserved.');
  console.log(` API port: ${config.port}`);
  console.log(` Host ID: ${app.state.hostId}`);
  console.log(' Do not expose plain HTTP directly to the public internet.');
  console.log(' Put this service behind HTTPS or restrict it to a trusted network.');
  console.log('=================================================');
  console.log('');

  const shutdown = async (signal) => {
    console.log(`[Sonicly] Received ${signal}; shutting down.`);
    try { await app.close(); process.exit(0); }
    catch (error) { console.error(`[Sonicly] Shutdown failed: ${error.message}`); process.exit(1); }
  };
  process.once('SIGINT', () => shutdown('SIGINT'));
  process.once('SIGTERM', () => shutdown('SIGTERM'));
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`[Sonicly] Fatal startup error: ${error.stack || error.message}`);
    process.exitCode = 1;
  });
}

module.exports = { createSoniclyServer, loadState, streamFile };
