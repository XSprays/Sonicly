'use strict';

const fs = require('node:fs');
const path = require('node:path');
const DEFAULTS = {
  host: '0.0.0.0',
  port: 47831,
  serverName: 'Sonicly',
  version: '1.0.2',
  dataDirectory: './data',
  directories: {
    music: ['./media/music'],
    videos: ['./media/videos'],
    photos: ['./media/photos'],
  },
  pairing: {
    challengeTtlSeconds: 120,
    maxRequestsPerMinute: 10,
    maxFailedAttempts: 5,
    failedAttemptWindowMinutes: 15,
  },
  library: {
    cacheSeconds: 15,
    maxFiles: 50000,
  },
  cors: { allowedOrigins: ['*'] },
  security: { trustProxy: false },
};

function merge(base, override) {
  const output = { ...base };
  for (const [key, value] of Object.entries(override || {})) {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      output[key] = merge(base[key] && typeof base[key] === 'object' ? base[key] : {}, value);
    } else {
      output[key] = value;
    }
  }
  return output;
}

function parsePort(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  const port = Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error(`Invalid port "${value}". Port must be an integer from 1 to 65535.`);
  }
  return port;
}

function asDirectoryList(value, label, baseDirectory) {
  const list = Array.isArray(value) ? value : [value];
  if (!list.length || list.some((entry) => typeof entry !== 'string' || !entry.trim())) {
    throw new Error(`directories.${label} must be a path or a non-empty array of paths.`);
  }
  return [...new Set(list.map((entry) => path.resolve(baseDirectory, entry)))];
}

function loadConfig(options = {}) {
  const configPath = path.resolve(options.configPath || process.env.SONICLY_CONFIG || path.join(process.cwd(), 'config.json'));
  const baseDirectory = path.dirname(configPath);
  const examplePath = path.join(__dirname, '..', 'config.example.json');

  if (!fs.existsSync(configPath)) {
    fs.mkdirSync(baseDirectory, { recursive: true });
    fs.copyFileSync(examplePath, configPath);
    console.log(`[Sonicly] Created ${configPath} from config.example.json`);
  }

  let fileConfig;
  try {
    fileConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (error) {
    throw new Error(`Could not read ${configPath}: ${error.message}`);
  }

  const raw = merge(DEFAULTS, fileConfig);
  const env = options.env || process.env;
  const portValue = env.SONICLY_PORT || env.PORT || env.SERVER_PORT;
  const envMusic = env.SONICLY_MUSIC_DIR;
  const envVideos = env.SONICLY_VIDEO_DIR;
  const envPhotos = env.SONICLY_PHOTO_DIR;
  const allowedOrigins = env.SONICLY_CORS_ORIGINS
    ? env.SONICLY_CORS_ORIGINS.split(',').map((value) => value.trim()).filter(Boolean)
    : raw.cors.allowedOrigins;

  const legacyPairingCodeConfigured = Boolean(String(env.SONICLY_PAIRING_CODE || raw.pairingCode || '').trim());

  const directories = {
    music: asDirectoryList(envMusic || raw.directories.music, 'music', baseDirectory),
    videos: asDirectoryList(envVideos || raw.directories.videos, 'videos', baseDirectory),
    photos: asDirectoryList(envPhotos || raw.directories.photos, 'photos', baseDirectory),
  };

  const dataDirectory = path.resolve(baseDirectory, env.SONICLY_DATA_DIR || raw.dataDirectory);
  const serverName = raw.serverName || DEFAULTS.serverName;
  if (serverName !== 'Sonicly') {
    throw new Error('serverName must remain Sonicly because existing Sonicly clients check this protocol identifier.');
  }

  const config = {
    host: env.SONICLY_HOST || raw.host || DEFAULTS.host,
    port: parsePort(portValue, parsePort(raw.port, DEFAULTS.port)),
    serverName,
    version: DEFAULTS.version, // The running release controls the API version; old config.json values must not mask upgrades.
    legacyPairingCodeConfigured,
    dataDirectory,
    stateFile: path.join(dataDirectory, 'server-state.json'),
    directories,
    pairing: {
      challengeTtlSeconds: Number(raw.pairing.challengeTtlSeconds) || 120,
      maxRequestsPerMinute: Number(raw.pairing.maxRequestsPerMinute) || 10,
      maxFailedAttempts: Number(raw.pairing.maxFailedAttempts) || 5,
      failedAttemptWindowMinutes: Number(raw.pairing.failedAttemptWindowMinutes) || 15,
    },
    library: {
      cacheSeconds: Math.max(0, Number(raw.library.cacheSeconds) || 0),
      maxFiles: Math.max(1, Number(raw.library.maxFiles) || 50000),
    },
    cors: { allowedOrigins: Array.isArray(allowedOrigins) ? allowedOrigins : ['*'] },
    security: { trustProxy: String(env.SONICLY_TRUST_PROXY ?? raw.security.trustProxy).toLowerCase() === 'true' },
    configPath,
    baseDirectory,
  };

  if (!config.directories.music.length || !config.directories.videos.length || !config.directories.photos.length) {
    throw new Error('Music, video, and photo directories must each contain at least one path.');
  }
  return config;
}

module.exports = { DEFAULTS, loadConfig };
