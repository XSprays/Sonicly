'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { MediaMetadataReader, imageMime } = require('./media-metadata.cjs');

const AUDIO_EXTENSIONS = new Set([
  '.mp3', '.m4a', '.m4b', '.aac', '.wav', '.wave', '.flac', '.ogg', '.oga', '.opus',
  '.aiff', '.aif', '.wma', '.weba', '.amr',
]);
const VIDEO_EXTENSIONS = new Set([
  '.mp4', '.m4v', '.mov', '.mkv', '.webm', '.avi', '.mpeg', '.mpg', '.mpe', '.ogv',
  '.3gp', '.3g2', '.ts', '.m2ts', '.mts', '.wmv', '.flv',
]);
const PHOTO_EXTENSIONS = new Set([
  '.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.avif', '.tif', '.tiff', '.heic', '.heif',
]);

const MIME_TYPES = {
  '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.m4b': 'audio/mp4', '.aac': 'audio/aac',
  '.wav': 'audio/wav', '.wave': 'audio/wav', '.flac': 'audio/flac', '.ogg': 'audio/ogg',
  '.oga': 'audio/ogg', '.opus': 'audio/ogg', '.aiff': 'audio/aiff', '.aif': 'audio/aiff',
  '.wma': 'audio/x-ms-wma', '.weba': 'audio/webm', '.amr': 'audio/amr',
  '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.mkv': 'video/x-matroska',
  '.webm': 'video/webm', '.avi': 'video/x-msvideo', '.mpeg': 'video/mpeg', '.mpg': 'video/mpeg',
  '.mpe': 'video/mpeg', '.ogv': 'video/ogg', '.3gp': 'video/3gpp', '.3g2': 'video/3gpp2',
  '.ts': 'video/mp2t', '.m2ts': 'video/mp2t', '.mts': 'video/mp2t', '.wmv': 'video/x-ms-wmv',
  '.flv': 'video/x-flv',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp',
  '.gif': 'image/gif', '.bmp': 'image/bmp', '.avif': 'image/avif', '.tif': 'image/tiff',
  '.tiff': 'image/tiff', '.heic': 'image/heic', '.heif': 'image/heif',
};

const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif'];
const COVER_NAMES = [
  ...['cover', 'folder', 'front', 'album', 'artwork', 'art', 'poster'].flatMap((name) => IMAGE_EXTENSIONS.map((extension) => `${name}${extension}`)),
];

function fileId(category, absolutePath) {
  return crypto.createHash('sha256').update(`${category}\0${path.resolve(absolutePath)}`).digest('hex').slice(0, 24);
}

function isInsideRoot(root, filePath) {
  const relative = path.relative(root, filePath);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function safeDisplayPath(root, absolutePath) {
  return path.relative(root, absolutePath).split(path.sep).join('/');
}

async function findCover(directory, mediaBaseName = '') {
  let entries;
  try {
    entries = await fs.promises.readdir(directory, { withFileTypes: true });
  } catch {
    return '';
  }
  const byLowerName = new Map(entries.filter((entry) => entry.isFile()).map((entry) => [entry.name.toLowerCase(), entry.name]));
  const preferredNames = mediaBaseName
    ? IMAGE_EXTENSIONS.map((extension) => `${mediaBaseName}${extension}`.toLowerCase())
    : [];
  for (const candidate of [...preferredNames, ...COVER_NAMES]) {
    const actualName = byLowerName.get(candidate);
    if (!actualName) continue;
    const coverPath = path.join(directory, actualName);
    try {
      const stat = await fs.promises.lstat(coverPath);
      if (stat.isFile() && !stat.isSymbolicLink()) return coverPath;
    } catch { /* ignore artwork that disappeared during scanning */ }
  }
  return '';
}

class MediaLibrary {
  constructor(config, logger = console) {
    this.config = config;
    this.logger = logger;
    this.cache = null;
    this.cacheExpiresAt = 0;
    this.index = new Map();
    this.metadataReader = new MediaMetadataReader({ maxEntries: this.config.library.maxFiles });
  }

  invalidate() {
    this.cache = null;
    this.cacheExpiresAt = 0;
  }

  async scan(force = false) {
    if (!force && this.cache && Date.now() < this.cacheExpiresAt) return this.cache;

    const output = { music: [], videos: [], photos: [], tracks: [], all: [] };
    const nextIndex = new Map();
    const visitedPaths = new Set();
    const coverCache = new Map();
    const getCachedCover = async (directory, baseName) => {
      const cacheKey = `${directory}\0${baseName || ''}`;
      if (!coverCache.has(cacheKey)) coverCache.set(cacheKey, await findCover(directory, baseName));
      return coverCache.get(cacheKey);
    };
    let totalScanned = 0;
    const maxFiles = this.config.library.maxFiles;
    let truncated = false;

    const roots = [
      ...this.config.directories.music.map((root) => ({ root, category: 'music', kind: 'audio' })),
      ...this.config.directories.videos.map((root) => ({ root, category: 'videos', kind: 'video' })),
      ...this.config.directories.photos.map((root) => ({ root, category: 'photos', kind: 'photo' })),
    ];

    for (const { root, category, kind } of roots) {
      try {
        await fs.promises.mkdir(root, { recursive: true });
      } catch (error) {
        this.logger.warn?.(`[Sonicly] Could not create media directory ${root}: ${error.message}`);
        continue;
      }

      const walk = async (directory) => {
        if (totalScanned >= maxFiles) {
          truncated = true;
          return;
        }
        let entries;
        try {
          entries = await fs.promises.readdir(directory, { withFileTypes: true });
        } catch (error) {
          this.logger.warn?.(`[Sonicly] Could not scan ${directory}: ${error.message}`);
          return;
        }
        entries.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));

        for (const entry of entries) {
          if (totalScanned >= maxFiles) {
            truncated = true;
            return;
          }
          if (!entry.name || entry.name.startsWith('.')) continue;
          const absolutePath = path.join(directory, entry.name);
          if (entry.isSymbolicLink()) continue;
          if (entry.isDirectory()) {
            await walk(absolutePath);
            continue;
          }
          if (!entry.isFile()) continue;

          totalScanned += 1;
          const absolute = path.resolve(absolutePath);
          if (!isInsideRoot(root, absolute)) continue;
          const dedupeKey = process.platform === 'win32' ? absolute.toLowerCase() : absolute;
          if (visitedPaths.has(dedupeKey)) continue;
          visitedPaths.add(dedupeKey);

          const extension = path.extname(entry.name).toLowerCase();
          const supported = kind === 'audio' ? AUDIO_EXTENSIONS.has(extension)
            : kind === 'video' ? VIDEO_EXTENSIONS.has(extension)
              : PHOTO_EXTENSIONS.has(extension);
          if (!supported) continue;

          let stat;
          try {
            stat = await fs.promises.stat(absolute);
          } catch { continue; }
          if (!stat.isFile()) continue;

          const id = fileId(category, absolute);
          const fallbackTitle = path.basename(entry.name, extension) || entry.name;
          const metadata = kind === 'photo'
            ? { title: '', artist: '', album: '', albumArtist: '', trackNumber: 0, trackTotal: 0, discNumber: 0, discTotal: 0, year: null, genre: '', artwork: null }
            : await this.metadataReader.read(absolute, stat);
          const relativePath = safeDisplayPath(root, absolute);
          const folderParts = relativePath.split('/').slice(0, -1)
            .filter((part) => !/^(?:cd|disc|disk)\s*\d+$/i.test(part));
          const folderAlbum = folderParts.length ? folderParts[folderParts.length - 1] : '';
          const folderArtist = folderParts.length > 1 ? folderParts[folderParts.length - 2] : '';
          const fallbackArtist = folderArtist;
          const fallbackAlbum = folderAlbum;
          const sharedArtwork = metadata.artwork?.data || null;
          const sidecarArtworkPath = kind === 'photo' ? '' : await getCachedCover(path.dirname(absolute), path.basename(entry.name, extension));
          const hasArtwork = Boolean(sharedArtwork || sidecarArtworkPath);
          const artist = metadata.artist || fallbackArtist;
          const album = metadata.album || fallbackAlbum;
          const item = {
            id,
            title: metadata.title || fallbackTitle,
            artist,
            album,
            albumArtist: metadata.albumArtist || artist,
            trackNumber: metadata.trackNumber || 0,
            trackTotal: metadata.trackTotal || 0,
            discNumber: metadata.discNumber || 0,
            discTotal: metadata.discTotal || 0,
            year: metadata.year || null,
            genre: metadata.genre || '',
            hasArtwork,
            artworkMime: sharedArtwork ? (metadata.artwork?.mime || imageMime(sharedArtwork)) : '',
            fileName: entry.name,
            folder: path.basename(root),
            path: relativePath,
            size: stat.size,
            modifiedAt: stat.mtimeMs,
            mime: MIME_TYPES[extension] || 'application/octet-stream',
            mediaType: kind,
            type: kind,
            streamPath: kind === 'photo' ? `/api/v1/photo/${id}` : `/api/v1/stream/${id}`,
            artworkPath: hasArtwork ? `/api/v1/artwork/${id}` : '',
          };
          const indexed = {
            ...item,
            absolutePath: absolute,
            rootPath: root,
            category,
            artworkData: sharedArtwork,
            artworkDataMime: sharedArtwork ? (metadata.artwork?.mime || imageMime(sharedArtwork)) : '',
            sidecarArtworkPath,
          };
          nextIndex.set(id, indexed);
          if (kind === 'audio') output.music.push(item);
          else if (kind === 'video') output.videos.push(item);
          else output.photos.push(item);
        }
      };

      await walk(root);
      if (truncated) break;
    }

    output.tracks = [...output.music, ...output.videos].sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }));
    output.all = [...output.tracks, ...output.photos].sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }));
    output.music.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }));
    output.videos.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }));
    output.photos.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }));
    output.truncated = truncated;
    output.scannedFiles = totalScanned;

    this.index = nextIndex;
    this.cache = output;
    this.cacheExpiresAt = Date.now() + this.config.library.cacheSeconds * 1000;
    return output;
  }

  async get(id, expectedKind) {
    await this.scan();
    const entry = this.index.get(String(id || ''));
    if (!entry || (expectedKind && entry.mediaType !== expectedKind)) return null;
    try {
      const stat = await fs.promises.lstat(entry.absolutePath);
      if (!stat.isFile() || stat.isSymbolicLink() || !isInsideRoot(entry.rootPath, path.resolve(entry.absolutePath))) return null;
      return { ...entry, currentStat: stat };
    } catch {
      return null;
    }
  }

  async getArtwork(id) {
    const entry = await this.get(id);
    if (!entry || entry.mediaType === 'photo') return null;
    if (entry.artworkData) {
      return {
        buffer: entry.artworkData,
        fileName: `${entry.id}-artwork${({ 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' })[entry.artworkDataMime || imageMime(entry.artworkData)] || ''}`,
        mime: entry.artworkDataMime || imageMime(entry.artworkData),
      };
    }
    const coverPath = entry.sidecarArtworkPath || await findCover(path.dirname(entry.absolutePath), path.basename(entry.absolutePath, path.extname(entry.absolutePath)));
    if (!coverPath) return null;
    try {
      const stat = await fs.promises.lstat(coverPath);
      if (!stat.isFile() || stat.isSymbolicLink()) return null;
      return {
        absolutePath: coverPath,
        currentStat: stat,
        mime: MIME_TYPES[path.extname(coverPath).toLowerCase()] || 'application/octet-stream',
      };
    } catch {
      return null;
    }
  }
}

module.exports = {
  MediaLibrary,
  AUDIO_EXTENSIONS,
  VIDEO_EXTENSIONS,
  PHOTO_EXTENSIONS,
  MIME_TYPES,
  isInsideRoot,
};
