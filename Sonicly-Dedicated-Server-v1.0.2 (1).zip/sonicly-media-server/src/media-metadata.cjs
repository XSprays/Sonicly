'use strict';

const fs = require('node:fs');
const path = require('node:path');

const MAX_TAG_BYTES = 32 * 1024 * 1024;
const MAX_MP4_MOOV_BYTES = 64 * 1024 * 1024;
const MAX_OGG_SCAN_BYTES = 8 * 1024 * 1024;
const MAX_CACHED_ARTWORK_BYTES = 128 * 1024 * 1024;

function cleanText(value) {
  return String(value ?? '').replace(/\0/g, '').replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim();
}

function decodeSynchsafe(buffer, offset = 0) {
  if (offset + 4 > buffer.length) return 0;
  return ((buffer[offset] & 0x7f) << 21)
    | ((buffer[offset + 1] & 0x7f) << 14)
    | ((buffer[offset + 2] & 0x7f) << 7)
    | (buffer[offset + 3] & 0x7f);
}

function decodeText(buffer, encoding = 3) {
  if (!buffer?.length) return '';
  try {
    if (encoding === 0) return cleanText(buffer.toString('latin1'));
    if (encoding === 1) {
      if (buffer.length >= 2 && buffer[0] === 0xfe && buffer[1] === 0xff) {
        const copy = Buffer.from(buffer.subarray(2));
        if (copy.length % 2) return cleanText(copy.subarray(0, -1).swap16().toString('utf16le'));
        return cleanText(copy.swap16().toString('utf16le'));
      }
      return cleanText(buffer.toString('utf16le').replace(/^\uFEFF/, ''));
    }
    if (encoding === 2) {
      const copy = Buffer.from(buffer);
      if (copy.length % 2) copy.fill(0, copy.length - 1);
      return cleanText(copy.swap16().toString('utf16le').replace(/^\uFEFF/, ''));
    }
    return cleanText(buffer.toString('utf8'));
  } catch {
    return cleanText(buffer.toString('latin1'));
  }
}

function findTextTerminator(buffer, start, encoding) {
  if (encoding === 1 || encoding === 2) {
    for (let index = start; index + 1 < buffer.length; index += 2) {
      if (buffer[index] === 0 && buffer[index + 1] === 0) return index;
    }
    return buffer.length;
  }
  const index = buffer.indexOf(0, start);
  return index < 0 ? buffer.length : index;
}

function readEncodedField(buffer, offset, encoding) {
  const end = findTextTerminator(buffer, offset, encoding);
  const value = decodeText(buffer.subarray(offset, end), encoding);
  const next = end >= buffer.length ? buffer.length : end + ((encoding === 1 || encoding === 2) ? 2 : 1);
  return { value, next };
}

function applyTag(metadata, rawKey, rawValue) {
  const key = String(rawKey || '').toUpperCase().trim();
  const value = cleanText(Array.isArray(rawValue) ? rawValue[0] : rawValue);
  if (!value) return;

  const aliases = {
    TITLE: 'title', TIT2: 'title', TT2: 'title', NAME: 'title', INAM: 'title', '\u00A9NAM': 'title',
    ARTIST: 'artist', TPE1: 'artist', TP1: 'artist', IART: 'artist', AUTH: 'artist', '\u00A9ART': 'artist',
    ALBUM: 'album', TALB: 'album', TAL: 'album', IPRD: 'album', '\u00A9ALB': 'album',
    ALBUMARTIST: 'albumArtist', ALBUM_ARTIST: 'albumArtist', BAND: 'albumArtist', TPE2: 'albumArtist', TP2: 'albumArtist', AART: 'albumArtist',
    TRACKNUMBER: 'trackNumber', TRACK: 'trackNumber', TRCK: 'trackNumber', TRK: 'trackNumber', IPRT: 'trackNumber',
    DISCNUMBER: 'discNumber', DISC: 'discNumber', TPOS: 'discNumber', TPA: 'discNumber',
    DATE: 'year', YEAR: 'year', TYER: 'year', TDRC: 'year', TYE: 'year', ICRD: 'year', '\u00A9DAY': 'year',
    GENRE: 'genre', TCON: 'genre', TCO: 'genre', IGNR: 'genre', '\u00A9GEN': 'genre',
  };
  const target = aliases[key];
  if (!target) return;
  if (target === 'trackNumber' || target === 'discNumber') {
    const match = value.match(/\d+/);
    if (match) metadata[target] = Number(match[0]);
    const total = value.match(/\/\s*(\d+)/);
    if (total) metadata[target === 'trackNumber' ? 'trackTotal' : 'discTotal'] = Number(total[1]);
    return;
  }
  if (target === 'year') {
    const year = value.match(/\b(\d{4})\b/);
    metadata.year = year ? Number(year[1]) : value;
    return;
  }
  if (!metadata[target]) metadata[target] = value;
}

function imageMime(buffer, fallback = '') {
  if (!buffer || buffer.length < 4) return fallback || 'application/octet-stream';
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'image/jpeg';
  if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return 'image/png';
  if (buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  if (buffer.toString('ascii', 0, 3) === 'GIF') return 'image/gif';
  if (buffer.toString('ascii', 0, 4) === 'BM') return 'image/bmp';
  return fallback || 'application/octet-stream';
}

function setArtwork(metadata, data, mime = '', priority = 1) {
  if (!Buffer.isBuffer(data) || data.length < 8 || data.length > 20 * 1024 * 1024) return;
  const detected = imageMime(data, mime);
  if (!detected.startsWith('image/')) return;
  if (!metadata.artwork || priority > (metadata.artwork.priority || 0)) {
    metadata.artwork = { data: Buffer.from(data), mime: detected, priority };
  }
}

function parseId3v2(buffer, metadata) {
  if (buffer.length < 10 || buffer.toString('ascii', 0, 3) !== 'ID3') return;
  const version = buffer[3];
  if (version < 2 || version > 4) return;
  const declaredSize = decodeSynchsafe(buffer, 6);
  const tagEnd = Math.min(buffer.length, 10 + declaredSize);
  if (tagEnd <= 10) return;
  let cursor = 10;
  const flags = buffer[5];
  if (flags & 0x40) {
    if (version === 3 && cursor + 4 <= tagEnd) cursor += 4 + buffer.readUInt32BE(cursor);
    else if (version === 4 && cursor + 4 <= tagEnd) cursor += decodeSynchsafe(buffer, cursor);
    else if (version === 2) return;
  }
  while (cursor < tagEnd) {
    let frameId;
    let frameSize;
    let headerSize;
    if (version === 2) {
      if (cursor + 6 > tagEnd) break;
      frameId = buffer.toString('ascii', cursor, cursor + 3);
      if (!/^[A-Z0-9]{3}$/.test(frameId)) break;
      frameSize = buffer[cursor + 3] * 65536 + buffer[cursor + 4] * 256 + buffer[cursor + 5];
      headerSize = 6;
    } else {
      if (cursor + 10 > tagEnd) break;
      frameId = buffer.toString('ascii', cursor, cursor + 4);
      if (!/^[A-Z0-9]{4}$/.test(frameId)) break;
      frameSize = version === 4 ? decodeSynchsafe(buffer, cursor + 4) : buffer.readUInt32BE(cursor + 4);
      headerSize = 10;
    }
    if (!frameSize || frameSize > tagEnd - cursor - headerSize) break;
    const frameStart = cursor + headerSize;
    let payload = buffer.subarray(frameStart, frameStart + frameSize);
    if (version >= 3) {
      const frameFlags = buffer.readUInt16BE(cursor + 8);
      if ((version === 3 && (frameFlags & 0x00c0)) || (version === 4 && (frameFlags & 0x000c))) {
        cursor = frameStart + frameSize;
        continue; // encrypted/compressed frames cannot be decoded safely
      }
      if (version === 4 && (frameFlags & 0x0002)) payload = deUnsynchronise(payload);
      if (version === 4 && (frameFlags & 0x0001) && payload.length >= 4) payload = payload.subarray(4); // data length indicator
    }
    const shortNames = { TT2: 'TIT2', TP1: 'TPE1', TAL: 'TALB', TP2: 'TPE2', TRK: 'TRCK', TPA: 'TPOS', TYE: 'TYER', TCO: 'TCON' };
    const mappedId = shortNames[frameId] || frameId;
    if (mappedId[0] === 'T' && payload.length > 1) {
      const encoding = payload[0];
      applyTag(metadata, mappedId, decodeText(payload.subarray(1), encoding).split('\u0000')[0]);
    } else if (mappedId === 'APIC' && payload.length > 5) {
      const encoding = payload[0];
      let mimeEnd = payload.indexOf(0, 1);
      if (mimeEnd < 0) mimeEnd = 1;
      const mime = payload.toString('latin1', 1, mimeEnd).toLowerCase();
      const pictureTypeOffset = Math.min(payload.length - 1, mimeEnd + 1);
      const pictureType = payload[pictureTypeOffset] || 0;
      const description = readEncodedField(payload, pictureTypeOffset + 1, encoding);
      setArtwork(metadata, payload.subarray(description.next), mime, pictureType === 3 ? 3 : 1);
    } else if (mappedId === 'PIC' && payload.length > 6) {
      const encoding = payload[0];
      const format = payload.toString('ascii', 1, 4).toLowerCase();
      const mime = format === 'png' ? 'image/png' : 'image/jpeg';
      const description = readEncodedField(payload, 5, encoding);
      setArtwork(metadata, payload.subarray(description.next), mime, payload[4] === 3 ? 3 : 1);
    }
    cursor = frameStart + frameSize;
  }
}

function deUnsynchronise(buffer) {
  const output = [];
  for (let index = 0; index < buffer.length; index += 1) {
    output.push(buffer[index]);
    if (buffer[index] === 0xff && buffer[index + 1] === 0x00) index += 1;
  }
  return Buffer.from(output);
}

function parseId3v1(buffer, metadata) {
  if (buffer.length < 128) return;
  const start = buffer.length - 128;
  if (buffer.toString('ascii', start, start + 3) !== 'TAG') return;
  const fields = [
    ['title', start + 3, 30], ['artist', start + 33, 30], ['album', start + 63, 30],
  ];
  for (const [target, offset, length] of fields) {
    if (!metadata[target]) metadata[target] = cleanText(buffer.toString('latin1', offset, offset + length));
  }
  if (!metadata.year) {
    const year = cleanText(buffer.toString('latin1', start + 93, start + 97));
    if (/^\d{4}$/.test(year)) metadata.year = Number(year);
  }
  if (!metadata.trackNumber && buffer[start + 125] === 0 && buffer[start + 126] !== 0) metadata.trackNumber = buffer[start + 126];
}

function parseVorbisComments(buffer, offset, metadata) {
  let cursor = offset;
  if (cursor + 4 > buffer.length) return cursor;
  const vendorLength = buffer.readUInt32LE(cursor); cursor += 4;
  if (vendorLength > buffer.length - cursor) return buffer.length;
  cursor += vendorLength;
  if (cursor + 4 > buffer.length) return cursor;
  const count = Math.min(buffer.readUInt32LE(cursor), 10000); cursor += 4;
  for (let index = 0; index < count && cursor + 4 <= buffer.length; index += 1) {
    const length = buffer.readUInt32LE(cursor); cursor += 4;
    if (length > buffer.length - cursor) break;
    const entry = buffer.toString('utf8', cursor, cursor + length);
    cursor += length;
    const split = entry.indexOf('=');
    if (split <= 0) continue;
    const key = entry.slice(0, split).toUpperCase();
    const value = entry.slice(split + 1);
    if (key === 'METADATA_BLOCK_PICTURE') {
      try {
        const picture = Buffer.from(value, 'base64');
        parseFlacPicture(picture, metadata);
      } catch { /* ignore invalid embedded picture */ }
    } else {
      applyTag(metadata, key, value);
    }
  }
  return cursor;
}

function parseFlacPicture(buffer, metadata) {
  if (buffer.length < 32) return;
  let cursor = 0;
  const pictureType = buffer.readUInt32BE(cursor); cursor += 4;
  const mimeLength = buffer.readUInt32BE(cursor); cursor += 4;
  if (mimeLength > buffer.length - cursor) return;
  const mime = buffer.toString('utf8', cursor, cursor + mimeLength); cursor += mimeLength;
  if (cursor + 4 > buffer.length) return;
  const descriptionLength = buffer.readUInt32BE(cursor); cursor += 4 + descriptionLength;
  if (cursor + 20 > buffer.length) return;
  cursor += 16; // width, height, color depth and indexed colors
  const dataLength = buffer.readUInt32BE(cursor); cursor += 4;
  if (dataLength > buffer.length - cursor) return;
  const data = buffer.subarray(cursor, cursor + dataLength);
  setArtwork(metadata, data, mime, pictureType === 3 ? 3 : 1);
}

function parseFlac(buffer, metadata) {
  if (buffer.length < 8 || buffer.toString('ascii', 0, 4) !== 'fLaC') return;
  let cursor = 4;
  let blocks = 0;
  while (cursor + 4 <= buffer.length && blocks++ < 128) {
    const header = buffer[cursor];
    const type = header & 0x7f;
    const isLast = Boolean(header & 0x80);
    const length = buffer.readUIntBE(cursor + 1, 3);
    cursor += 4;
    if (length > buffer.length - cursor) break;
    const block = buffer.subarray(cursor, cursor + length);
    if (type === 4) parseVorbisComments(block, 0, metadata);
    else if (type === 6) parseFlacPicture(block, metadata);
    cursor += length;
    if (isLast) break;
  }
}

function parseOgg(buffer, metadata) {
  let cursor = 0;
  const packets = [];
  let packetParts = [];
  let packetLength = 0;
  while (cursor + 27 <= buffer.length && packets.length < 8) {
    if (buffer.toString('ascii', cursor, cursor + 4) !== 'OggS') {
      const next = buffer.indexOf('OggS', cursor + 1, 'ascii');
      if (next < 0) break;
      cursor = next;
    }
    if (cursor + 27 > buffer.length) break;
    const segmentCount = buffer[cursor + 26];
    if (cursor + 27 + segmentCount > buffer.length) break;
    const lacingStart = cursor + 27;
    const dataStart = lacingStart + segmentCount;
    let dataCursor = dataStart;
    for (let index = 0; index < segmentCount; index += 1) {
      const length = buffer[lacingStart + index];
      if (dataCursor + length > buffer.length) return;
      packetParts.push(buffer.subarray(dataCursor, dataCursor + length));
      packetLength += length;
      dataCursor += length;
      if (length < 255) {
        packets.push(Buffer.concat(packetParts, packetLength));
        packetParts = [];
        packetLength = 0;
        if (packets.length >= 3) break;
      }
    }
    cursor = dataCursor;
  }
  for (const packet of packets) {
    if (packet.subarray(0, 7).toString('ascii') === '\u0003vorbis') {
      parseVorbisComments(packet, 7, metadata);
      return;
    }
    if (packet.subarray(0, 8).toString('ascii') === 'OpusTags') {
      parseVorbisComments(packet, 8, metadata);
      return;
    }
  }
}

function parseMp4DataAtom(buffer, start, end, key, metadata) {
  let cursor = start;
  while (cursor + 8 <= end) {
    const size = buffer.readUInt32BE(cursor);
    const type = buffer.toString('latin1', cursor + 4, cursor + 8);
    if (size < 8 || cursor + size > end) break;
    if (type === 'data' && size >= 16) {
      const dataType = buffer.readUInt32BE(cursor + 8) & 0x00ffffff;
      const valueStart = cursor + 16;
      const value = buffer.subarray(valueStart, cursor + size);
      if (key === 'covr') {
        const mime = dataType === 14 ? 'image/png' : dataType === 13 ? 'image/jpeg' : '';
        setArtwork(metadata, value, mime);
      } else if (key === 'trkn' || key === 'disk') {
        if (value.length >= 6) {
          const current = value.readUInt16BE(2);
          const total = value.readUInt16BE(4);
          if (key === 'trkn') {
            if (current) metadata.trackNumber = current;
            if (total) metadata.trackTotal = total;
          } else {
            if (current) metadata.discNumber = current;
            if (total) metadata.discTotal = total;
          }
        }
      } else {
        const text = decodeText(value, dataType === 2 ? 2 : 3);
        const map = {
          '\u00A9nam': 'TITLE', '\u00A9ART': 'ARTIST', 'aART': 'ALBUMARTIST', '\u00A9alb': 'ALBUM',
          '\u00A9day': 'DATE', '\u00A9gen': 'GENRE', '\u00A9wrt': 'COMPOSER',
        };
        if (map[key]) applyTag(metadata, map[key], text);
      }
    }
    cursor += size;
  }
}

function parseMp4Container(buffer, start, end, metadata, parent = '') {
  let cursor = start;
  while (cursor + 8 <= end) {
    let size = buffer.readUInt32BE(cursor);
    const type = buffer.toString('latin1', cursor + 4, cursor + 8);
    let header = 8;
    if (size === 1) {
      if (cursor + 16 > end) break;
      const large = buffer.readBigUInt64BE(cursor + 8);
      if (large > BigInt(Number.MAX_SAFE_INTEGER)) break;
      size = Number(large); header = 16;
    } else if (size === 0) {
      size = end - cursor;
    }
    if (size < header || cursor + size > end) break;
    const contentStart = cursor + header;
    const contentEnd = cursor + size;
    if (parent === 'ilst') {
      parseMp4DataAtom(buffer, contentStart, contentEnd, type, metadata);
    } else if (type === 'meta') {
      parseMp4Container(buffer, Math.min(contentStart + 4, contentEnd), contentEnd, metadata, 'meta');
    } else if (type === 'moov' || type === 'udta' || type === 'meta' || type === 'ilst') {
      parseMp4Container(buffer, contentStart, contentEnd, metadata, type);
    } else if (parent === 'meta' && type === 'ilst') {
      parseMp4Container(buffer, contentStart, contentEnd, metadata, 'ilst');
    }
    cursor += size;
  }
}

async function readExactly(handle, length, position) {
  const buffer = Buffer.alloc(length);
  const { bytesRead } = await handle.read(buffer, 0, length, position);
  return buffer.subarray(0, bytesRead);
}

async function parseMp4File(filePath, metadata) {
  const handle = await fs.promises.open(filePath, 'r');
  try {
    const stat = await handle.stat();
    let offset = 0;
    while (offset + 8 <= stat.size) {
      const header = await readExactly(handle, 16, offset);
      if (header.length < 8) break;
      let size = header.readUInt32BE(0);
      const type = header.toString('latin1', 4, 8);
      let headerSize = 8;
      if (size === 1) {
        if (header.length < 16) break;
        const large = header.readBigUInt64BE(8);
        if (large > BigInt(Number.MAX_SAFE_INTEGER)) break;
        size = Number(large); headerSize = 16;
      } else if (size === 0) size = stat.size - offset;
      if (size < headerSize || offset + size > stat.size) break;
      if (type === 'moov') {
        if (size > MAX_MP4_MOOV_BYTES) return;
        const moov = await readExactly(handle, size, offset);
        if (moov.length === size) parseMp4Container(moov, headerSize, moov.length, metadata, 'moov');
        return;
      }
      offset += size;
    }
  } finally {
    await handle.close();
  }
}

function parseWavOrAiff(buffer, metadata) {
  const isWave = buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WAVE';
  const isAiff = buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'FORM';
  if (!isWave && !isAiff) return;
  let cursor = 12;
  while (cursor + 8 <= buffer.length) {
    const id = buffer.toString('ascii', cursor, cursor + 4);
    const size = isWave ? buffer.readUInt32LE(cursor + 4) : buffer.readUInt32BE(cursor + 4);
    const start = cursor + 8;
    const end = Math.min(buffer.length, start + size);
    if (end < start) break;
    if (id === 'ID3 ' || id === 'id3 ') parseId3v2(buffer.subarray(start, end), metadata);
    if (id === 'LIST' && end - start >= 4 && buffer.toString('ascii', start, start + 4) === 'INFO') {
      let infoCursor = start + 4;
      while (infoCursor + 8 <= end) {
        const infoId = buffer.toString('ascii', infoCursor, infoCursor + 4);
        const infoSize = buffer.readUInt32LE(infoCursor + 4);
        applyTag(metadata, infoId, buffer.toString('latin1', infoCursor + 8, Math.min(end, infoCursor + 8 + infoSize)));
        infoCursor += 8 + infoSize + (infoSize % 2);
      }
    }
    if (isAiff && id === 'NAME') applyTag(metadata, 'TITLE', buffer.toString('latin1', start, end));
    if (isAiff && id === 'AUTH') applyTag(metadata, 'ARTIST', buffer.toString('latin1', start, end));
    cursor = start + size + (isWave && size % 2 ? 1 : 0);
  }
}


async function readFlacMetadataBuffer(handle, fileSize) {
  const signature = await readExactly(handle, 4, 0);
  if (signature.toString('ascii') !== 'fLaC') return await readExactly(handle, Math.min(fileSize, 64 * 1024), 0);
  const parts = [signature];
  let offset = 4;
  let total = 4;
  let blocks = 0;
  while (offset + 4 <= fileSize && total < MAX_TAG_BYTES && blocks++ < 128) {
    const header = await readExactly(handle, 4, offset);
    if (header.length !== 4) break;
    const length = header.readUIntBE(1, 3);
    if (total + 4 + length > MAX_TAG_BYTES || offset + 4 + length > fileSize) break;
    const data = await readExactly(handle, length, offset + 4);
    if (data.length !== length) break;
    parts.push(header, data);
    offset += 4 + length;
    total += 4 + length;
    if (header[0] & 0x80) break;
  }
  return Buffer.concat(parts, total);
}

async function readMediaMetadata(filePath, extension) {
  const metadata = {
    title: '', artist: '', album: '', albumArtist: '',
    trackNumber: 0, trackTotal: 0, discNumber: 0, discTotal: 0,
    year: null, genre: '', artwork: null,
  };
  const ext = extension.toLowerCase();

  if (['.mp4', '.m4v', '.m4a', '.m4b', '.mov', '.3gp', '.3g2'].includes(ext)) {
    await parseMp4File(filePath, metadata);
    return metadata;
  }

  const handle = await fs.promises.open(filePath, 'r');
  let start = Buffer.alloc(0);
  let tail = Buffer.alloc(0);
  try {
    const stat = await handle.stat();
    if (ext === '.mp3' || ext === '.aac') {
      const header = await readExactly(handle, Math.min(10, stat.size), 0);
      if (header.length >= 10 && header.toString('ascii', 0, 3) === 'ID3') {
        const declaredSize = decodeSynchsafe(header, 6);
        const footerSize = header[3] === 4 && (header[5] & 0x10) ? 10 : 0;
        const tagSize = Math.min(stat.size, Math.min(MAX_TAG_BYTES, 10 + declaredSize + footerSize));
        start = await readExactly(handle, tagSize, 0);
      } else {
        start = header;
      }
      if (ext === '.mp3' && stat.size > 128) tail = await readExactly(handle, 128, stat.size - 128);
      parseId3v2(start, metadata);
      parseId3v1(tail, metadata);
      return metadata;
    }

    if (ext === '.flac') {
      start = await readFlacMetadataBuffer(handle, stat.size);
      parseFlac(start, metadata);
      return metadata;
    }

    if (['.ogg', '.oga', '.opus', '.weba'].includes(ext)) {
      start = await readExactly(handle, Math.min(stat.size, MAX_OGG_SCAN_BYTES), 0);
      parseOgg(start, metadata);
      return metadata;
    }

    if (['.wav', '.wave', '.aiff', '.aif'].includes(ext)) {
      start = await readExactly(handle, Math.min(stat.size, 8 * 1024 * 1024), 0);
      parseWavOrAiff(start, metadata);
      return metadata;
    }

    return metadata;
  } finally {
    await handle.close();
  }
}

class MediaMetadataReader {
  constructor(options = {}) {
    this.maxEntries = options.maxEntries || 50000;
    this.maxArtworkBytes = options.maxArtworkBytes || MAX_CACHED_ARTWORK_BYTES;
    this.artworkBytes = 0;
    this.artworkCache = new Map();
    this.cache = new Map();
  }

  async read(filePath, stat) {
    const key = path.resolve(filePath);
    const cached = this.cache.get(key);
    if (cached && cached.size === stat.size && cached.mtimeMs === stat.mtimeMs) {
      // Refresh insertion order for a small LRU cache.
      this.cache.delete(key);
      this.cache.set(key, cached);
      return cached.value;
    }
    let value;
    try {
      value = await readMediaMetadata(key, path.extname(key));
    } catch {
      value = {
        title: '', artist: '', album: '', albumArtist: '', trackNumber: 0, trackTotal: 0,
        discNumber: 0, discTotal: 0, year: null, genre: '', artwork: null,
      };
    }
    if (value.artwork?.data) {
      const hash = require('node:crypto').createHash('sha256').update(value.artwork.data).digest('hex');
      const existing = this.artworkCache.get(hash);
      if (existing) {
        value.artwork.data = existing;
      } else if (this.artworkBytes + value.artwork.data.length <= this.maxArtworkBytes) {
        this.artworkCache.set(hash, value.artwork.data);
        this.artworkBytes += value.artwork.data.length;
      } else {
        // Avoid unbounded memory growth on very large libraries with many unique covers.
        value.artwork = null;
      }
    }
    this.cache.set(key, { size: stat.size, mtimeMs: stat.mtimeMs, value });
    while (this.cache.size > this.maxEntries) this.cache.delete(this.cache.keys().next().value);
    return value;
  }
}

module.exports = {
  MediaMetadataReader,
  readMediaMetadata,
  parseId3v2,
  parseFlac,
  parseOgg,
  parseMp4Container,
  imageMime,
};
