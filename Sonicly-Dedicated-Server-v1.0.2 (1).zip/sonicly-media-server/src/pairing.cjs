'use strict';

const crypto = require('node:crypto');

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function safeEqual(left, right) {
  const a = Buffer.from(String(left ?? ''), 'utf8');
  const b = Buffer.from(String(right ?? ''), 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createPairingManager({ ttlSeconds, maxRequestsPerMinute, maxFailedAttempts, failedWindowMinutes, state }) {
  const challenges = new Map();
  const requestWindows = new Map();
  const failureWindows = new Map();
  const ttlMs = ttlSeconds * 1000;
  const failureWindowMs = failedWindowMinutes * 60 * 1000;

  function prune(now = Date.now()) {
    for (const [id, challenge] of challenges) {
      if (challenge.expiresAt <= now) challenges.delete(id);
    }
    for (const [ip, bucket] of requestWindows) {
      if (now - bucket.startedAt > 60_000) requestWindows.delete(ip);
    }
    for (const [ip, bucket] of failureWindows) {
      if (now - bucket.startedAt > failureWindowMs) failureWindows.delete(ip);
    }
  }

  function consumeRequest(ip) {
    const now = Date.now();
    prune(now);
    const bucket = requestWindows.get(ip) || { startedAt: now, count: 0 };
    if (now - bucket.startedAt > 60_000) {
      bucket.startedAt = now;
      bucket.count = 0;
    }
    bucket.count += 1;
    requestWindows.set(ip, bucket);
    return bucket.count <= maxRequestsPerMinute;
  }

  function failuresLocked(ip) {
    const now = Date.now();
    const bucket = failureWindows.get(ip);
    if (!bucket) return false;
    if (now - bucket.startedAt > failureWindowMs) {
      failureWindows.delete(ip);
      return false;
    }
    return bucket.count >= maxFailedAttempts;
  }

  function recordFailure(ip) {
    const now = Date.now();
    const bucket = failureWindows.get(ip) || { startedAt: now, count: 0 };
    if (now - bucket.startedAt > failureWindowMs) {
      bucket.startedAt = now;
      bucket.count = 0;
    }
    bucket.count += 1;
    failureWindows.set(ip, bucket);
  }

  function generateCode() {
    // Avoid collisions between simultaneously active device-pairing challenges.
    const activeCodes = new Set([...challenges.values()].map((challenge) => challenge.code));
    for (let attempt = 0; attempt < 10_000; attempt += 1) {
      const code = String(crypto.randomInt(0, 10_000)).padStart(4, '0');
      if (!activeCodes.has(code)) return code;
    }
    throw new Error('Could not allocate a unique active pairing code.');
  }

  function request({ ip, deviceName, platform }) {
    if (!consumeRequest(ip)) return { ok: false, status: 429, error: 'too_many_pair_requests' };
    const challengeId = crypto.randomBytes(24).toString('hex');
    const cleanName = String(deviceName || 'Sonicly device').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 80) || 'Sonicly device';
    const cleanPlatform = String(platform || 'unknown').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 40) || 'unknown';
    const now = Date.now();
    const code = generateCode();
    challenges.set(challengeId, {
      ip,
      deviceName: cleanName,
      platform: cleanPlatform,
      code,
      createdAt: now,
      expiresAt: now + ttlMs,
    });
    // The code is returned only to the server process for console logging. It is
    // deliberately omitted from the public HTTP response.
    return { ok: true, challengeId, code, deviceName: cleanName, platform: cleanPlatform, expiresIn: ttlSeconds };
  }

  function complete({ ip, challengeId, code }) {
    prune();
    if (failuresLocked(ip)) return { ok: false, status: 429, error: 'pairing_temporarily_locked' };
    const challenge = challenges.get(String(challengeId || ''));
    if (!challenge || challenge.ip !== ip) {
      recordFailure(ip);
      return { ok: false, status: 400, error: 'pairing_challenge_invalid_or_expired' };
    }
    if (!/^\d{4}$/.test(String(code || '').trim()) || !safeEqual(String(code || '').trim(), challenge.code)) {
      recordFailure(ip);
      return { ok: false, status: 401, error: 'pairing_code_invalid' };
    }

    challenges.delete(challengeId);
    const token = crypto.randomBytes(32).toString('hex');
    const deviceId = crypto.randomUUID();
    const device = {
      id: deviceId,
      name: challenge.deviceName,
      platform: challenge.platform,
      tokenHash: sha256(token),
      createdAt: new Date().toISOString(),
    };
    state.devices.push(device);
    return { ok: true, token, deviceId, deviceName: device.name };
  }

  return { request, complete, prune };
}

function findDeviceByToken(state, token) {
  if (typeof token !== 'string' || token.length < 32 || token.length > 512) return null;
  const hash = Buffer.from(sha256(token), 'hex');
  for (const device of state.devices) {
    const expected = Buffer.from(device.tokenHash, 'hex');
    if (expected.length === hash.length && crypto.timingSafeEqual(expected, hash)) return device;
  }
  return null;
}

module.exports = { createPairingManager, findDeviceByToken, sha256 };
