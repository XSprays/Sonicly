'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createSoniclyServer } = require('../server.js');

async function makeFixture(t) {
  const temp = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'sonicly-server-test-'));
  const dirs = {
    music: path.join(temp, 'music'),
    videos: path.join(temp, 'videos'),
    photos: path.join(temp, 'photos'),
    data: path.join(temp, 'data'),
  };
  for (const directory of Object.values(dirs)) await fs.promises.mkdir(directory, { recursive: true });
  await fs.promises.writeFile(path.join(dirs.music, 'Test Song.mp3'), Buffer.from('0123456789abcdef'));
  await fs.promises.writeFile(path.join(dirs.videos, 'Test Movie.mp4'), Buffer.from('movie-content-12345'));
  await fs.promises.writeFile(path.join(dirs.photos, 'Test Photo.jpg'), Buffer.from([0xff, 0xd8, 0xff, 0xd9]));
  await fs.promises.writeFile(path.join(dirs.music, 'cover.jpg'), Buffer.from([0xff, 0xd8, 0xff, 0xd9]));

  const config = {
    host: '127.0.0.1',
    port: 0,
    serverName: 'Sonicly',
    version: 'test',
    dataDirectory: dirs.data,
    stateFile: path.join(dirs.data, 'server-state.json'),
    directories: {
      music: [dirs.music],
      videos: [dirs.videos],
      photos: [dirs.photos],
    },
    pairing: {
      challengeTtlSeconds: 120,
      maxRequestsPerMinute: 10,
      maxFailedAttempts: 5,
      failedAttemptWindowMinutes: 15,
    },
    library: { cacheSeconds: 0, maxFiles: 1000 },
    cors: { allowedOrigins: ['*'] },
    security: { trustProxy: false },
  };
  const logs = [];
  const logger = { info(message) { logs.push(String(message)); }, warn(message) { logs.push(String(message)); }, error(error) { throw new Error(error); } };
  const app = await createSoniclyServer(config, { logger });
  await app.listen();
  const address = app.server.address();
  const baseUrl = `http://127.0.0.1:${address.port}`;
  t.after(async () => {
    await app.close();
    await fs.promises.rm(temp, { recursive: true, force: true });
  });
  return { app, baseUrl, dirs, stateFile: config.stateFile, logs };
}

async function pair(baseUrl, logs) {
  const request = await fetch(`${baseUrl}/api/v1/pair/request`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ deviceName: 'Test desktop', platform: 'desktop' }),
  });
  assert.equal(request.status, 200);
  const challenge = await request.json();
  assert.equal(Object.hasOwn(challenge, 'code'), false, 'pairing code must not be exposed by the public API');
  const logLine = [...logs].reverse().find((line) => line.includes(challenge.challengeId));
  const code = logLine?.match(/: (\d{4}) \(expires in /)?.[1];
  assert.ok(code, 'the unique pairing code should be written to the server console');
  const complete = await fetch(`${baseUrl}/api/v1/pair/complete`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ challengeId: challenge.challengeId, code }),
  });
  assert.equal(complete.status, 200);
  return complete.json();
}

test('discovery exposes public host details without exposing pairing code or tokens', async (t) => {
  const { baseUrl } = await makeFixture(t);
  const response = await fetch(`${baseUrl}/api/v1/discover`);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.name, 'Sonicly');
  assert.equal(body.protocol, 1);
  assert.equal(body.pairingRequired, true);
  assert.ok(body.hostId);
  assert.equal(Object.hasOwn(body, 'token'), false);
  assert.equal(Object.hasOwn(body, 'pairingCode'), false);
});

test('pairing issues a persistent bearer token and protects the library', async (t) => {
  const { app, baseUrl, stateFile, logs } = await makeFixture(t);
  const before = await fetch(`${baseUrl}/api/v1/library`);
  assert.equal(before.status, 401);

  const paired = await pair(baseUrl, logs);
  assert.ok(paired.token);
  assert.ok(paired.deviceId);
  assert.equal(paired.hostId, app.state.hostId);
  const saved = JSON.parse(await fs.promises.readFile(stateFile, 'utf8'));
  assert.equal(saved.devices.length, 1);
  assert.equal(saved.devices[0].tokenHash.length, 64);
  assert.equal(Object.hasOwn(saved.devices[0], 'token'), false);

  const status = await fetch(`${baseUrl}/api/v1/status`, { headers: { authorization: `Bearer ${paired.token}` } });
  assert.equal(status.status, 200);
  assert.equal((await status.json()).protocol, 1);
});

test('library separates music and video while exposing photos through the photo API', async (t) => {
  const { baseUrl, logs } = await makeFixture(t);
  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };

  const libraryResponse = await fetch(`${baseUrl}/api/v1/library`, { headers });
  assert.equal(libraryResponse.status, 200);
  const library = await libraryResponse.json();
  assert.equal(library.tracks.length, 2);
  assert.equal(library.musicCount, 1);
  assert.equal(library.videoCount, 1);
  assert.ok(library.tracks.some((item) => item.mediaType === 'video'));
  assert.ok(library.tracks.find((item) => item.mediaType === 'audio').artworkPath);

  const photosResponse = await fetch(`${baseUrl}/api/v1/photos`, { headers });
  const photos = await photosResponse.json();
  assert.equal(photos.count, 1);
  assert.equal(photos.photos[0].mediaType, 'photo');
});

test('stream endpoint supports byte ranges and photo delivery', async (t) => {
  const { baseUrl, logs } = await makeFixture(t);
  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const library = await (await fetch(`${baseUrl}/api/v1/library`, { headers })).json();
  const song = library.tracks.find((item) => item.mediaType === 'audio');

  const ranged = await fetch(`${baseUrl}${song.streamPath}`, { headers: { ...headers, range: 'bytes=2-5' } });
  assert.equal(ranged.status, 206);
  assert.equal(ranged.headers.get('content-range'), 'bytes 2-5/16');
  assert.equal(await ranged.text(), '2345');

  const artworkResponse = await fetch(`${baseUrl}${song.artworkPath}`, { headers });
  assert.equal(artworkResponse.status, 200);
  assert.equal(artworkResponse.headers.get('content-type'), 'image/jpeg');

  const unifiedResponse = await fetch(`${baseUrl}/api/v1/media?type=all`, { headers });
  const unified = await unifiedResponse.json();
  assert.equal(unified.count, 3);

  const photoList = await (await fetch(`${baseUrl}/api/v1/photos`, { headers })).json();
  const photo = photoList.photos[0];
  const photoResponse = await fetch(`${baseUrl}${photo.streamPath}`, { headers });
  assert.equal(photoResponse.status, 200);
  assert.equal(photoResponse.headers.get('content-type'), 'image/jpeg');
  assert.equal((await photoResponse.arrayBuffer()).byteLength, 4);
});

test('pairing code attempts are rate limited', async (t) => {
  const { baseUrl } = await makeFixture(t);
  for (let index = 0; index < 5; index += 1) {
    const request = await fetch(`${baseUrl}/api/v1/pair/request`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ deviceName: 'Test' }),
    });
    const challenge = await request.json();
    const result = await fetch(`${baseUrl}/api/v1/pair/complete`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ challengeId: challenge.challengeId, code: '99999' }),
    });
    assert.equal(result.status, 401);
  }
  const request = await fetch(`${baseUrl}/api/v1/pair/request`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ deviceName: 'Test' }),
  });
  const challenge = await request.json();
  const locked = await fetch(`${baseUrl}/api/v1/pair/complete`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ challengeId: challenge.challengeId, code: '99999' }),
  });
  assert.equal(locked.status, 429);
});


test('each new device gets a distinct pairing code while previously paired devices stay paired', async (t) => {
  const { app, baseUrl, logs, stateFile } = await makeFixture(t);

  async function requestChallenge(deviceName, platform) {
    const response = await fetch(`${baseUrl}/api/v1/pair/request`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ deviceName, platform }),
    });
    assert.equal(response.status, 200);
    const challenge = await response.json();
    const line = logs.find((entry) => entry.includes(challenge.challengeId));
    const code = line?.match(/: (\d{4}) \(expires in /)?.[1];
    assert.ok(code, `server console should issue a code for ${deviceName}`);
    assert.equal(Object.hasOwn(challenge, 'code'), false);
    return { challenge, code };
  }

  async function finishPair(challenge, code) {
    const response = await fetch(`${baseUrl}/api/v1/pair/complete`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ challengeId: challenge.challengeId, code }),
    });
    assert.equal(response.status, 200);
    return response.json();
  }

  const firstChallenge = await requestChallenge('Desktop PC', 'windows');
  const secondChallenge = await requestChallenge('Android TV', 'android-tv');
  assert.notEqual(firstChallenge.code, secondChallenge.code, 'simultaneous pairing challenges must not share a code');

  const firstDevice = await finishPair(firstChallenge.challenge, firstChallenge.code);
  const firstStatusBefore = await fetch(`${baseUrl}/api/v1/status`, {
    headers: { authorization: `Bearer ${firstDevice.token}` },
  });
  assert.equal(firstStatusBefore.status, 200);

  const secondDevice = await finishPair(secondChallenge.challenge, secondChallenge.code);
  assert.notEqual(firstDevice.deviceId, secondDevice.deviceId);

  const firstStatusAfter = await fetch(`${baseUrl}/api/v1/status`, {
    headers: { authorization: `Bearer ${firstDevice.token}` },
  });
  const secondStatus = await fetch(`${baseUrl}/api/v1/status`, {
    headers: { authorization: `Bearer ${secondDevice.token}` },
  });
  assert.equal(firstStatusAfter.status, 200, 'adding a new device must not invalidate the first device token');
  assert.equal(secondStatus.status, 200);

  const saved = JSON.parse(await fs.promises.readFile(stateFile, 'utf8'));
  assert.equal(saved.devices.length, 2);
  assert.deepEqual(new Set(saved.devices.map((device) => device.id)), new Set([firstDevice.deviceId, secondDevice.deviceId]));
  assert.ok(saved.devices.every((device) => typeof device.tokenHash === 'string' && device.tokenHash.length === 64));
});

function id3Frame(id, payload) {
  const header = Buffer.alloc(10);
  header.write(id, 0, 4, 'ascii');
  header.writeUInt32BE(payload.length, 4);
  return Buffer.concat([header, payload]);
}

function id3Tag(frames) {
  const body = Buffer.concat(frames);
  const header = Buffer.from([
    0x49, 0x44, 0x33, 0x03, 0x00, 0x00,
    (body.length >> 21) & 0x7f,
    (body.length >> 14) & 0x7f,
    (body.length >> 7) & 0x7f,
    body.length & 0x7f,
  ]);
  return Buffer.concat([header, body, Buffer.from('fake-audio-data')]);
}

function id3TextFrame(id, value) {
  return id3Frame(id, Buffer.concat([Buffer.from([3]), Buffer.from(value, 'utf8')]));
}

function flacVorbisBlock(entries) {
  const vendor = Buffer.from('Sonicly test encoder', 'utf8');
  const parts = [Buffer.alloc(4), vendor, Buffer.alloc(4)];
  parts[0].writeUInt32LE(vendor.length);
  parts[2].writeUInt32LE(entries.length);
  for (const entry of entries) {
    const encoded = Buffer.from(entry, 'utf8');
    const length = Buffer.alloc(4);
    length.writeUInt32LE(encoded.length);
    parts.push(length, encoded);
  }
  return Buffer.concat(parts);
}

function flacPictureBlock(image) {
  const mime = Buffer.from('image/jpeg', 'ascii');
  const fields = [];
  const push32 = (value) => { const buffer = Buffer.alloc(4); buffer.writeUInt32BE(value); fields.push(buffer); };
  push32(3); push32(mime.length); fields.push(mime); push32(0);
  push32(600); push32(600); push32(24); push32(0); push32(image.length); fields.push(image);
  return Buffer.concat(fields);
}

function flacMetadataHeader(type, block, isLast = false) {
  return Buffer.concat([Buffer.from([(isLast ? 0x80 : 0) | type, (block.length >> 16) & 0xff, (block.length >> 8) & 0xff, block.length & 0xff]), block]);
}

test('reads MP3 ID3 metadata and serves embedded album artwork before folder artwork', async (t) => {
  const { baseUrl, dirs, logs } = await makeFixture(t);
  const artwork = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x00, 0x00, 0xff, 0xd9]);
  const apic = Buffer.concat([
    Buffer.from([3]), Buffer.from('image/jpeg\0', 'ascii'), Buffer.from([3, 0]), artwork,
  ]);
  const file = id3Tag([
    id3TextFrame('TIT2', 'Embedded Title'),
    id3TextFrame('TPE1', 'Embedded Artist'),
    id3TextFrame('TALB', 'Embedded Album'),
    id3TextFrame('TPE2', 'Embedded Album Artist'),
    id3TextFrame('TRCK', '03/11'),
    id3TextFrame('TPOS', '2/2'),
    id3TextFrame('TDRC', '2024-03-01'),
    id3TextFrame('TCON', 'Electronic'),
    id3Frame('APIC', apic),
  ]);
  await fs.promises.writeFile(path.join(dirs.music, 'Test Song.mp3'), file);

  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const response = await fetch(`${baseUrl}/api/v1/library`, { headers });
  const library = await response.json();
  const song = library.tracks.find((item) => item.mediaType === 'audio');
  assert.equal(song.title, 'Embedded Title');
  assert.equal(song.artist, 'Embedded Artist');
  assert.equal(song.album, 'Embedded Album');
  assert.equal(song.albumArtist, 'Embedded Album Artist');
  assert.equal(song.trackNumber, 3);
  assert.equal(song.trackTotal, 11);
  assert.equal(song.discNumber, 2);
  assert.equal(song.discTotal, 2);
  assert.equal(song.year, 2024);
  assert.equal(song.genre, 'Electronic');
  assert.equal(song.hasArtwork, true);
  assert.equal(song.artworkMime, 'image/jpeg');

  const artResponse = await fetch(`${baseUrl}${song.artworkPath}`, { headers });
  assert.equal(artResponse.status, 200);
  assert.equal(artResponse.headers.get('content-type'), 'image/jpeg');
  assert.deepEqual(Buffer.from(await artResponse.arrayBuffer()), artwork);
  const rangedArt = await fetch(`${baseUrl}${song.artworkPath}`, { headers: { ...headers, range: 'bytes=2-5' } });
  assert.equal(rangedArt.status, 206);
  assert.deepEqual(Buffer.from(await rangedArt.arrayBuffer()), artwork.subarray(2, 6));
});

test('reads FLAC Vorbis comments and embedded picture metadata', async (t) => {
  const { baseUrl, dirs, logs } = await makeFixture(t);
  const artwork = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x00, 0x00, 0xff, 0xd9]);
  const comments = flacVorbisBlock([
    'TITLE=FLAC Track', 'ARTIST=FLAC Artist', 'ALBUM=FLAC Album',
    'ALBUMARTIST=FLAC Album Artist', 'TRACKNUMBER=7', 'DISCNUMBER=1',
    'DATE=2023', 'GENRE=Ambient',
  ]);
  const picture = flacPictureBlock(artwork);
  const file = Buffer.concat([
    Buffer.from('fLaC', 'ascii'),
    flacMetadataHeader(4, comments),
    flacMetadataHeader(6, picture, true),
    Buffer.from('flac-audio-frames'),
  ]);
  await fs.promises.writeFile(path.join(dirs.music, 'FLAC Track.flac'), file);

  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const library = await (await fetch(`${baseUrl}/api/v1/library`, { headers })).json();
  const song = library.tracks.find((item) => item.fileName === 'FLAC Track.flac');
  assert.equal(song.title, 'FLAC Track');
  assert.equal(song.artist, 'FLAC Artist');
  assert.equal(song.album, 'FLAC Album');
  assert.equal(song.albumArtist, 'FLAC Album Artist');
  assert.equal(song.trackNumber, 7);
  assert.equal(song.discNumber, 1);
  assert.equal(song.year, 2023);
  assert.equal(song.genre, 'Ambient');
  assert.ok(song.artworkPath);

  const artResponse = await fetch(`${baseUrl}${song.artworkPath}`, { headers });
  assert.equal(artResponse.status, 200);
  assert.deepEqual(Buffer.from(await artResponse.arrayBuffer()), artwork);
});

function mp4Atom(type, payload) {
  const header = Buffer.alloc(8);
  header.writeUInt32BE(8 + payload.length, 0);
  header.write(type, 4, 4, 'latin1');
  return Buffer.concat([header, payload]);
}

function mp4Data(value, dataType = 1) {
  const fields = Buffer.alloc(8);
  fields.writeUInt32BE(dataType, 0);
  return mp4Atom('data', Buffer.concat([fields, value]));
}

function mp4TextItem(type, value) {
  return mp4Atom(type, mp4Data(Buffer.from(value, 'utf8')));
}

test('reads M4A/MP4 iTunes atoms and embedded cover artwork', async (t) => {
  const { baseUrl, dirs, logs } = await makeFixture(t);
  const artwork = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x00, 0x00, 0xff, 0xd9]);
  const trackData = Buffer.alloc(8);
  trackData.writeUInt16BE(5, 2);
  trackData.writeUInt16BE(12, 4);
  const items = Buffer.concat([
    mp4TextItem('\u00a9nam', 'M4A Embedded Title'),
    mp4TextItem('\u00a9ART', 'M4A Artist'),
    mp4TextItem('\u00a9alb', 'M4A Album'),
    mp4TextItem('aART', 'M4A Album Artist'),
    mp4TextItem('\u00a9day', '2021-10-15'),
    mp4TextItem('\u00a9gen', 'Pop'),
    mp4Atom('trkn', mp4Data(trackData, 0)),
    mp4Atom('covr', mp4Data(artwork, 13)),
  ]);
  const ilst = mp4Atom('ilst', items);
  const meta = mp4Atom('meta', Buffer.concat([Buffer.alloc(4), ilst]));
  const moov = mp4Atom('moov', mp4Atom('udta', meta));
  const ftyp = mp4Atom('ftyp', Buffer.from('M4A '));
  await fs.promises.writeFile(path.join(dirs.music, 'Tagged.m4a'), Buffer.concat([ftyp, moov, Buffer.from('audio payload')]));

  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const library = await (await fetch(`${baseUrl}/api/v1/library`, { headers })).json();
  const song = library.tracks.find((item) => item.fileName === 'Tagged.m4a');
  assert.equal(song.title, 'M4A Embedded Title');
  assert.equal(song.artist, 'M4A Artist');
  assert.equal(song.album, 'M4A Album');
  assert.equal(song.albumArtist, 'M4A Album Artist');
  assert.equal(song.trackNumber, 5);
  assert.equal(song.trackTotal, 12);
  assert.equal(song.year, 2021);
  assert.equal(song.genre, 'Pop');
  const artResponse = await fetch(`${baseUrl}${song.artworkPath}`, { headers });
  assert.equal(artResponse.status, 200);
  assert.deepEqual(Buffer.from(await artResponse.arrayBuffer()), artwork);
});

test('reads Ogg Vorbis comments and base64 embedded picture metadata', async (t) => {
  const { baseUrl, dirs, logs } = await makeFixture(t);
  const artwork = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x00, 0x00, 0xff, 0xd9]);
  const picture = flacPictureBlock(artwork);
  const comments = flacVorbisBlock([
    'TITLE=Ogg Title', 'ARTIST=Ogg Artist', 'ALBUM=Ogg Album',
    `METADATA_BLOCK_PICTURE=${picture.toString('base64')}`,
  ]);
  const identification = Buffer.concat([Buffer.from([1]), Buffer.from('vorbis'), Buffer.alloc(23)]);
  const commentPacket = Buffer.concat([Buffer.from([3]), Buffer.from('vorbis'), comments]);
  assert.ok(identification.length < 255 && commentPacket.length < 255);
  const pageHeader = Buffer.alloc(27);
  pageHeader.write('OggS', 0, 4, 'ascii');
  pageHeader[26] = 2;
  const lacing = Buffer.from([identification.length, commentPacket.length]);
  await fs.promises.writeFile(path.join(dirs.music, 'Tagged.ogg'), Buffer.concat([pageHeader, lacing, identification, commentPacket, Buffer.from('ogg audio payload')]));

  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const library = await (await fetch(`${baseUrl}/api/v1/library`, { headers })).json();
  const song = library.tracks.find((item) => item.fileName === 'Tagged.ogg');
  assert.equal(song.title, 'Ogg Title');
  assert.equal(song.artist, 'Ogg Artist');
  assert.equal(song.album, 'Ogg Album');
  assert.ok(song.artworkPath);
  const artResponse = await fetch(`${baseUrl}${song.artworkPath}`, { headers });
  assert.equal(artResponse.status, 200);
  assert.deepEqual(Buffer.from(await artResponse.arrayBuffer()), artwork);
});


test('infers missing artist and album tags from Artist/Album folder structure', async (t) => {
  const { baseUrl, dirs, logs } = await makeFixture(t);
  const albumDirectory = path.join(dirs.music, 'Folder Artist', 'Folder Album');
  await fs.promises.mkdir(albumDirectory, { recursive: true });
  await fs.promises.writeFile(path.join(albumDirectory, 'Folder Track.mp3'), Buffer.from('untagged audio content'));

  const paired = await pair(baseUrl, logs);
  const headers = { authorization: `Bearer ${paired.token}` };
  const library = await (await fetch(`${baseUrl}/api/v1/library`, { headers })).json();
  const song = library.tracks.find((item) => item.fileName === 'Folder Track.mp3');
  assert.equal(song.title, 'Folder Track');
  assert.equal(song.artist, 'Folder Artist');
  assert.equal(song.album, 'Folder Album');
  assert.equal(song.albumArtist, 'Folder Artist');
});
