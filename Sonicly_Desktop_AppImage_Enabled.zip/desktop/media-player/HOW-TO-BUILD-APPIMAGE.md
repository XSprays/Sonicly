# Build Sonicly for Linux (AppImage)

This is the same Sonicly Electron desktop project used for the Windows installer. The AppImage target packages the existing renderer, player, lyrics, Veylara visualizer, Discord Rich Presence, and dedicated-server client into one portable Linux application.

## Build on Linux

Use a native Linux x86_64 machine for the most reliable AppImage build (the target is x64, matching the Intel/AMD desktop build). Install Node.js 22 or newer, then open a terminal in this folder—the folder containing `package.json`—and run:

```bash
npm install
npm run appimage
```

The Electron Builder `beforePack` hook builds the desktop renderer and copies it into `desktop-dist`. The AppImage is written to `release/`, with a name similar to `Sonicly-1.0.0-Linux-x64.AppImage`.

Make it executable and launch it:

```bash
chmod +x release/Sonicly-*-Linux-x64.AppImage
./release/Sonicly-*-Linux-x64.AppImage
```

## CachyOS / Arch notes

- AppImage is a single portable file; it does not install Sonicly system-wide.
- If launching reports that `libfuse.so.2` is missing, install the FUSE 2 compatibility package (`fuse2`) from your distribution's repositories, then try again.
- For dedicated-server pairing, Sonicly uses Electron `safeStorage`. On Linux it requires a working desktop keyring such as KWallet (KDE Plasma) or GNOME Keyring. Sonicly will refuse to save a server bearer token when Electron selects the insecure `basic_text` fallback.
- The app's local library and playback features do not require a keyring; the keyring requirement applies to securely saving a dedicated-server pairing token.

## Windows build remains available

The existing Windows installer script is unchanged:

```bash
npm install
npm run exe
```

## Troubleshooting

- **AppImage won't launch:** ensure the file is executable (`chmod +x ...`). If FUSE 2 is unavailable, use your distribution's FUSE 2 compatibility package.
- **Server pairing cannot save:** unlock/enable KWallet or GNOME Keyring and pair again. Do not disable the secure-storage check or store the bearer token in plain text.
- **Build fails during native packaging:** run the build on Linux rather than attempting to cross-package an AppImage from Windows.
