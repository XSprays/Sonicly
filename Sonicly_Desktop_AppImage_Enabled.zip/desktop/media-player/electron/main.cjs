const { app, BrowserWindow, shell, ipcMain, dialog, nativeImage, safeStorage } = require("electron");
const mediaMeta = require("./media-meta.cjs");
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const os = require("node:os");
const { Readable } = require("node:stream");

let discordClient = null;
let discordClientId = "";
let discordRpcModule = null;
let discordStatus = { state: "disconnected", message: "Discord is not connected." };

const MEDIA_TOKEN = crypto.randomBytes(32).toString("hex");
const MOBILE_PORT = 47831;
let mobileServer = null;
let mobileServerPort = null;
let serverOrigin = "";
const mobileFiles = new Map();
const pendingMobilePairs = new Map();
const pairRateLimits = new Map();
let mobileHostId = "";
let pairingPopupWindow = null;
function mobileDevicesFile() { return path.join(app.getPath("userData"), "sonicly-paired-devices.json"); }
function readMobileDevices() {
  try { const d = JSON.parse(fs.readFileSync(mobileDevicesFile(), "utf8")); if (d.hostId) mobileHostId = d.hostId; return Array.isArray(d.devices) ? d.devices : []; } catch { return []; }
}
function writeMobileDevices(devices) {
  fs.mkdirSync(path.dirname(mobileDevicesFile()), { recursive: true });
  fs.writeFileSync(mobileDevicesFile(), JSON.stringify({ hostId: getMobileHostId(), devices }, null, 2), { mode: 0o600 });
}
function getMobileHostId() {
  if (!mobileHostId) { try { const d = JSON.parse(fs.readFileSync(mobileDevicesFile(), "utf8")); mobileHostId = d.hostId || ""; } catch {} }
  if (!mobileHostId) mobileHostId = crypto.randomUUID();
  return mobileHostId;
}
function challengeDeviceName(value) {
  return String(value || "Android device").slice(0, 80);
}
function showPairingPopup({ code, deviceName, expiresAt }) {
  if (pairingPopupWindow && !pairingPopupWindow.isDestroyed()) pairingPopupWindow.close();
  const parent = BrowserWindow.getAllWindows().find((win) => !win.isDestroyed()) || undefined;
  const popup = new BrowserWindow({
    width: 440,
    height: 500,
    minWidth: 400,
    minHeight: 460,
    resizable: false,
    minimizable: false,
    maximizable: false,
    title: "Pair a device · Sonicly",
    backgroundColor: "#0b1020",
    autoHideMenuBar: true,
    show: false,
    ...(parent ? { parent, modal: true } : {}),
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true }
  });
  pairingPopupWindow = popup;
  const safeName = deviceName.replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Pair Sonicly</title>
  <style>
  *{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at 12% 0%,#263d78 0%,transparent 48%),radial-gradient(ellipse at 100% 100%,#45266f 0%,transparent 52%),#090e1d;color:#f4f6ff;font:14px/1.5 Segoe UI,Arial,sans-serif;display:grid;place-items:center;padding:22px}
  .card{width:100%;border:1px solid #35436a;background:linear-gradient(145deg,rgba(20,31,58,.97),rgba(13,17,36,.98));border-radius:22px;padding:28px 26px 22px;box-shadow:0 24px 70px #0009;text-align:center}
  .brand{font-weight:700;letter-spacing:.16em;text-transform:uppercase;font-size:12px;color:#9eafff}.orb{width:54px;height:54px;margin:0 auto 12px;border-radius:17px;background:linear-gradient(135deg,#3285ff,#8b5cf6);display:grid;place-items:center;font-size:25px;box-shadow:0 8px 30px #5a68ff55}
  h1{font-size:23px;margin:8px 0 5px}.sub{color:#aab6d3;margin:0 auto 20px;max-width:320px}
  .device{display:inline-flex;align-items:center;gap:8px;padding:7px 12px;border:1px solid #3c4a70;border-radius:999px;background:#ffffff08;color:#dce5ff}
  .code{margin:20px 0 12px;padding:18px 10px;border-radius:16px;background:#080d1b;border:1px solid #45558a;font-size:48px;font-weight:750;letter-spacing:.28em;font-variant-numeric:tabular-nums;color:#fff;text-shadow:0 0 25px #7c8dff66}
  .hint{color:#9daac8;font-size:12px}.timer{margin:15px auto 18px;color:#b8c7ef;font-variant-numeric:tabular-nums}.bar{height:5px;background:#27324e;border-radius:9px;overflow:hidden}.fill{height:100%;width:100%;background:linear-gradient(90deg,#3285ff,#9b62ff);transition:width 1s linear}
  button{border:0;border-radius:11px;padding:11px 20px;background:#273451;color:#e7edff;font-weight:600;cursor:pointer}button:hover{background:#344465}
  .safe{margin:16px 0 0;color:#8492b5;font-size:11px}
  </style></head><body><main class="card"><div class="orb">S</div><div class="brand">SONICLY COMPANION</div><h1>Pair a new device</h1><p class="sub">Enter this verification code in your Sonicly app to securely link this device.</p><div class="device">◉ &nbsp;${safeName}</div><div class="code">${code}</div><div class="hint">This code is single-use and expires automatically.</div><div class="timer" id="timer">Expires in 02:00</div><div class="bar"><div class="fill" id="fill"></div></div><p class="safe">Only enter this code on a device you trust. Each device receives its own revocable connection.</p><button style="margin-top:18px" onclick="window.close()">Close</button></main>
  <script>const end=${Number(expiresAt)};function tick(){const left=Math.max(0,Math.ceil((end-Date.now())/1000));document.getElementById('timer').textContent=left?('Expires in '+String(Math.floor(left/60)).padStart(2,'0')+':'+String(left%60).padStart(2,'0')):'Code expired';document.getElementById('fill').style.width=(left/120*100)+'%';if(!left){document.querySelector('.code').textContent='EXPIRED';document.querySelector('.hint').textContent='Request a new code from your device.';clearInterval(t);setTimeout(()=>window.close(),2500)}}tick();const t=setInterval(tick,1000);</script></body></html>`;
  popup.once("ready-to-show", () => { if (!popup.isDestroyed()) popup.show(); });
  popup.on("closed", () => { if (pairingPopupWindow === popup) pairingPopupWindow = null; });
  popup.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(html));
}
function readRequestJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => { body += chunk; if (body.length > 16384) { reject(new Error("Request too large")); req.destroy(); } });
    req.on("end", () => { try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error("Invalid JSON")); } });
    req.on("error", reject);
  });
}
function rateAllowed(key) {
  const now = Date.now(), e = pairRateLimits.get(key) || { start: now, count: 0 };
  if (now - e.start > 60000) { e.start = now; e.count = 0; }
  e.count++; pairRateLimits.set(key, e); return e.count <= 12;
}
function mobileAuthorized(req) {
  const h = req.headers.authorization || "";
  const supplied = h.startsWith("Bearer ") ? h.slice(7) : (req.headers["x-sonicly-token"] || "");
  if (typeof supplied !== "string" || supplied.length < 32) return false;
  const devices = readMobileDevices();
  const d = devices.find(x => x.token && x.token.length === supplied.length && crypto.timingSafeEqual(Buffer.from(x.token), Buffer.from(supplied)));
  if (!d) return false;
  d.lastSeenAt = Date.now(); writeMobileDevices(devices); return true;
}
const AUDIO = new Set(["mp3", "wav", "ogg", "oga", "opus", "m4a", "aac", "flac", "weba"]);
const VIDEO = new Set(["mp4", "m4v", "webm", "mkv", "avi", "mov", "mpeg", "mpg", "ogv"]);
const IMAGE = new Set(["jpg", "jpeg", "png", "webp", "gif", "bmp", "avif"]);
const MEDIA_EXT = new Set([...AUDIO, ...VIDEO, ...IMAGE]);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
  ".ogg": "audio/ogg",
  ".oga": "audio/ogg",
  ".opus": "audio/ogg",
  ".aac": "audio/aac",
  ".weba": "audio/webm",
  ".flac": "audio/flac",
  ".m4a": "audio/mp4",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".mkv": "video/x-matroska",
  ".mov": "video/quicktime",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json",
};


function networkAddresses() {
  const found = [];
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (entry && entry.family === "IPv4" && !entry.internal) found.push(entry.address);
    }
  }
  return [...new Set(found)];
}

function mobileInfo() {
  return {
    running: Boolean(mobileServerPort),
    port: mobileServerPort,
    hostId: getMobileHostId(),
    pairedDevices: readMobileDevices().map(({ token, ...device }) => device),
    addresses: networkAddresses(),
    baseUrls: networkAddresses().map((address) => `http://${address}:${mobileServerPort || MOBILE_PORT}`),
  };
}



async function buildMobileLibrary() {
  const output = [];
  mobileFiles.clear();
  const candidates = [];
  const seen = new Set();
  for (const folder of readLibrary()) {
    let files = [];
    try { files = await scanFolder(folder.path); } catch { continue; }
    for (const file of files) {
      const absolute = path.resolve(folder.path, file.relPath.split("/").join(path.sep));
      if (seen.has(absolute.toLowerCase())) continue;
      seen.add(absolute.toLowerCase());
      candidates.push({ absolute, relPath: file.relPath, folderName: folder.name, size: file.size, modifiedAt: file.modifiedAt });
    }
  }
  // Files selected through the desktop app's Add files control or drag/drop.
  for (const absolute of readMobileFiles()) {
    const key = absolute.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    try {
      const stat = fs.statSync(absolute);
      candidates.push({ absolute, relPath: path.basename(absolute), folderName: "Added files", size: stat.size, modifiedAt: stat.mtimeMs });
    } catch { /* skip removed files */ }
  }
  const playable = [];
  for (const file of candidates) {
    const ext = path.extname(file.relPath).slice(1).toLowerCase();
    const isAudio = AUDIO.has(ext);
    const isVideo = VIDEO.has(ext);
    if (!isAudio && !isVideo) continue;
    if (!allowedFile(file.absolute)) continue;
    playable.push({ file, isVideo });
  }
  // Read embedded tags (title/artist/album/track no./artwork presence) with bounded concurrency.
  // Results are cached by path+mtime+size, so only the first scan is slow.
  const metas = new Array(playable.length);
  let cursor = 0;
  const workers = Array.from({ length: Math.min(8, playable.length) }, async () => {
    while (cursor < playable.length) {
      const index = cursor++;
      const { file } = playable[index];
      try { metas[index] = await mediaMeta.readMeta(file.absolute, { mtimeMs: file.modifiedAt, size: file.size }); }
      catch { metas[index] = null; }
    }
  });
  await Promise.all(workers);
  playable.forEach(({ file, isVideo }, index) => {
    const meta = metas[index] || {};
    const id = crypto.createHash("sha256").update(file.absolute.toLowerCase()).digest("hex").slice(0, 24);
    mobileFiles.set(id, file.absolute);
    const base = path.basename(file.relPath, path.extname(file.relPath));
    const parts = file.relPath.split("/");
    // Untagged files: fall back to the containing folder as the album so albums still group sensibly.
    const folderAlbum = !isVideo && parts.length > 1 ? parts[parts.length - 2] : "";
    output.push({
      id,
      title: meta.title || base,
      artist: meta.artist || meta.albumArtist || "",
      album: meta.album || folderAlbum,
      albumArtist: meta.albumArtist || "",
      trackNumber: meta.trackNumber || 0,
      discNumber: meta.discNumber || 0,
      year: meta.year || "",
      fileName: path.basename(file.relPath),
      folder: file.folderName,
      path: file.relPath,
      size: file.size,
      modifiedAt: file.modifiedAt,
      mime: MIME[path.extname(file.relPath).toLowerCase()] || (isVideo ? "video/mp4" : "audio/mpeg"),
      mediaType: isVideo ? "video" : "audio",
      streamPath: `/api/v1/stream/${id}`,
      // Videos always advertise a thumbnail URL (generated on demand); audio only when art exists.
      artworkPath: meta.hasArt || isVideo ? `/api/v1/artwork/${id}` : "",
    });
  });
  output.sort((a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: "base" }));
  return output;
}

// ---- artwork for the mobile API ----
const artworkCache = new Map(); // id -> { bytes, mime } | null  (small, size-limited)
function cacheArtwork(id, value) {
  if (artworkCache.size >= 400) artworkCache.delete(artworkCache.keys().next().value);
  artworkCache.set(id, value);
}
function shrinkImage(art, maxEdge = 640) {
  // Embedded covers can be several MB; phones only need tile-sized images.
  try {
    if (art.bytes.length < 200 * 1024) return art;
    const image = nativeImage.createFromBuffer(art.bytes);
    if (image.isEmpty()) return art;
    const { width, height } = image.getSize();
    if (Math.max(width, height) <= maxEdge && art.bytes.length < 600 * 1024) return art;
    const scale = Math.min(1, maxEdge / Math.max(width, height));
    const resized = scale < 1 ? image.resize({ width: Math.round(width * scale), height: Math.round(height * scale), quality: "good" }) : image;
    return { bytes: resized.toJPEG(85), mime: "image/jpeg" };
  } catch { return art; }
}
async function mobileArtwork(id, filePath) {
  if (artworkCache.has(id)) return artworkCache.get(id);
  let art = await mediaMeta.readArtwork(filePath).catch(() => null);
  if (!art) {
    // Videos (and art-less audio): ask the OS for a thumbnail. Works on Windows/macOS using the
    // system codecs, so formats Windows can preview in Explorer get a thumbnail.
    const ext = path.extname(filePath).slice(1).toLowerCase();
    if (VIDEO.has(ext) && typeof nativeImage.createThumbnailFromPath === "function") {
      try {
        const thumb = await nativeImage.createThumbnailFromPath(filePath, { width: 480, height: 480 });
        if (thumb && !thumb.isEmpty()) art = { bytes: thumb.toJPEG(85), mime: "image/jpeg" };
      } catch { /* codec/shell can't preview this file */ }
    }
  }
  if (art) art = shrinkImage(art);
  cacheArtwork(id, art || null);
  return art || null;
}

function startMobileServer() {
  if (mobileServer) return Promise.resolve(mobileServerPort);
  mobileServer = http.createServer(async (req, res) => {
    const origin = req.headers.origin;
    res.setHeader("access-control-allow-origin", origin || "*");
    res.setHeader("access-control-allow-headers", "authorization, content-type, x-sonicly-token, range");
    res.setHeader("access-control-allow-methods", "GET, HEAD, POST, DELETE, OPTIONS");
    res.setHeader("vary", "origin");
    if (req.method === "OPTIONS") { res.writeHead(204).end(); return; }
    let url;
    try { url = new URL(req.url || "/", "http://127.0.0.1"); } catch { res.writeHead(400).end(); return; }
    if (!url.pathname.startsWith("/api/v1/")) { res.writeHead(404).end(); return; }
    // Discovery intentionally reveals no pairing secret; the user must confirm pairing with the code shown in desktop settings.
    if (url.pathname === "/api/v1/discover" && req.method === "GET") {
      res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
      res.end(JSON.stringify({ name: "Sonicly", version: app.getVersion(), protocol: 1, hostId: getMobileHostId(), port: mobileServerPort || MOBILE_PORT, pairingRequired: true, hostName: os.hostname() }));
      return;
    }
    if (url.pathname === "/api/v1/pair/request" && req.method === "POST") {
      const ip = req.socket.remoteAddress || "unknown";
      if (!rateAllowed(ip)) { res.writeHead(429).end(JSON.stringify({ error: "rate_limited" })); return; }
      try {
        const body = await readRequestJson(req), challengeId = crypto.randomUUID();
        const code = String(crypto.randomInt(0, 10000)).padStart(4, "0");
        pendingMobilePairs.set(challengeId, { code, expiresAt: Date.now() + 120000, attempts: 0, name: String(body.deviceName || "Android device").slice(0, 80), platform: String(body.platform || "android").slice(0, 24) });
        for (const [id, value] of pendingMobilePairs) if (value.expiresAt < Date.now()) pendingMobilePairs.delete(id);
        showPairingPopup({ code, deviceName: challengeDeviceName(body.deviceName), expiresAt: Date.now() + 120000 });
        res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
        res.end(JSON.stringify({ challengeId, expiresIn: 120 }));
      } catch { res.writeHead(400).end(JSON.stringify({ error: "invalid_request" })); }
      return;
    }
    if (url.pathname === "/api/v1/pair/complete" && req.method === "POST") {
      const ip = req.socket.remoteAddress || "unknown";
      if (!rateAllowed(ip)) { res.writeHead(429).end(JSON.stringify({ error: "rate_limited" })); return; }
      try {
        const body = await readRequestJson(req), id = String(body.challengeId || ""), challenge = pendingMobilePairs.get(id);
        if (!challenge || challenge.expiresAt < Date.now()) { pendingMobilePairs.delete(id); res.writeHead(410).end(JSON.stringify({ error: "challenge_expired" })); return; }
        challenge.attempts++;
        if (challenge.attempts > 5) { pendingMobilePairs.delete(id); res.writeHead(429).end(JSON.stringify({ error: "too_many_attempts" })); return; }
        if (String(body.code || "") !== challenge.code) { res.writeHead(403).end(JSON.stringify({ error: "invalid_code" })); return; }
        pendingMobilePairs.delete(id);
        const devices = readMobileDevices(), deviceId = crypto.randomUUID(), token = crypto.randomBytes(32).toString("hex");
        devices.push({ deviceId, name: challenge.name, platform: challenge.platform, token, pairedAt: Date.now(), lastSeenAt: Date.now() });
        writeMobileDevices(devices);
        res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
        res.end(JSON.stringify({ deviceId, token, hostId: getMobileHostId(), hostName: os.hostname() }));
      } catch { res.writeHead(400).end(JSON.stringify({ error: "invalid_request" })); }
      return;
    }
    if (url.pathname === "/api/v1/pair/revoke" && req.method === "POST") {
      if (!mobileAuthorized(req)) { res.writeHead(401).end(); return; }
      try {
        const body = await readRequestJson(req), devices = readMobileDevices();
        writeMobileDevices(devices.filter(d => d.deviceId !== String(body.deviceId || "")));
        res.writeHead(200).end(JSON.stringify({ ok: true }));
      } catch { res.writeHead(400).end(); }
      return;
    }
    if (!mobileAuthorized(req)) {
      res.writeHead(401, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
      res.end(JSON.stringify({ error: "unauthorized" }));
      return;
    }
    if (url.pathname === "/api/v1/status") {
      res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
      res.end(JSON.stringify({ name: "Sonicly", version: app.getVersion(), protocol: 1, streaming: true }));
      return;
    }
    if (url.pathname === "/api/v1/library") {
      try {
        const tracks = await buildMobileLibrary();
        res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
        res.end(JSON.stringify({ tracks, count: tracks.length }));
      } catch (error) {
        res.writeHead(500, { "content-type": "application/json; charset=utf-8" });
        res.end(JSON.stringify({ error: error && error.message ? error.message : "library_scan_failed" }));
      }
      return;
    }
    const artworkMatch = /^\/api\/v1\/artwork\/([a-f0-9]{24})$/.exec(url.pathname);
    if (artworkMatch) {
      const filePath = mobileFiles.get(artworkMatch[1]);
      if (!filePath || !allowedFile(filePath)) { res.writeHead(404).end(); return; }
      try {
        const art = await mobileArtwork(artworkMatch[1], filePath);
        if (!art) { res.writeHead(404, { "cache-control": "private, max-age=300" }).end(); return; }
        res.writeHead(200, { "content-type": art.mime, "content-length": art.bytes.length, "cache-control": "private, max-age=3600", "x-content-type-options": "nosniff" });
        res.end(req.method === "HEAD" ? undefined : art.bytes);
      } catch { if (!res.headersSent) res.writeHead(500); res.end(); }
      return;
    }
    const streamMatch = /^\/api\/v1\/stream\/([a-f0-9]{24})$/.exec(url.pathname);
    if (streamMatch) {
      const filePath = mobileFiles.get(streamMatch[1]);
      if (!filePath || !allowedFile(filePath)) { res.writeHead(404).end(); return; }
      try { sendFile(req, res, filePath); } catch { if (!res.headersSent) res.writeHead(404); res.end(); }
      return;
    }
    res.writeHead(404).end();
  });
  return new Promise((resolve, reject) => {
    mobileServer.once("error", (error) => {
      mobileServer = null;
      if (error && error.code === "EADDRINUSE") reject(new Error(`Sonicly mobile streaming port ${MOBILE_PORT} is already in use.`));
      else reject(error);
    });
    mobileServer.listen(MOBILE_PORT, "0.0.0.0", () => {
      mobileServerPort = MOBILE_PORT;
      resolve(MOBILE_PORT);
    });
  });
}

function candidates() {
  const exeDir = path.dirname(process.execPath);
  return [
    path.join(process.resourcesPath || "", "desktop-dist"),
    path.join(process.resourcesPath || "", "app", "desktop-dist"),
    path.join(__dirname, "..", "desktop-dist"),
    path.join(exeDir, "resources", "desktop-dist"),
    path.join(exeDir, "desktop-dist"),
  ];
}

function rendererRoot() {
  for (const dir of candidates()) {
    if (dir && fs.existsSync(path.join(dir, "index.html"))) return dir;
  }
  return candidates()[0];
}

function libraryFile() {
  return path.join(app.getPath("userData"), "library.json");
}

function readLibrary() {
  try {
    const parsed = JSON.parse(fs.readFileSync(libraryFile(), "utf8"));
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item.path === "string" && typeof item.id === "string");
  } catch {
    return [];
  }
}

// Dedicated-server credentials are encrypted by the OS credential store.
// The renderer only receives the token through a narrow IPC method; media
// requests are proxied by this main process so tokens never appear in URLs.
function remoteServerFile() {
  return path.join(app.getPath("userData"), "remote-server.json");
}

function normalizeRemoteBaseUrl(value) {
  if (typeof value !== "string" || !value.trim()) throw new Error("Enter a valid Sonicly server address.");
  let url;
  try { url = new URL(value.trim()); } catch { throw new Error("Enter a valid Sonicly server address."); }
  if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("Sonicly servers must use HTTP or HTTPS.");
  if (url.username || url.password || url.search || url.hash) throw new Error("Remove credentials, query strings, and fragments from the server address.");
  return url.toString().replace(/\/+$/, "");
}

function secureTokenStorageAvailable() {
  if (!safeStorage.isEncryptionAvailable()) return false;
  if (process.platform === "linux") {
    // Electron may report encryption as available while using its weak basic_text
    // fallback. Never persist a dedicated-server bearer token with that backend.
    const backend = typeof safeStorage.getSelectedStorageBackend === "function"
      ? safeStorage.getSelectedStorageBackend()
      : "unknown";
    if (backend === "basic_text" || backend === "unknown") return false;
  }
  return true;
}

function secureTokenStorageError() {
  if (process.platform === "linux") {
    return "A Linux desktop keyring is required to securely save the Sonicly server token. Enable KWallet or GNOME Keyring, then reconnect and pair this desktop again.";
  }
  if (process.platform === "darwin") {
    return "macOS Keychain is unavailable. Unlock Keychain, then reconnect and pair this desktop again.";
  }
  return "Windows secure credential storage is unavailable. The saved server token cannot be decrypted on this computer.";
}

function readRemoteServer() {
  let stored;
  try { stored = JSON.parse(fs.readFileSync(remoteServerFile(), "utf8")); }
  catch (error) {
    if (error && error.code === "ENOENT") return null;
    throw new Error("The saved Sonicly server connection could not be read.");
  }
  if (!stored || typeof stored.baseUrl !== "string") return null;
  const baseUrl = normalizeRemoteBaseUrl(stored.baseUrl);
  let token = "";
  if (typeof stored.encryptedToken === "string" && stored.encryptedToken) {
    if (!secureTokenStorageAvailable()) throw new Error(secureTokenStorageError());
    try { token = safeStorage.decryptString(Buffer.from(stored.encryptedToken, "base64")); }
    catch { throw new Error("The saved server token could not be decrypted. Reconnect and pair this desktop again."); }
  }
  return {
    baseUrl,
    token,
    deviceId: typeof stored.deviceId === "string" ? stored.deviceId : "",
    hostId: typeof stored.hostId === "string" ? stored.hostId : "",
  };
}

function writeRemoteServer(connection) {
  if (!connection || typeof connection !== "object" || typeof connection.token !== "string" || connection.token.length < 32) {
    throw new Error("Invalid Sonicly server connection details.");
  }
  const baseUrl = normalizeRemoteBaseUrl(connection.baseUrl);
  if (!secureTokenStorageAvailable()) throw new Error(secureTokenStorageError());
  const encryptedToken = safeStorage.encryptString(connection.token).toString("base64");
  const file = remoteServerFile();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify({
    baseUrl: baseUrl.slice(0, 2048),
    encryptedToken,
    deviceId: typeof connection.deviceId === "string" ? connection.deviceId.slice(0, 128) : "",
    hostId: typeof connection.hostId === "string" ? connection.hostId.slice(0, 128) : "",
  }, null, 2), { mode: 0o600 });
  try { fs.renameSync(temp, file); }
  catch (error) { try { fs.unlinkSync(temp); } catch {} throw error; }
}

function clearRemoteServer() {
  try { fs.unlinkSync(remoteServerFile()); }
  catch (error) { if (!error || error.code !== "ENOENT") throw error; }
}

// Explicitly added single files are part of the desktop library too. Keep only
// their canonical paths so the authenticated mobile API can expose the same items.
function mobileFilesFile() {
  return path.join(app.getPath("userData"), "mobile-files.json");
}
function readMobileFiles() {
  try {
    const data = JSON.parse(fs.readFileSync(mobileFilesFile(), "utf8"));
    if (!Array.isArray(data)) return [];
    return data.filter((value) => typeof value === "string").filter((value) => {
      try { return fs.statSync(value).isFile(); } catch { return false; }
    });
  } catch {
    return [];
  }
}
function writeMobileFiles(values) {
  fs.mkdirSync(path.dirname(mobileFilesFile()), { recursive: true });
  fs.writeFileSync(mobileFilesFile(), JSON.stringify([...new Set(values)].slice(0, 8000), null, 2));
}
function registerMobileFiles(values) {
  if (!Array.isArray(values)) throw new Error("Expected a list of selected media files.");
  const registered = new Set(readMobileFiles());
  for (const value of values.slice(0, 2000)) {
    if (typeof value !== "string" || !value.trim()) continue;
    try {
      const absolute = fs.realpathSync(value);
      if (!fs.statSync(absolute).isFile()) continue;
      const ext = path.extname(absolute).slice(1).toLowerCase();
      if (!AUDIO.has(ext) && !VIDEO.has(ext)) continue;
      registered.add(absolute);
    } catch {
      // A file may have been removed between selection and registration.
    }
  }
  writeMobileFiles([...registered]);
  return registered.size;
}

function writeLibrary(folders) {
  fs.mkdirSync(path.dirname(libraryFile()), { recursive: true });
  fs.writeFileSync(libraryFile(), JSON.stringify(folders, null, 2));
}

function folderId(folderPath) {
  return "disk_" + crypto.createHash("sha1").update(path.resolve(folderPath).toLowerCase()).digest("hex").slice(0, 16);
}

function isUnderRoot(filePath, root) {
  const resolved = path.resolve(filePath);
  const base = path.resolve(root);
  return resolved === base || resolved.startsWith(base + path.sep);
}

function allowedFile(filePath) {
  let resolved;
  try {
    resolved = fs.realpathSync(filePath);
  } catch {
    return false;
  }
  const insideLinkedFolder = readLibrary().some((folder) => {
    try {
      return isUnderRoot(resolved, fs.realpathSync(folder.path));
    } catch {
      return false;
    }
  });
  return insideLinkedFolder || readMobileFiles().includes(resolved);
}

async function scanFolder(folderPath) {
  const root = await fs.promises.realpath(folderPath);
  const files = [];
  async function walk(dir) {
    if (files.length >= 8000) return;
    let entries = [];
    try {
      entries = await fs.promises.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (files.length >= 8000) return;
      if (!entry.name || entry.name.startsWith(".")) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === "node_modules" || entry.name === "__MACOSX") continue;
        await walk(full);
        continue;
      }
      // Do not follow symlinks: libraries should only expose files physically inside the chosen tree.
      if (!entry.isFile()) continue;
      const ext = path.extname(entry.name).slice(1).toLowerCase();
      if (!MEDIA_EXT.has(ext)) continue;
      try {
        const stat = await fs.promises.stat(full);
        if (!stat.isFile() || !stat.size) continue;
        files.push({ relPath: path.relative(root, full).split(path.sep).join("/"), size: stat.size, modifiedAt: stat.mtimeMs });
      } catch {
        // Skip files that disappear or become unreadable during a scan.
      }
    }
  }
  await walk(root);
  return files;
}

function sendFile(req, res, filePath) {
  const stat = fs.statSync(filePath);
  const type = MIME[path.extname(filePath).toLowerCase()] || "application/octet-stream";
  const common = { "content-type": type, "accept-ranges": "bytes", "x-content-type-options": "nosniff", "cache-control": "private, max-age=60" };
  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405, { allow: "GET, HEAD" });
    res.end();
    return;
  }
  const range = req.headers.range;
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (!match || (!match[1] && !match[2])) {
      res.writeHead(416, { "content-range": `bytes */${stat.size}` });
      res.end();
      return;
    }
    let start;
    let end;
    if (!match[1]) {
      const suffix = Number(match[2]);
      if (!Number.isSafeInteger(suffix) || suffix <= 0) {
        res.writeHead(416, { "content-range": `bytes */${stat.size}` });
        res.end();
        return;
      }
      start = Math.max(0, stat.size - suffix);
      end = stat.size - 1;
    } else {
      start = Number(match[1]);
      end = match[2] ? Number(match[2]) : stat.size - 1;
    }
    if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || start >= stat.size || end < start) {
      res.writeHead(416, { "content-range": `bytes */${stat.size}` });
      res.end();
      return;
    }
    end = Math.min(end, stat.size - 1);
    res.writeHead(206, {
      ...common,
      "content-length": end - start + 1,
      "content-range": `bytes ${start}-${end}/${stat.size}`,
    });
    if (req.method === "HEAD") return res.end();
    fs.createReadStream(filePath, { start, end }).on("error", () => res.destroy()).pipe(res);
    return;
  }
  res.writeHead(200, { ...common, "content-length": stat.size });
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(filePath).on("error", () => res.destroy()).pipe(res);
}

function startServer(root) {
  const canonicalRoot = fs.realpathSync(root);
  const server = http.createServer(async (req, res) => {
    let url;
    try {
      url = new URL(req.url || "/", "http://127.0.0.1");
    } catch {
      res.writeHead(400).end();
      return;
    }
    if (url.pathname === "/remote-media") {
      if (req.method !== "GET" && req.method !== "HEAD") {
        res.writeHead(405, { allow: "GET, HEAD", "cache-control": "no-store" }).end();
        return;
      }
      const origin = req.headers.origin;
      if (origin && origin !== serverOrigin) {
        res.writeHead(403, { "cache-control": "no-store" }).end("forbidden");
        return;
      }
      const remotePath = url.searchParams.get("p") || "";
      if (!/^\/api\/v1\/(?:stream|photo|artwork)\/[a-f0-9]{24}$/i.test(remotePath)) {
        res.writeHead(400, { "cache-control": "no-store" }).end("invalid remote media path");
        return;
      }
      let saved;
      try { saved = readRemoteServer(); }
      catch { res.writeHead(503, { "cache-control": "no-store" }).end("saved server connection is unavailable"); return; }
      if (!saved || !saved.baseUrl || !saved.token) {
        res.writeHead(503, { "cache-control": "no-store" }).end("no paired Sonicly server");
        return;
      }
      const controller = new AbortController();
      res.once("close", () => { if (!res.writableEnded) controller.abort(); });
      try {
        const headers = { authorization: `Bearer ${saved.token}` };
        if (typeof req.headers.range === "string") headers.range = req.headers.range;
        const upstream = await fetch(`${saved.baseUrl}${remotePath}`, {
          method: req.method,
          headers,
          redirect: "manual",
          signal: controller.signal,
        });
        if (upstream.status >= 300 && upstream.status < 400) {
          res.writeHead(502, { "cache-control": "no-store" }).end("remote server redirects are not supported");
          return;
        }
        const responseHeaders = { "cache-control": "no-store", "x-content-type-options": "nosniff" };
        for (const name of ["content-type", "content-length", "content-range", "accept-ranges", "last-modified", "etag"]) {
          const value = upstream.headers.get(name);
          if (value) responseHeaders[name] = value;
        }
        res.writeHead(upstream.status, responseHeaders);
        if (req.method === "HEAD" || !upstream.body) { res.end(); return; }
        Readable.fromWeb(upstream.body).on("error", () => res.destroy()).pipe(res);
      } catch (error) {
        if (!res.headersSent) res.writeHead(502, { "cache-control": "no-store" });
        res.end(error && error.name === "TimeoutError" ? "remote media request timed out" : "could not reach remote media server");
      }
      return;
    }
    if (url.pathname === "/local-media") {
      const origin = req.headers.origin;
      const asked = url.searchParams.get("p") || "";
      const suppliedToken = url.searchParams.get("t") || "";
      const tokenMatches = suppliedToken.length === MEDIA_TOKEN.length && crypto.timingSafeEqual(Buffer.from(suppliedToken), Buffer.from(MEDIA_TOKEN));
      if (!tokenMatches || (origin && origin !== serverOrigin)) {
        res.writeHead(403, { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" });
        res.end("forbidden");
        return;
      }
      let filePath;
      try {
        filePath = fs.realpathSync(path.resolve(asked));
      } catch {
        filePath = "";
      }
      if (!asked || !filePath || !allowedFile(filePath) || !fs.statSync(filePath).isFile()) {
        res.writeHead(404, { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" });
        res.end("not found");
        return;
      }
      try {
        sendFile(req, res, filePath);
      } catch {
        if (!res.headersSent) res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
        res.end("not found");
      }
      return;
    }
    let pathname;
    try {
      pathname = decodeURIComponent(url.pathname);
    } catch {
      res.writeHead(400).end();
      return;
    }
    if (pathname === "/") pathname = "/index.html";
    const filePath = path.resolve(canonicalRoot, `.${pathname}`);
    let canonicalFile = "";
    try {
      canonicalFile = fs.realpathSync(filePath);
    } catch {
      // handled as a missing renderer asset below
    }
    const inside = canonicalFile && isUnderRoot(canonicalFile, canonicalRoot);
    const exists = inside && fs.statSync(canonicalFile).isFile();
    if (!exists) {
      const ext = path.extname(pathname).toLowerCase();
      if (ext && ext !== ".html") {
        res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
        res.end("not found");
        return;
      }
      const index = path.join(canonicalRoot, "index.html");
      if (!fs.existsSync(index)) {
        res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
        res.end("Sonicly files were not found.\nLooked in:\n" + candidates().join("\n"));
        return;
      }
      sendFile(req, res, index);
      return;
    }
    sendFile(req, res, canonicalFile);
  });
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = address && typeof address === "object" ? address.port : PREFERRED_PORT;
      serverOrigin = `http://127.0.0.1:${port}`;
      resolve(port);
    });
  });
}

async function clearDiscordPresence() {
  try {
    if (discordClient) await discordClient.clearActivity();
  } catch {
    /* Discord may have closed while the app was running. */
  }
}

async function disconnectDiscord() {
  await clearDiscordPresence();
  if (discordClient) {
    try { await discordClient.destroy(); } catch { /* ignore disconnect errors */ }
  }
  discordClient = null;
  discordClientId = "";
  discordStatus = { state: "disconnected", message: "Discord is not connected." };
}

async function ensureDiscordClient(clientId) {
  if (discordClient && discordClientId === clientId) return discordClient;
  await disconnectDiscord();
  if (!discordRpcModule) discordRpcModule = require("discord-rpc");
  discordRpcModule.register(clientId);
  discordStatus = { state: "connecting", message: "Connecting to the Discord desktop app…" };
  const client = new discordRpcModule.Client({ transport: "ipc" });
  try {
    await Promise.race([
      client.login({ clientId }),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Timed out connecting to Discord. Make sure the Discord desktop app is open.")), 10000)),
    ]);
    discordClient = client;
    discordClientId = clientId;
    discordStatus = { state: "connected", message: "Connected to Discord." };
    return client;
  } catch (error) {
    try { await client.destroy(); } catch { /* ignore cleanup errors */ }
    discordStatus = { state: "error", message: error && error.message ? error.message : "Discord connection failed." };
    throw error;
  }
}

function cleanPresenceText(value, max = 128) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

async function testDiscordConnection(clientId) {
  const id = cleanPresenceText(clientId, 32);
  if (!/^\d{15,25}$/.test(id)) {
    discordStatus = { state: "error", message: "Enter a valid Discord Application ID (15–25 digits)." };
    return { ok: false, ...discordStatus };
  }
  try {
    const client = await ensureDiscordClient(id);
    await client.setActivity({
      details: "Discord connection successful",
      state: "Sonicly is connected",
      type: 0,
      instance: false,
    });
    discordStatus = { state: "connected", message: "Connected! A test activity was sent to Discord." };
    return { ok: true, ...discordStatus };
  } catch (error) {
    discordStatus = { state: "error", message: error && error.message ? error.message : "Couldn't connect to Discord." };
    return { ok: false, ...discordStatus };
  }
}

async function updateDiscordPresence(presence) {
  if (!presence || typeof presence !== "object" || !presence.enabled) {
    await disconnectDiscord();
    return { ok: true, ...discordStatus };
  }
  const clientId = cleanPresenceText(presence.clientId, 32);
  const title = cleanPresenceText(presence.title);
  if (!/^\d{15,25}$/.test(clientId)) {
    await disconnectDiscord();
    discordStatus = { state: "error", message: "Enter a valid Discord Application ID (15–25 digits)." };
    return { ok: false, ...discordStatus };
  }
  if (!title) {
    await clearDiscordPresence();
    return { ok: true };
  }
  try {
    const client = await ensureDiscordClient(clientId);
    const artist = cleanPresenceText(presence.artist);
    const album = cleanPresenceText(presence.album);
    const playing = Boolean(presence.playing);
    const position = Math.max(0, Number(presence.position) || 0);
    const duration = Math.max(0, Number(presence.duration) || 0);
    const activity = {
      details: title,
      state: artist ? `${artist}${album ? ` · ${album}` : ""}` : (album || "Local music"),
      type: 2,
      largeImageKey: "app_icon",
      largeImageText: album || "Sonicly",
      instance: false,
    };
    if (playing && duration > 0) {
      const start = Date.now() - position * 1000;
      activity.startTimestamp = start;
      activity.endTimestamp = start + duration * 1000;
    } else if (!playing) {
      activity.state = `${activity.state} · Paused`;
    }
    await client.setActivity(activity);
    discordStatus = { state: "connected", message: "Connected to Discord. Rich Presence is up to date." };
    return { ok: true, ...discordStatus };
  } catch (error) {
    await disconnectDiscord();
    discordStatus = { state: "error", message: error && error.message ? error.message : "Couldn't connect to Discord." };
    return { ok: false, ...discordStatus };
  }
}

function registerIpc() {
  ipcMain.handle("remote-server:get", () => readRemoteServer());
  ipcMain.handle("remote-server:save", (_event, connection) => { writeRemoteServer(connection); return { ok: true }; });
  ipcMain.handle("remote-server:clear", () => { clearRemoteServer(); return { ok: true }; });
  ipcMain.handle("discord:set-presence", (_event, presence) => updateDiscordPresence(presence));
  ipcMain.handle("discord:test-connection", (_event, clientId) => testDiscordConnection(clientId));
  ipcMain.handle("discord:get-status", () => discordStatus);
  ipcMain.on("desktop:media-token", (event) => { event.returnValue = MEDIA_TOKEN; });
  ipcMain.on("mobile:connection-info", (event) => { event.returnValue = mobileInfo(); });
  ipcMain.handle("mobile:unpair-device", (_event, deviceId) => {
    const devices = readMobileDevices();
    const next = devices.filter((device) => device.deviceId !== String(deviceId));
    writeMobileDevices(next);
    return { ok: next.length !== devices.length };
  });
  ipcMain.handle("desktop:pick-folder", async () => {
    const result = await dialog.showOpenDialog({
      title: "Choose a media folder",
      properties: ["openDirectory"],
    });
    if (result.canceled || !result.filePaths[0]) return null;
    return result.filePaths[0];
  });
  ipcMain.handle("desktop:list-saved", () => readLibrary());
  ipcMain.handle("mobile:register-files", (_event, files) => ({ registered: registerMobileFiles(files) }));
  ipcMain.handle("desktop:remember", (_event, folderPath) => {
    if (typeof folderPath !== "string" || !fs.existsSync(folderPath) || !fs.statSync(folderPath).isDirectory()) {
      throw new Error("Choose a folder that exists on this computer.");
    }
    const resolved = fs.realpathSync(folderPath);
    const folders = readLibrary().filter((folder) => path.resolve(folder.path) !== resolved);
    const saved = { id: folderId(resolved), name: path.basename(resolved) || resolved, path: resolved };
    folders.push(saved);
    writeLibrary(folders);
    return saved;
  });
  ipcMain.handle("desktop:forget", (_event, id) => {
    writeLibrary(readLibrary().filter((folder) => folder.id !== id));
  });
  ipcMain.handle("desktop:clear", () => {
    writeLibrary([]);
  });
  ipcMain.handle("desktop:scan", async (_event, folderPath) => {
    if (typeof folderPath !== "string" || !fs.existsSync(folderPath)) return [];
    let resolved;
    try {
      resolved = fs.realpathSync(folderPath);
    } catch {
      return [];
    }
    const known = readLibrary().some((folder) => {
      try { return fs.realpathSync(folder.path) === resolved; } catch { return false; }
    });
    if (!known || !fs.statSync(resolved).isDirectory()) return [];
    return scanFolder(resolved);
  });
}

async function createWindow() {
  const root = rendererRoot();
  const hasIndex = fs.existsSync(path.join(root, "index.html"));
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 880,
    minHeight: 560,
    backgroundColor: "#101018",
    autoHideMenuBar: true,
    title: "Sonicly",
    icon: path.join(__dirname, "icon.ico"),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, "preload.cjs"),
    },
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://")) void shell.openExternal(url);
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (event, targetUrl) => {
    if (serverOrigin && !targetUrl.startsWith(`${serverOrigin}/`)) event.preventDefault();
  });
  if (!hasIndex) {
    const html = `<!doctype html><meta charset="utf-8"><title>Sonicly</title>
      <body style="font-family:sans-serif;background:#101018;color:#f2f2f7;padding:32px">
      <h1>Sonicly files were not found</h1>
      <p>Looked in:</p><pre>${candidates().join("\n")}</pre>
      </body>`;
    await win.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(html));
    return;
  }
  const port = await startServer(root);
  await win.loadURL(`http://127.0.0.1:${port}/`);
}

app.whenReady().then(() => {
  registerIpc();
  void startMobileServer().catch((error) => console.error("Sonicly mobile server:", error));
  void createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) void createWindow();
  });
});

app.on("before-quit", () => {
  if (mobileServer) mobileServer.close();
  void disconnectDiscord();
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
