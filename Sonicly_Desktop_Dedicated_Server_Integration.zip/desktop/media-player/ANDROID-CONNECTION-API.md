# Sonicly Android connection (desktop host)

The Electron desktop app starts a LAN-only HTTP API on TCP port **47831** while it is running. The API is intended for the future native Android client to browse the desktop's linked music folders and stream tracks directly from the host PC.

## Pairing

1. Start Sonicly on the Windows host.
2. Open **Settings → Sonicly mobile connection**.
3. Connect the Android device to the same trusted Wi-Fi/LAN.
4. Copy one of the displayed `http://<PC-LAN-IP>:47831` addresses and the pairing token into the Android app.
5. If Windows Firewall prompts, allow Sonicly on **Private networks** only.

The token is randomly generated each time the desktop app starts. It is shown only in the desktop settings panel. Do not share it, do not port-forward TCP 47831 to the internet, and use this HTTP connection only on a trusted local network. The server stops when Sonicly exits.

## Authentication

Send the token as an HTTP bearer token:

`Authorization: Bearer <pairing-token>`

The `X-Sonicly-Token` header is also accepted. Do not put the token in the URL.

## Endpoints

- `GET /api/v1/status` — server identity and protocol version.
- `GET /api/v1/library` — scans linked desktop folders and returns `{ "tracks": [...], "count": n }`.
- `GET /api/v1/artwork/{trackId}` — cover art for a track (embedded tag art, else cover/folder/front.jpg in the same folder, else a same-named image for videos, else an OS-generated video thumbnail on Windows/macOS). Token-protected; send the bearer header. Returns 404 when there is none. Large images are downscaled to ~640px JPEG.
- `GET /api/v1/stream/{trackId}` — streams the selected audio file. Supports HTTP byte ranges (`Range`) for seeking and efficient playback.

Track objects include `id`, `title` (filename without extension for this first API version), `artist`, `album`, `fileName`, `folder`, `path`, `size`, `modifiedAt`, `mime`, and `streamPath`. `title`, `artist`, `album`, `albumArtist`, `trackNumber`, `discNumber` and `year` are read from the embedded tags (ID3v2/ID3v1 for mp3, FLAC, MP4/M4A, Ogg Vorbis/Opus); untagged audio falls back to the filename and, for album, the containing folder name. `artworkPath` is set when artwork is available (always for videos). Track IDs are opaque and should not be constructed by the client.

## Example

```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://PC-LAN-IP:47831/api/v1/status
curl -H "Authorization: Bearer YOUR_TOKEN" http://PC-LAN-IP:47831/api/v1/library
curl -H "Authorization: Bearer YOUR_TOKEN" -H "Range: bytes=0-1023" http://PC-LAN-IP:47831/api/v1/stream/TRACK_ID
```

Protocol version: `1`.

## Automatic desktop discovery

`GET /api/v1/discover` is intentionally unauthenticated and returns only public host metadata (`name`, `version`, `protocol`, `port`, `hostName`, `pairingRequired`). It never returns the pairing token. Android scans the current local IPv4 /24 for this endpoint, then requires the user to enter the pairing code displayed in desktop Settings and explicitly tap **Confirm pairing & connect**. All library and stream endpoints remain bearer-token protected.
