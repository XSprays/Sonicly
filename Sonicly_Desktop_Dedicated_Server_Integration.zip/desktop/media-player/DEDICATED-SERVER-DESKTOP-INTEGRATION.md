# Sonicly Desktop — Dedicated Server Integration

This build restores the dedicated-server client in the current Veylara-enabled Electron desktop app. The Node.js dedicated server remains a separate service; the desktop app connects to an existing Sonicly API v1 server.

## Connect

1. Start the Sonicly Dedicated Media Server (v1.0.2 or compatible) and make its address reachable from this computer.
2. Open **Server** in Sonicly Desktop and enter the server IP/domain and port. The default port is `47831`.
3. Select **Find server and pair**. The server creates a unique, short-lived code for this pairing request and prints it in the server console.
4. Enter that four-digit code in Sonicly Desktop.
5. Once the status and remote library have been validated, Sonicly stores the device token with Electron `safeStorage`.
6. Open **Settings → Active media library → Server files** to use the remote library throughout the app.

Use HTTPS or a VPN when connecting over the public internet. Plain HTTP is intended only for a trusted local network.

## What is integrated

- Server discovery, manual address entry, pairing request and pairing completion.
- Persistent per-device pairing; disconnecting locally forgets this desktop credential but does not revoke the server-side device. The server owner can revoke it through the server's device-management CLI.
- Full paginated `/api/v1/media?type=all` loading, with an explicit 50,000-item client ceiling and truncation indication.
- Audio, video and photo library items with album artist, track/disc numbers, year, genre, MIME type and artwork path metadata.
- Authenticated stream, photo and artwork requests through the Electron local media host. The proxy forwards HTTP byte ranges and response metadata for seeking and streaming.
- Local and Server library source selection. Local folders and local file management remain separate and unchanged.
- Remote source support across Music, Videos, Gallery, Library, transport, integrated lyrics, video lyrics and the Veylara visualizer.

## Credential and media security

- The device bearer token is encrypted at rest with Electron `safeStorage`; it is not written as plaintext JSON.
- The renderer receives the saved token only through the narrow preload IPC method needed for authenticated library API calls.
- Media URLs contain only the API resource path; the Electron main process adds the bearer token to the upstream request.
- The local proxy accepts only `GET`/`HEAD` and the expected `/api/v1/stream`, `/photo`, and `/artwork` 24-character media-ID paths.
- Range headers are forwarded, allowing the media element to seek without downloading an entire file.
- Disconnect removes this desktop's local saved credential. It does not delete server media or revoke another device.

## Build the Windows app

From `desktop/media-player`:

```bash
npm install
npm run exe
```

The build uses the desktop renderer and Electron Builder configuration already present in this project.
