# Sonicly Media Player – fixes applied

## Changes

- Desktop MP3 imports now read ID3v2 and ID3v1 metadata using HTTP byte-range requests, so tags and embedded album artwork are available in Electron just as they are for browser imports.
- Desktop metadata reads run with bounded concurrency (six workers) and a bounded in-memory metadata cache. Large embedded images are not retained in the cache.
- Folder artwork is now detected automatically from `cover`, `folder`, `front`, `album`, or `artwork` image files. A same-basename image remains the preferred match.
- The local media server now binds to an ephemeral loopback port, uses a random per-launch token for media requests, checks the request origin when present, canonicalizes paths to prevent symlink/path traversal escapes, and only exposes files inside remembered media folders.
- Byte-range requests are validated, suffix ranges are supported, oversized end offsets are clamped, and GET/HEAD are the only accepted methods.
- Desktop folder scanning is asynchronous, stops at the 8,000-file cap, skips symlinks, and includes modification timestamps for metadata cache invalidation.
- Electron navigation is restricted to the local app origin; external HTTPS links are opened in the system browser.
- Media responses use a short private browser cache lifetime to reduce repeated local disk reads while keeping rescans responsive to file changes.

## Validation

- `node --check electron/main.cjs`: passed.
- `node --check electron/preload.cjs`: passed.
- TypeScript transpile syntax checks for `src/player/files.ts`, `src/player/desktop.ts`, and `src/player/store.ts`: passed.
- Existing script tests: 185 passed, 12 failed. The failures are caused by `.grok/skills/og/SKILL.md` and its `references` directory being absent from the supplied ZIP; these are pre-existing project support files not included in the archive.
- Full TypeScript typecheck and Windows installer build could not be run: dependencies were not present, and `npm ci` did not complete in the available environment.

## Build on Windows

From this project directory, run:

```powershell
npm ci
npm run typecheck
npm test
npm run exe
```
