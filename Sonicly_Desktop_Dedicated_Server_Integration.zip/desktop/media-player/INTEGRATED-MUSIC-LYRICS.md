Sonicly Desktop — Integrated Music Lyrics
=========================================

- Lyrics are now rendered as a normal-flow section inside the main workspace, above the global transport bar. The panel is not fixed, absolute, floating, or layered over transport controls.
- The panel appears globally while an audio track is playing, regardless of the selected page (Music, Videos, Gallery, Library, or Settings).
- LRCLIB lookup is automatic from the active track title, artist, album and media duration. There is no lyrics search field.
- Synchronized results open automatically and show previous/current/next lines with Sonicly blue-to-purple highlighting. Plain lyrics display as text.
- The bottom transport retains only Lyrics toggle and Fullscreen buttons while audio is playing.
- Fullscreen lyrics remains a dedicated full-window view; closing it returns to the same player state without pausing.
- The old fixed-position lyric card that overlapped the bottom transport has been removed.
