Sonicly Desktop — Global Music Lyrics Controls
==============================================

- Lyrics controls are rendered inside the global Transport component, which remains mounted outside page-specific Music/Videos/Gallery/Library/Settings views.
- Lyrics and Fullscreen Lyrics buttons appear in the circled bottom transport strip whenever an audio item is actively playing.
- The controls are hidden for videos/images and while audio playback is paused/stopped.
- LRCLIB lookup is automatic using the active audio track title, artist, album and duration. No manual search field or manual title search is shown.
- When synchronized lyrics are found, the compact three-line lyrics display opens automatically above the transport bar.
- Plain lyrics are displayed automatically too, with a short compact excerpt and full text in fullscreen mode.
- The Lyrics button toggles the compact display; Fullscreen Lyrics opens a full-window synchronized display. Escape / Back to player closes fullscreen without interrupting music.
- The existing video lyrics overlay, audio/video playback, seek controls, volume, repeat, shuffle, desktop pairing and library features are retained.

Validation:
- TypeScript syntax transpilation passed for the changed transport and existing video component source.
- Electron main/preload syntax checks passed in the source package.
- Full npm dependency-based typecheck/build was not run in this environment.
