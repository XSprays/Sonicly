Sonicly Visualizer — Veylara Theme Port
======================================

Ported from the user-provided Veylara Music Player backup.

Included theme designs
----------------------
- Ring
- Blobs
- Solar
- Vinyl
- Ducks
- Cat

The original canvas theme implementations are retained in `public/veylara-visualizer/themes.js`. The Sonicly host component loads that theme pack and provides the canvas, timing, artwork, metadata, and audio-analysis state expected by the themes. The Veylara visualizer's control/HUD styling was adapted and namespaced in `src/components/visualizer.css` so it does not reset or leak styles into the rest of Sonicly.

Sonicly integration
-------------------
- A new Visualizer page is available from the global Sonicly navigation.
- Theme selection, sensitivity, and Vinyl art mode are persisted with local storage, using Veylara's existing preference keys.
- The visualizer analyzes the already-playing Sonicly `HTMLAudioElement` with one shared `AudioContext`/`MediaElementAudioSourceNode`/`AnalyserNode` graph. That graph is retained across Visualizer page unmounts so the media source is never attached twice.
- Audio is routed from the analyser back to `AudioContext.destination`; playback remains on Sonicly's existing player element. No second player, microphone capture, or screen/tab capture is used.
- The original Veylara Vinyl theme's canvas transport buttons now dispatch Sonicly events for previous, play/pause, next, and volume instead of calling Veylara's `api.php` endpoint or BroadcastChannel.
- Sonicly album artwork and icon are provided to the original themes through their existing canvas state fields.

Validation performed
--------------------
- The six registered theme draw functions were smoke-tested against a canvas-context stub and all executed without throwing.
- Vinyl's built-in play/pause and volume hit areas were exercised and emitted the new Sonicly events.
- The copied theme pack passes `node --check` and contains no references to Veylara's `api.php`, legacy BroadcastChannel, or legacy transport storage bridge.
- Modified TypeScript/TSX files pass TypeScript syntax transpilation.
- The project archive was checked for integrity and compared against the supplied Sonicly source to ensure no original files were removed.

A full Electron/Vite production build was not available in this environment because the project dependencies are not installed here. Run the desktop build locally after extracting this ZIP.
