Sonicly Desktop — Video Lyrics Overlay
=====================================

- Adds a video-only overlay over the existing HTML video element. It uses the current video element and existing playback store; no second player is created.
- Uses LRCLIB, with exact metadata lookup when artist and duration are available, then a strict title/artist-filtered search fallback. Requests are cached in-memory by metadata signature.
- Automatically enables the previous/current/next line overlay when synchronized lyrics are found.
- Plain lyrics are available via the Lyrics toggle and fullscreen lyrics view. Missing or instrumental lyrics leave controls disabled and show a compact status message.
- Fullscreen lyrics expands the video shell so the overlay remains visible in fullscreen. Returning closes lyrics and, if lyrics mode initiated fullscreen, returns to the embedded player without pausing playback.
- Fullscreen browser-native video controls are enabled while the shell is fullscreen; the lyric panel is positioned above that control area.
- The pre-existing audio lyrics panel remains unchanged.
