// Media tag + embedded artwork reader for the Sonicly mobile API.
// Pure Node (no dependencies). Supports ID3v2/ID3v1 (mp3, many wav/aac), FLAC,
// MP4/M4A/M4V (iTunes atoms), and Ogg Vorbis/Opus comments.
// readMeta() returns { title, artist, album, albumArtist, trackNumber, discNumber, year, hasArt }
// readArtwork() returns { bytes: Buffer, mime } or null.
const fs = require("node:fs");
const path = require("node:path");

const MAX_TAG_BYTES = 12 * 1024 * 1024;

async function readAt(fh, position, length) {
  const buffer = Buffer.alloc(length);
  const { bytesRead } = await fh.read(buffer, 0, length, position);
  return bytesRead === length ? buffer : buffer.subarray(0, bytesRead);
}

function sniffImage(buf) {
  if (!buf || buf.length < 4) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8) return "image/jpeg";
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "image/png";
  if (buf.subarray(0, 4).toString("latin1") === "GIF8") return "image/gif";
  if (buf.subarray(0, 4).toString("latin1") === "RIFF" && buf.subarray(8, 12).toString("latin1") === "WEBP") return "image/webp";
  if (buf[0] === 0x42 && buf[1] === 0x4d) return "image/bmp";
  return null;
}

function parseIntLead(value) {
  const m = /^\s*(\d+)/.exec(String(value || ""));
  return m ? Number(m[1]) : 0;
}

function emptyMeta() {
  return { title: "", artist: "", album: "", albumArtist: "", trackNumber: 0, discNumber: 0, year: "", art: null };
}

// ---------- ID3 ----------
function synchsafe(b0, b1, b2, b3) { return (b0 << 21) | (b1 << 14) | (b2 << 7) | b3; }

function decodeText(data, encoding) {
  if (!data.length) return "";
  let text;
  if (encoding === 1 || encoding === 2) {
    let d = data, enc = "utf16le";
    if (d.length >= 2 && d[0] === 0xfe && d[1] === 0xff) { d = Buffer.from(d.subarray(2)).swap16(); }
    else if (d.length >= 2 && d[0] === 0xff && d[1] === 0xfe) { d = d.subarray(2); }
    else if (encoding === 2) { d = Buffer.from(d).swap16(); }
    text = d.toString(enc);
  } else if (encoding === 3) text = data.toString("utf8");
  else text = data.toString("latin1");
  return text.replace(/\0+$/g, "").replace(/\0/g, " / ").trim();
}

function id3TextFrame(data) {
  if (!data.length) return "";
  return decodeText(data.subarray(1), data[0]);
}

function parseApic(data, v22) {
  if (data.length < 8) return null;
  const encoding = data[0];
  let i = 1;
  let mime = "";
  if (v22) { mime = data.subarray(1, 4).toString("latin1").toLowerCase() === "png" ? "image/png" : "image/jpeg"; i = 4; }
  else {
    const end = data.indexOf(0, i);
    if (end < 0) return null;
    mime = data.subarray(i, end).toString("latin1");
    i = end + 1;
  }
  const pictureType = data[i]; i += 1;
  // description (terminated per encoding)
  if (encoding === 1 || encoding === 2) {
    while (i + 1 < data.length && !(data[i] === 0 && data[i + 1] === 0)) i += 2;
    i += 2;
  } else {
    while (i < data.length && data[i] !== 0) i += 1;
    i += 1;
  }
  if (i >= data.length) return null;
  const bytes = data.subarray(i);
  const sniffed = sniffImage(bytes);
  if (!sniffed && bytes.length < 64) return null;
  return { bytes, mime: sniffed || (mime.includes("/") ? mime : "image/jpeg"), pictureType };
}

function parseId3v2(tag, meta, wantArt) {
  const version = tag[3];
  const flags = tag[5];
  let body = tag.subarray(10);
  if (flags & 0x80 && version <= 3) {
    // whole-tag unsynchronisation: undo 0xFF00 -> 0xFF
    const out = []; for (let i = 0; i < body.length; i += 1) { out.push(body[i]); if (body[i] === 0xff && body[i + 1] === 0) i += 1; }
    body = Buffer.from(out);
  }
  let offset = 0;
  if (flags & 0x40) { // extended header
    const size = version === 4 ? synchsafe(body[0], body[1], body[2], body[3]) : body.readUInt32BE(0) + 4;
    offset = Math.min(size, body.length);
  }
  const v22 = version === 2;
  const headerLen = v22 ? 6 : 10;
  while (offset + headerLen <= body.length) {
    let id, size, fflags = 0;
    if (v22) { id = body.subarray(offset, offset + 3).toString("latin1"); size = (body[offset + 3] << 16) | (body[offset + 4] << 8) | body[offset + 5]; }
    else {
      id = body.subarray(offset, offset + 4).toString("latin1");
      size = version === 4 ? synchsafe(body[offset + 4], body[offset + 5], body[offset + 6], body[offset + 7]) : body.readUInt32BE(offset + 4);
      fflags = body.readUInt16BE(offset + 8);
    }
    if (!/^[A-Z0-9]{3,4}$/.test(id) || size <= 0 || offset + headerLen + size > body.length) break;
    let data = body.subarray(offset + headerLen, offset + headerLen + size);
    offset += headerLen + size;
    if (!v22) {
      if (version === 4) {
        if (fflags & 0x0001) data = data.subarray(4); // data length indicator
        if (fflags & 0x0002) { const out = []; for (let i = 0; i < data.length; i += 1) { out.push(data[i]); if (data[i] === 0xff && data[i + 1] === 0) i += 1; } data = Buffer.from(out); }
        if (fflags & 0x000c) continue; // compressed/encrypted
      } else if (fflags & 0x00c0) continue;
    }
    switch (id) {
      case "TIT2": case "TT2": meta.title = meta.title || id3TextFrame(data); break;
      case "TPE1": case "TP1": meta.artist = meta.artist || id3TextFrame(data); break;
      case "TALB": case "TAL": meta.album = meta.album || id3TextFrame(data); break;
      case "TPE2": case "TP2": meta.albumArtist = meta.albumArtist || id3TextFrame(data); break;
      case "TRCK": case "TRK": meta.trackNumber = meta.trackNumber || parseIntLead(id3TextFrame(data)); break;
      case "TPOS": case "TPA": meta.discNumber = meta.discNumber || parseIntLead(id3TextFrame(data)); break;
      case "TDRC": case "TYER": case "TYE": meta.year = meta.year || id3TextFrame(data).slice(0, 4); break;
      case "APIC": case "PIC": {
        if (!wantArt && meta.art) break;
        const pic = parseApic(data, v22);
        if (pic) {
          // Prefer the front cover (type 3) over any other picture.
          if (!meta.art || (pic.pictureType === 3 && meta.art.pictureType !== 3)) meta.art = { bytes: wantArt ? Buffer.from(pic.bytes) : null, mime: pic.mime, pictureType: pic.pictureType };
        }
        break;
      }
      default: break;
    }
  }
}

function parseId3v1(buf, meta) {
  if (buf.length < 128 || buf.subarray(0, 3).toString("latin1") !== "TAG") return;
  const t = (a, b) => buf.subarray(a, b).toString("latin1").replace(/\0.*$/s, "").trim();
  meta.title = meta.title || t(3, 33);
  meta.artist = meta.artist || t(33, 63);
  meta.album = meta.album || t(63, 93);
  meta.year = meta.year || t(93, 97);
  if (buf[125] === 0 && buf[126]) meta.trackNumber = meta.trackNumber || buf[126];
}

async function readId3(fh, size, meta, wantArt) {
  const head = await readAt(fh, 0, 10);
  if (head.length === 10 && head.subarray(0, 3).toString("latin1") === "ID3") {
    const tagSize = synchsafe(head[6], head[7], head[8], head[9]);
    const footer = head[5] & 0x10 ? 10 : 0;
    const total = Math.min(10 + tagSize + footer, MAX_TAG_BYTES, size);
    const tag = await readAt(fh, 0, total);
    try { parseId3v2(tag, meta, wantArt); } catch { /* corrupt tag: keep what we have */ }
  }
  if (!meta.title || !meta.artist || !meta.album) {
    if (size >= 128) parseId3v1(await readAt(fh, size - 128, 128), meta);
  }
}

// ---------- FLAC ----------
function parseVorbisComments(buf, meta) {
  let o = 0;
  const vendorLen = buf.readUInt32LE(o); o += 4 + vendorLen;
  const count = buf.readUInt32LE(o); o += 4;
  const out = {};
  for (let i = 0; i < count && o + 4 <= buf.length; i += 1) {
    const len = buf.readUInt32LE(o); o += 4;
    if (o + len > buf.length) break;
    const s = buf.subarray(o, o + len).toString("utf8"); o += len;
    const eq = s.indexOf("=");
    if (eq < 1) continue;
    const key = s.slice(0, eq).toUpperCase();
    (out[key] = out[key] || []).push(s.slice(eq + 1));
  }
  const first = (k) => (out[k] && out[k][0] ? out[k][0].trim() : "");
  meta.title = meta.title || first("TITLE");
  meta.artist = meta.artist || (out.ARTIST || []).join(" / ").trim();
  meta.album = meta.album || first("ALBUM");
  meta.albumArtist = meta.albumArtist || first("ALBUMARTIST") || first("ALBUM ARTIST");
  meta.trackNumber = meta.trackNumber || parseIntLead(first("TRACKNUMBER"));
  meta.discNumber = meta.discNumber || parseIntLead(first("DISCNUMBER"));
  meta.year = meta.year || first("DATE").slice(0, 4) || first("YEAR");
  return out;
}

function parseFlacPicture(data) {
  let o = 0;
  const pictureType = data.readUInt32BE(o); o += 4;
  const mimeLen = data.readUInt32BE(o); o += 4;
  const mime = data.subarray(o, o + mimeLen).toString("latin1"); o += mimeLen;
  const descLen = data.readUInt32BE(o); o += 4 + descLen;
  o += 16; // width, height, depth, colours
  const len = data.readUInt32BE(o); o += 4;
  const bytes = data.subarray(o, o + len);
  if (!bytes.length) return null;
  return { bytes, mime: sniffImage(bytes) || mime || "image/jpeg", pictureType };
}

async function readFlac(fh, size, meta, wantArt) {
  if ((await readAt(fh, 0, 4)).toString("latin1") !== "fLaC") return;
  let pos = 4;
  for (let guard = 0; guard < 64 && pos + 4 <= size; guard += 1) {
    const h = await readAt(fh, pos, 4);
    const last = Boolean(h[0] & 0x80);
    const type = h[0] & 0x7f;
    const len = (h[1] << 16) | (h[2] << 8) | h[3];
    pos += 4;
    if (type === 4 && len < MAX_TAG_BYTES) {
      try { parseVorbisComments(await readAt(fh, pos, len), meta); } catch { /* ignore */ }
    } else if (type === 6 && len < MAX_TAG_BYTES) {
      try {
        const pic = parseFlacPicture(await readAt(fh, pos, len));
        if (pic && (!meta.art || (pic.pictureType === 3 && meta.art.pictureType !== 3))) meta.art = { bytes: wantArt ? Buffer.from(pic.bytes) : null, mime: pic.mime, pictureType: pic.pictureType };
      } catch { /* ignore */ }
    }
    pos += len;
    if (last) break;
  }
}

// ---------- MP4 / M4A ----------
function findAtoms(buf, start, end, wanted) {
  const found = [];
  let o = start;
  while (o + 8 <= end) {
    let size = buf.readUInt32BE(o);
    const type = buf.subarray(o + 4, o + 8).toString("latin1");
    let header = 8;
    if (size === 1) { if (o + 16 > end) break; size = Number(buf.readBigUInt64BE(o + 8)); header = 16; }
    else if (size === 0) size = end - o;
    if (size < header || o + size > end) break;
    if (!wanted || wanted.includes(type)) found.push({ type, start: o + header, end: o + size });
    o += size;
  }
  return found;
}

async function readMp4(fh, size, meta, wantArt) {
  // Walk top-level atoms from the file, locate moov (may be at the end), then read it whole.
  let pos = 0;
  let moov = null;
  for (let guard = 0; guard < 200 && pos + 8 <= size; guard += 1) {
    const h = await readAt(fh, pos, 16);
    if (h.length < 8) break;
    let atomSize = h.readUInt32BE(0);
    const type = h.subarray(4, 8).toString("latin1");
    let header = 8;
    if (atomSize === 1 && h.length >= 16) { atomSize = Number(h.readBigUInt64BE(8)); header = 16; }
    else if (atomSize === 0) atomSize = size - pos;
    if (atomSize < header) break;
    if (type === "moov") { moov = { start: pos + header, length: Math.min(atomSize - header, MAX_TAG_BYTES * 2) }; break; }
    pos += atomSize;
  }
  if (!moov) return;
  const buf = await readAt(fh, moov.start, moov.length);
  const udta = findAtoms(buf, 0, buf.length, ["udta"])[0];
  const metaAtom = udta && findAtoms(buf, udta.start, udta.end, ["meta"])[0];
  if (!metaAtom) return;
  const ilst = findAtoms(buf, metaAtom.start + 4, metaAtom.end, ["ilst"])[0]; // meta has 4 bytes version/flags
  if (!ilst) return;
  const text = (item) => {
    const d = findAtoms(buf, item.start, item.end, ["data"])[0];
    return d ? buf.subarray(d.start + 8, d.end).toString("utf8").replace(/\0+$/g, "").trim() : "";
  };
  for (const item of findAtoms(buf, ilst.start, ilst.end)) {
    switch (item.type) {
      case "©nam": meta.title = meta.title || text(item); break;
      case "©ART": meta.artist = meta.artist || text(item); break;
      case "aART": meta.albumArtist = meta.albumArtist || text(item); break;
      case "©alb": meta.album = meta.album || text(item); break;
      case "©day": meta.year = meta.year || text(item).slice(0, 4); break;
      case "trkn": { const d = findAtoms(buf, item.start, item.end, ["data"])[0]; if (d && d.end - d.start >= 12) meta.trackNumber = meta.trackNumber || buf.readUInt16BE(d.start + 10); break; }
      case "disk": { const d = findAtoms(buf, item.start, item.end, ["data"])[0]; if (d && d.end - d.start >= 12) meta.discNumber = meta.discNumber || buf.readUInt16BE(d.start + 10); break; }
      case "covr": {
        const d = findAtoms(buf, item.start, item.end, ["data"])[0];
        if (d && !meta.art) {
          const bytes = buf.subarray(d.start + 8, d.end);
          const mime = sniffImage(bytes);
          if (mime) meta.art = { bytes: wantArt ? Buffer.from(bytes) : null, mime, pictureType: 3 };
        }
        break;
      }
      default: break;
    }
  }
}

// ---------- Ogg Vorbis / Opus ----------
async function readOgg(fh, size, meta, wantArt) {
  const raw = await readAt(fh, 0, Math.min(size, 4 * 1024 * 1024));
  // Reassemble the first few logical packets (identification, comments).
  const packets = [];
  let cur = [];
  let o = 0;
  while (o + 27 <= raw.length && packets.length < 2) {
    if (raw.subarray(o, o + 4).toString("latin1") !== "OggS") break;
    const segCount = raw[o + 26];
    const segs = raw.subarray(o + 27, o + 27 + segCount);
    let dataPos = o + 27 + segCount;
    for (const s of segs) {
      cur.push(raw.subarray(dataPos, dataPos + s));
      dataPos += s;
      if (s < 255) { packets.push(Buffer.concat(cur)); cur = []; if (packets.length >= 2) break; }
    }
    o = dataPos;
  }
  const comment = packets[1];
  if (!comment) return;
  let body;
  if (comment.subarray(0, 8).toString("latin1") === "OpusTags") body = comment.subarray(8);
  else if (comment[0] === 3 && comment.subarray(1, 7).toString("latin1") === "vorbis") body = comment.subarray(7);
  else return;
  let out;
  try { out = parseVorbisComments(body, meta); } catch { return; }
  for (const b64 of out.METADATA_BLOCK_PICTURE || []) {
    try {
      const pic = parseFlacPicture(Buffer.from(b64, "base64"));
      if (pic && !meta.art) meta.art = { bytes: wantArt ? Buffer.from(pic.bytes) : null, mime: pic.mime, pictureType: pic.pictureType };
    } catch { /* ignore */ }
  }
}

// ---------- folder artwork ----------
const FOLDER_ART_NAMES = ["cover", "folder", "front", "album", "albumart", "albumartsmall", "artwork", "poster", "thumb", "thumbnail"];
const IMAGE_EXT = [".jpg", ".jpeg", ".png", ".webp", ".bmp"];
const dirCache = new Map(); // dir -> { at, file }

async function findFolderArt(filePath) {
  const dir = path.dirname(filePath);
  const hit = dirCache.get(dir);
  if (hit && Date.now() - hit.at < 60_000) return hit.file;
  let file = null;
  try {
    const names = await fs.promises.readdir(dir);
    const byLower = new Map(names.map((n) => [n.toLowerCase(), n]));
    outer: for (const base of FOLDER_ART_NAMES) {
      for (const ext of IMAGE_EXT) {
        const real = byLower.get(base + ext);
        if (real) { file = path.join(dir, real); break outer; }
      }
    }
  } catch { /* unreadable dir */ }
  dirCache.set(dir, { at: Date.now(), file });
  return file;
}

async function findSiblingImage(filePath) {
  // Video poster next to the file: "Movie.mp4" -> "Movie.jpg" / "Movie-poster.jpg"
  const dir = path.dirname(filePath);
  const base = path.basename(filePath, path.extname(filePath));
  for (const suffix of ["", "-poster", "-thumb", "-thumbnail", ".poster"]) {
    for (const ext of IMAGE_EXT) {
      const candidate = path.join(dir, base + suffix + ext);
      try { if ((await fs.promises.stat(candidate)).isFile()) return candidate; } catch { /* next */ }
    }
  }
  return null;
}

// ---------- public API ----------
async function parseFile(filePath, wantArt) {
  const meta = emptyMeta();
  const ext = path.extname(filePath).slice(1).toLowerCase();
  let fh;
  try {
    fh = await fs.promises.open(filePath, "r");
    const { size } = await fh.stat();
    if (ext === "flac") await readFlac(fh, size, meta, wantArt);
    else if (ext === "mp4" || ext === "m4a" || ext === "m4v" || ext === "mov") await readMp4(fh, size, meta, wantArt);
    else if (ext === "ogg" || ext === "oga" || ext === "opus") await readOgg(fh, size, meta, wantArt);
    else if (ext === "mp3" || ext === "wav" || ext === "aac" || ext === "weba" || ext === "mpeg" || ext === "mpg") await readId3(fh, size, meta, wantArt);
    // mp4 files with ID3 or flac-in-id3 are rare; but any file starting with ID3 is worth a try
    if (!meta.title && !meta.art && ext !== "mp3") {
      try { await readId3(fh, size, meta, wantArt); } catch { /* ignore */ }
    }
  } catch { /* unreadable file: return what we have */ }
  finally { if (fh) await fh.close().catch(() => {}); }
  return meta;
}

const metaCache = new Map(); // key: path|mtime|size -> meta without bytes

async function readMeta(filePath, stat) {
  const key = `${filePath}|${stat.mtimeMs}|${stat.size}`;
  const cached = metaCache.get(key);
  if (cached) return cached;
  const m = await parseFile(filePath, false);
  let hasArt = Boolean(m.art);
  if (!hasArt) hasArt = Boolean(await findFolderArt(filePath)) || Boolean(await findSiblingImage(filePath));
  const result = { title: m.title, artist: m.artist, album: m.album, albumArtist: m.albumArtist, trackNumber: m.trackNumber, discNumber: m.discNumber, year: m.year, hasArt };
  if (metaCache.size > 20000) metaCache.clear();
  metaCache.set(key, result);
  return result;
}

async function readArtwork(filePath) {
  const m = await parseFile(filePath, true);
  if (m.art && m.art.bytes && m.art.bytes.length) return { bytes: m.art.bytes, mime: m.art.mime };
  for (const find of [findSiblingImage, findFolderArt]) {
    const file = await find(filePath);
    if (file) {
      try {
        const bytes = await fs.promises.readFile(file);
        if (bytes.length && bytes.length < 20 * 1024 * 1024) return { bytes, mime: sniffImage(bytes) || "image/jpeg" };
      } catch { /* next */ }
    }
  }
  return null;
}

module.exports = { readMeta, readArtwork, sniffImage };
