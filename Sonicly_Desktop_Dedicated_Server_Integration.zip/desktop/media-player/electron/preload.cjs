const { contextBridge, ipcRenderer, webUtils } = require("electron");

contextBridge.exposeInMainWorld("desktop", {
  pickFolder: () => ipcRenderer.invoke("desktop:pick-folder"),
  listSaved: () => ipcRenderer.invoke("desktop:list-saved"),
  remember: (folderPath) => ipcRenderer.invoke("desktop:remember", folderPath),
  forget: (id) => ipcRenderer.invoke("desktop:forget", id),
  clear: () => ipcRenderer.invoke("desktop:clear"),
  scan: (folderPath) => ipcRenderer.invoke("desktop:scan", folderPath),
  getPathForFile: (file) => webUtils.getPathForFile(file),
  registerMobileFiles: (paths) => ipcRenderer.invoke("mobile:register-files", paths),
  setDiscordPresence: (presence) => ipcRenderer.invoke("discord:set-presence", presence),
  testDiscordConnection: (clientId) => ipcRenderer.invoke("discord:test-connection", clientId),
  getDiscordStatus: () => ipcRenderer.invoke("discord:get-status"),
  mediaToken: () => ipcRenderer.sendSync("desktop:media-token"),
  mobileConnectionInfo: () => ipcRenderer.sendSync("mobile:connection-info"),
  unpairMobileDevice: (deviceId) => ipcRenderer.invoke("mobile:unpair-device", deviceId),
  getRemoteServer: () => ipcRenderer.invoke("remote-server:get"),
  saveRemoteServer: (connection) => ipcRenderer.invoke("remote-server:save", connection),
  clearRemoteServer: () => ipcRenderer.invoke("remote-server:clear"),
});
