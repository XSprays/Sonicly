// ========== INLINE THEMES (no external files needed) ==========
window.PulseVizThemes = window.PulseVizThemes || {};

// --- RING THEME ---
(function () {
  function cloudPath(ctx, cx, cy, R, phase, energy) {
    var steps = 48;
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var a = (i / steps) * Math.PI * 2;
      var puff =
        0.55 +
        0.22 * Math.sin(a * 3 + phase) +
        0.16 * Math.sin(a * 5 - phase * 1.3) +
        0.12 * Math.sin(a * 2 + phase * 0.5) +
        0.08 * Math.sin(a * 7 + phase * 2) * (0.5 + energy);
      var r = R * puff;
      var x = cx + Math.cos(a) * r;
      var y = cy + Math.sin(a) * r * 0.85;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  function ringPoint(i, steps, cx, cy, rx, ry, waveSpin, energy) {
    var a = (i / steps) * Math.PI * 2;
    var baseX = Math.cos(a) * rx;
    var baseY = Math.sin(a) * ry;
    var wave =
      Math.sin(a * 3 - waveSpin) * (8 + energy * 18) +
      Math.sin(a * 5 + waveSpin * 1.2) * (4 + energy * 10) +
      Math.sin(a * 2 - waveSpin * 0.6) * (5 + energy * 8);
    var nx = Math.cos(a);
    var ny = Math.sin(a);
    return {
      x: cx + baseX + nx * wave,
      y: cy + baseY + ny * wave * 0.85,
      a: a, nx: nx, ny: ny
    };
  }

  window.PulseVizThemes.ring = {
    id: "ring",
    name: "Ring",
    update: function (state) {
      var beatEnergy = state.beatEnergy;
      var targetSplash = beatEnergy > 0.55 ? Math.min(1, (beatEnergy - 0.45) / 0.35) : 0;
      var wasLow = state.splash < 0.25;
      state.splash += (targetSplash - state.splash) * 0.12;
      if (state.splash > 0.4 && wasLow && state.seedSplash) {
        state.seedSplash(state.w * 0.5, state.h * 0.45, state.splash);
      }
      if (state.splash > 0.7 && Math.random() < 0.05 + state.flowBass * 0.08 && state.seedSplash) {
        state.seedSplash(state.w * 0.5, state.h * 0.45, state.splash);
      }
    },
    draw: function (ctx, w, h, state) {
      var dt = state.dt;
      var flowLevel = state.flowLevel;
      var flowBass = state.flowBass;
      var beatEnergy = state.beatEnergy;
      var m = state.m;
      var crazy = state.crazy;
      var energy = Math.min(1.5, beatEnergy);

      state.flowT += dt * (0.5 + flowLevel * 1.2 + flowBass * 1.0 + crazy * 1.2);
      state.cloudPhase += dt * (0.8 + flowBass * 1.3 + crazy * 1.5);
      var pulseWave = 0.5 + 0.5 * Math.sin(state.flowT * (2.2 + crazy * 2));
      state.logoPulse += ((0.94 + pulseWave * (0.12 + crazy * 0.12) + flowBass * 0.2) - state.logoPulse) * 0.12;

      var cx = w * 0.5;
      var cy = h * 0.46;
      var base = Math.min(w, h);
      var rx = base * (0.26 + flowLevel * 0.05 + energy * 0.03);
      var ry = rx * 0.70;

      // Ambient glow
      var glow = 0.25 + flowLevel * 0.5 + energy * 0.3;
      var rg = ctx.createRadialGradient(cx, cy, 0, cx, cy, rx * 1.8);
      rg.addColorStop(0, "rgba(76, 29, 149," + (glow * 0.45) + ")");
      rg.addColorStop(0.45, "rgba(37, 99, 235," + (glow * 0.2) + ")");
      rg.addColorStop(1, "rgba(3, 7, 18, 0)");
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, w, h);

      // Floor wave
      var midY = h * 0.78;
      var baseAmp = h * (0.055 + flowLevel * 0.14 + flowBass * 0.08);
      function surfaceY(x) {
        var nx = x / w;
        return midY - (
          Math.sin(nx * Math.PI * 2 * 1.2 - state.flowT * 0.9) +
          Math.sin(nx * Math.PI * 2 * 0.55 - state.flowT * 0.45) * 0.5
        ) * baseAmp;
      }
      var floorSteps = Math.max(80, Math.floor(w / 5));
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (var i = 0; i <= floorSteps; i++) ctx.lineTo((i / floorSteps) * w, surfaceY((i / floorSteps) * w));
      ctx.lineTo(w, h);
      ctx.closePath();
      var floorFill = ctx.createLinearGradient(0, midY - 50, 0, h);
      floorFill.addColorStop(0, "rgba(167, 139, 250, 0.75)");
      floorFill.addColorStop(0.5, "rgba(99, 102, 241, 0.45)");
      floorFill.addColorStop(1, "rgba(30, 58, 138, 0.4)");
      ctx.fillStyle = floorFill;
      ctx.fill();
      // surface line
      ctx.beginPath();
      for (var i = 0; i <= floorSteps; i++) {
        var x = (i / floorSteps) * w;
        if (i === 0) ctx.moveTo(x, surfaceY(x)); else ctx.lineTo(x, surfaceY(x));
      }
      ctx.strokeStyle = "rgba(224, 231, 255, 0.35)";
      ctx.lineWidth = 2;
      ctx.stroke();

      // ===== THICK RING (stroke-based so it always shows) =====
      var steps = 100;
      var lineW = Math.max(14, 16 + flowLevel * 18 + flowBass * 20 + energy * 10);

      // Outer glow stroke
      ctx.beginPath();
      for (var i = 0; i <= steps; i++) {
        var p = ringPoint(i, steps, cx, cy, rx, ry, state.flowT * 1.4, energy);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.closePath();
      ctx.strokeStyle = "rgba(129, 140, 248, 0.35)";
      ctx.lineWidth = lineW * 1.8;
      ctx.lineJoin = "round";
      ctx.stroke();

      // Main thick body
      ctx.beginPath();
      for (var i = 0; i <= steps; i++) {
        var p = ringPoint(i, steps, cx, cy, rx, ry, state.flowT * 1.4, energy);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.closePath();
      var ringGrad = ctx.createLinearGradient(cx - rx, cy - ry, cx + rx, cy + ry);
      ringGrad.addColorStop(0, "rgba(147, 197, 253, 0.95)");
      ringGrad.addColorStop(0.35, "rgba(165, 180, 252, 0.95)");
      ringGrad.addColorStop(0.65, "rgba(167, 139, 250, 0.95)");
      ringGrad.addColorStop(1, "rgba(192, 132, 252, 0.9)");
      ctx.strokeStyle = ringGrad;
      ctx.lineWidth = lineW;
      ctx.lineJoin = "round";
      ctx.stroke();

      // Bright inner edge
      ctx.beginPath();
      for (var i = 0; i <= steps; i++) {
        var p = ringPoint(i, steps, cx, cy, rx, ry, state.flowT * 1.4, energy);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.closePath();
      ctx.strokeStyle = "rgba(237, 233, 254," + (0.45 + crazy * 0.25) + ")";
      ctx.lineWidth = Math.max(2, lineW * 0.25);
      ctx.stroke();

      // Secondary outer ripple
      ctx.beginPath();
      for (var i = 0; i <= steps; i++) {
        var p = ringPoint(i, steps, cx, cy, rx * 1.2, ry * 1.2, state.flowT * 0.7, energy * 0.5);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.closePath();
      ctx.strokeStyle = "rgba(165, 180, 252," + (0.2 + energy * 0.25) + ")";
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Cloud blob when there's energy
      if (energy > 0.08 || m > 0.05) {
        var alpha = Math.min(1, 0.4 + energy * 0.8 + m * 0.5);
        var cloudAngle = -Math.PI * 0.65 + Math.sin(state.cloudPhase * 0.4) * 0.1;
        var cloudDist = (rx + ry) * 0.5 * 0.9;
        var cloudX = cx + Math.cos(cloudAngle) * cloudDist;
        var cloudY = cy + Math.sin(cloudAngle) * cloudDist * (ry / rx) * 0.85;
        var cloudR = base * (0.1 + flowLevel * 0.04 + flowBass * 0.035) * state.logoPulse;

        ctx.save();
        ctx.globalAlpha = alpha;

        var halo = ctx.createRadialGradient(cloudX, cloudY, cloudR * 0.2, cloudX, cloudY, cloudR * 2);
        halo.addColorStop(0, "rgba(196, 181, 253," + (0.5 + flowBass * 0.3) + ")");
        halo.addColorStop(1, "rgba(37, 99, 235, 0)");
        ctx.fillStyle = halo;
        ctx.beginPath();
        ctx.arc(cloudX, cloudY, cloudR * 2, 0, Math.PI * 2);
        ctx.fill();

        cloudPath(ctx, cloudX, cloudY, cloudR, state.cloudPhase, energy);
        var cloudFill = ctx.createLinearGradient(cloudX - cloudR, cloudY - cloudR, cloudX + cloudR, cloudY + cloudR);
        cloudFill.addColorStop(0, "rgba(237, 233, 254, 0.95)");
        cloudFill.addColorStop(0.35, "rgba(196, 181, 253, 0.9)");
        cloudFill.addColorStop(0.7, "rgba(129, 140, 248, 0.88)");
        cloudFill.addColorStop(1, "rgba(99, 102, 241, 0.8)");
        ctx.fillStyle = cloudFill;
        ctx.fill();
        ctx.strokeStyle = "rgba(255,255,255,0.3)";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        cloudPath(ctx, cloudX - cloudR * 0.7, cloudY + cloudR * 0.15, cloudR * 0.55, state.cloudPhase + 1.2, energy);
        ctx.fillStyle = "rgba(167, 139, 250, 0.75)";
        ctx.fill();
        cloudPath(ctx, cloudX + cloudR * 0.65, cloudY + cloudR * 0.1, cloudR * 0.5, state.cloudPhase + 2.1, energy);
        ctx.fillStyle = "rgba(147, 197, 253, 0.7)";
        ctx.fill();

        // Logo in center of ring
        var logoSize = Math.min(rx, ry) * 0.4 * state.logoPulse;
        ctx.globalAlpha = alpha * 0.4;
        ctx.translate(cx, cy);
        if (state.logoReady && state.logoImg) {
          ctx.drawImage(state.logoImg, -logoSize / 2, -logoSize / 2, logoSize, logoSize);
        } else {
          ctx.fillStyle = "#fff";
          ctx.font = "bold " + Math.floor(logoSize * 0.55) + "px Segoe UI, system-ui, sans-serif";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("\u266A", 0, 2);
        }
        ctx.restore();
      }

      // Splash
      if (state.splash > 0.15) {
        var scx = w * 0.5, scy = h * 0.45;
        var sAlpha = Math.min(1, (state.splash - 0.15) / 0.4);
        ctx.save();
        ctx.globalAlpha = sAlpha * 0.9;
        for (var r = 0; r < 3; r++) {
          var t = (state.flowT * 1.5 + r * 0.45) % 1.2;
          var rad = base * (0.08 + t * 0.22) * (0.8 + state.splash * 0.4);
          var thick = (12 + state.splash * 16) * (1 - t / 1.2);
          ctx.beginPath();
          for (var i = 0; i <= 72; i++) {
            var a = (i / 72) * Math.PI * 2;
            var jagged = 1 + Math.sin(a * 8 + state.flowT * 4 + r) * 0.08 * state.splash
              + Math.sin(a * 5 - state.flowT * 3) * 0.06;
            var rr = rad * jagged;
            var x = scx + Math.cos(a) * rr;
            var y = scy + Math.sin(a) * rr * 0.92;
            if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
          }
          ctx.closePath();
          var g = ctx.createRadialGradient(scx, scy, rad * 0.7, scx, scy, rad + thick);
          g.addColorStop(0, "rgba(191, 219, 254, 0)");
          g.addColorStop(0.55, "rgba(147, 197, 253," + (0.4 * (1 - t / 1.2)) + ")");
          g.addColorStop(0.85, "rgba(167, 139, 250," + (0.55 * (1 - t / 1.2)) + ")");
          g.addColorStop(1, "rgba(255,255,255,0)");
          ctx.strokeStyle = g;
          ctx.lineWidth = Math.max(2, thick);
          ctx.stroke();
        }
        var dtP = 1 / 60;
        for (var i = 0; i < state.splashParticles.length; i++) {
          var p = state.splashParticles[i];
          p.x += p.vx * dtP;
          p.y += p.vy * dtP;
          p.vy += 90 * dtP;
          p.life -= p.decay * dtP;
          p.wobble += dtP * 6;
          if (p.life <= 0) continue;
          var pr = p.r * p.life;
          var px = p.x + Math.sin(p.wobble) * 3;
          var py = p.y;
          var dg = ctx.createRadialGradient(px, py, 0, px, py, pr * 1.4);
          dg.addColorStop(0, "rgba(255,255,255," + (0.7 * p.life) + ")");
          dg.addColorStop(0.4, "rgba(167, 139, 250," + (0.55 * p.life) + ")");
          dg.addColorStop(1, "rgba(37, 99, 235, 0)");
          ctx.fillStyle = dg;
          ctx.beginPath();
          ctx.arc(px, py, pr * 1.4, 0, Math.PI * 2);
          ctx.fill();
        }
        state.splashParticles = state.splashParticles.filter(function (p) { return p.life > 0; });
        ctx.restore();
      }
    }
  };
})();

// --- BLOBS THEME ---
(function () {
  function softBlobPath(ctx, cx, cy, R, phase, energy, seed) {
    const steps = 56;
    ctx.beginPath();
    for (let i = 0; i <= steps; i++) {
      const a = (i / steps) * Math.PI * 2;
      const puff =
        0.72 +
        0.18 * Math.sin(a * 2.4 + phase + seed) +
        0.14 * Math.sin(a * 3.7 - phase * 1.1 + seed * 0.7) +
        0.10 * Math.sin(a * 5.2 + phase * 0.6) +
        0.07 * Math.sin(a * 7.1 - phase * 1.8) * (0.4 + energy);
      const r = R * puff;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r * 0.92;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  function drawEqIcon(ctx, cx, cy, size, alpha) {
    const s = size, half = s / 2;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.translate(cx, cy);
    const r = s * 0.18;
    ctx.beginPath();
    ctx.moveTo(-half + r, -half);
    ctx.lineTo(half - r, -half);
    ctx.quadraticCurveTo(half, -half, half, -half + r);
    ctx.lineTo(half, half - r);
    ctx.quadraticCurveTo(half, half, half - r, half);
    ctx.lineTo(-half + r, half);
    ctx.quadraticCurveTo(-half, half, -half, half - r);
    ctx.lineTo(-half, -half + r);
    ctx.quadraticCurveTo(-half, -half, -half + r, -half);
    ctx.closePath();
    ctx.fillStyle = "rgba(30, 58, 138, 0.85)";
    ctx.fill();
    ctx.strokeStyle = "rgba(96, 165, 250, 0.45)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    const bars = [0.35, 0.7, 1, 0.55, 0.85];
    const barW = s * 0.1, gap = s * 0.06;
    const totalW = bars.length * barW + (bars.length - 1) * gap;
    let x0 = -totalW / 2;
    for (let i = 0; i < bars.length; i++) {
      const bh = s * 0.42 * bars[i];
      const bx = x0 + i * (barW + gap), by = -bh / 2;
      const br = barW * 0.35;
      ctx.beginPath();
      ctx.moveTo(bx + br, by);
      ctx.lineTo(bx + barW - br, by);
      ctx.quadraticCurveTo(bx + barW, by, bx + barW, by + br);
      ctx.lineTo(bx + barW, by + bh - br);
      ctx.quadraticCurveTo(bx + barW, by + bh, bx + barW - br, by + bh);
      ctx.lineTo(bx + br, by + bh);
      ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - br);
      ctx.lineTo(bx, by + br);
      ctx.quadraticCurveTo(bx, by, bx + br, by);
      ctx.closePath();
      ctx.fillStyle = "rgba(147, 197, 253, 0.95)";
      ctx.fill();
    }
    ctx.restore();
  }

  window.PulseVizThemes.blobs = {
    id: "blobs",
    name: "Blobs",
    update: function (state) { state.splash *= 0.9; },
    draw: function (ctx, w, h, state) {
      const { dt, flowLevel, flowBass, flowTreble, beatEnergy, crazy } = state;
      state.flowT += dt * (0.35 + flowLevel * 0.9 + flowBass * 0.7);
      state.cloudPhase += dt * (0.55 + flowBass * 1.1 + crazy * 1.2);
      const pulse = 0.5 + 0.5 * Math.sin(state.flowT * 1.8);
      state.logoPulse += ((0.92 + pulse * 0.08 + flowBass * 0.14 + flowLevel * 0.06) - state.logoPulse) * 0.12;

      const cx = w * 0.5, cy = h * 0.42, base = Math.min(w, h);
      const energy = Math.min(1.2, beatEnergy);

      function blobGlow(bx, by, rad, strength) {
        const g = ctx.createRadialGradient(bx, by, 0, bx, by, rad);
        g.addColorStop(0, "rgba(99, 102, 241," + (0.22 * strength) + ")");
        g.addColorStop(0.45, "rgba(59, 130, 246," + (0.12 * strength) + ")");
        g.addColorStop(1, "rgba(3, 7, 18, 0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(bx, by, rad, 0, Math.PI * 2);
        ctx.fill();
      }

      const leftX = w * 0.22 + Math.sin(state.flowT * 0.4) * base * 0.012;
      const leftY = cy + Math.cos(state.flowT * 0.35) * base * 0.018;
      const rightX = w * 0.78 + Math.sin(state.flowT * 0.38 + 1) * base * 0.012;
      const rightY = cy + Math.cos(state.flowT * 0.42 + 0.5) * base * 0.016;
      const midX = cx + Math.sin(state.flowT * 0.25) * base * 0.008;
      const midY = cy + Math.cos(state.flowT * 0.3) * base * 0.01;
      const leftR = base * (0.11 + flowLevel * 0.025 + flowBass * 0.02) * state.logoPulse;
      const rightR = base * (0.105 + flowLevel * 0.022 + flowTreble * 0.02) * state.logoPulse;
      const midR = base * (0.20 + flowLevel * 0.04 + flowBass * 0.035) * state.logoPulse;

      blobGlow(leftX, leftY, leftR * 2.4, 0.7 + energy * 0.4);
      blobGlow(rightX, rightY, rightR * 2.4, 0.7 + energy * 0.4);
      blobGlow(midX, midY, midR * 2.6, 0.9 + energy * 0.5);

      function paintBlob(bx, by, R, phase, seed, alpha) {
        ctx.save();
        ctx.globalAlpha = alpha;
        softBlobPath(ctx, bx, by, R * 1.15, phase, energy, seed);
        const halo = ctx.createRadialGradient(bx, by, R * 0.15, bx, by, R * 1.4);
        halo.addColorStop(0, "rgba(167, 139, 250, 0.35)");
        halo.addColorStop(0.55, "rgba(99, 102, 241, 0.18)");
        halo.addColorStop(1, "rgba(37, 99, 235, 0)");
        ctx.fillStyle = halo;
        ctx.fill();
        softBlobPath(ctx, bx, by, R, phase, energy, seed);
        const fill = ctx.createLinearGradient(bx - R, by - R, bx + R, by + R);
        fill.addColorStop(0, "rgba(196, 181, 253, 0.95)");
        fill.addColorStop(0.35, "rgba(147, 197, 253, 0.88)");
        fill.addColorStop(0.7, "rgba(129, 140, 248, 0.9)");
        fill.addColorStop(1, "rgba(79, 70, 229, 0.82)");
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = "rgba(224, 231, 255," + (0.22 + energy * 0.15) + ")";
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
      }

      paintBlob(leftX, leftY, leftR, state.cloudPhase, 0.3, 0.92);
      paintBlob(rightX, rightY, rightR, state.cloudPhase + 1.4, 1.1, 0.92);
      paintBlob(midX, midY, midR, state.cloudPhase + 0.6, 0.7, 1);
      drawEqIcon(ctx, midX, midY, midR * 0.55 * state.logoPulse, 0.92);

      if (energy > 0.35) {
        ctx.save();
        const n = 6 + Math.floor(energy * 8);
        for (let i = 0; i < n; i++) {
          const a = (i / n) * Math.PI * 2 + state.flowT * 0.8;
          const dist = midR * (1.15 + 0.25 * Math.sin(state.flowT * 2 + i));
          const px = midX + Math.cos(a) * dist;
          const py = midY + Math.sin(a) * dist * 0.9;
          const pr = 2 + energy * 4 * (0.5 + 0.5 * Math.sin(state.flowT * 3 + i));
          const pg = ctx.createRadialGradient(px, py, 0, px, py, pr * 2);
          pg.addColorStop(0, "rgba(199, 210, 254," + (0.45 * energy) + ")");
          pg.addColorStop(1, "rgba(99, 102, 241, 0)");
          ctx.fillStyle = pg;
          ctx.beginPath();
          ctx.arc(px, py, pr * 2, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
    }
  };
})();

// --- SOLAR: one planet + fast orbiting blob ---
(function () {
  function softBlob(ctx, cx, cy, R, phase, energy, seed) {
    var steps = 52;
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var a = (i / steps) * Math.PI * 2;
      var puff =
        0.74 +
        0.15 * Math.sin(a * 2.4 + phase + seed) +
        0.11 * Math.sin(a * 3.9 - phase * 1.15 + seed * 0.7) +
        0.08 * Math.sin(a * 5.2 + phase * 0.6) +
        0.06 * Math.sin(a * 7.1 - phase * 1.7) * (0.4 + energy);
      var r = R * puff;
      var x = cx + Math.cos(a) * r;
      var y = cy + Math.sin(a) * r * 0.93;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  var orbitAngle = 0;
  var orbitSpeed = 1.2; // grows over time / with energy

  window.PulseVizThemes.solar = {
    id: "solar",
    name: "Solar",
    update: function (state) { state.splash *= 0.85; },
    draw: function (ctx, w, h, state) {
      var dt = state.dt;
      var flowLevel = state.flowLevel;
      var flowBass = state.flowBass;
      var flowTreble = state.flowTreble;
      var beatEnergy = state.beatEnergy;
      var crazy = state.crazy;

      state.flowT += dt * (0.35 + flowLevel * 0.85 + flowBass * 0.6);
      state.cloudPhase += dt * (0.5 + flowBass * 1.0);

      var energy = Math.min(1.5, beatEnergy);
      var pulse = 0.5 + 0.5 * Math.sin(state.flowT * 2.0);
      state.logoPulse += ((0.93 + pulse * 0.09 + flowBass * 0.16 + flowLevel * 0.07) - state.logoPulse) * 0.12;

      var cx = w * 0.5;
      var cy = h * 0.46;
      var scale = Math.min(w, h);

      // Ambient glow
      var bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, scale * 0.55);
      bg.addColorStop(0, "rgba(76, 29, 149," + (0.32 + energy * 0.2) + ")");
      bg.addColorStop(0.5, "rgba(37, 99, 235," + (0.1 + energy * 0.08) + ")");
      bg.addColorStop(1, "rgba(3, 7, 18, 0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // ===== PLANET (center) =====
      var planetR = scale * (0.16 + flowBass * 0.035 + flowLevel * 0.025) * state.logoPulse;

      // Soft outer atmosphere
      for (var c = 3; c >= 1; c--) {
        var ar = planetR * (1.25 + c * 0.45 + energy * 0.12);
        softBlob(ctx, cx, cy, ar, state.cloudPhase * 0.5, energy, 0.15 * c);
        var ag = ctx.createRadialGradient(cx, cy, planetR * 0.3, cx, cy, ar * 1.15);
        var aa = (0.2 / c) * (0.75 + energy * 0.45);
        ag.addColorStop(0, "rgba(167, 139, 250," + aa + ")");
        ag.addColorStop(0.55, "rgba(99, 102, 241," + (aa * 0.4) + ")");
        ag.addColorStop(1, "rgba(37, 99, 235, 0)");
        ctx.fillStyle = ag;
        ctx.fill();
      }

      // Planet body
      softBlob(ctx, cx, cy, planetR, state.cloudPhase, energy, 0.4);
      var pf = ctx.createLinearGradient(cx - planetR, cy - planetR, cx + planetR, cy + planetR);
      pf.addColorStop(0, "rgba(237, 233, 254, 0.95)");
      pf.addColorStop(0.3, "rgba(196, 181, 253, 0.92)");
      pf.addColorStop(0.65, "rgba(129, 140, 248, 0.9)");
      pf.addColorStop(1, "rgba(79, 70, 229, 0.88)");
      ctx.fillStyle = pf;
      ctx.fill();
      ctx.strokeStyle = "rgba(224, 231, 255," + (0.28 + energy * 0.2) + ")";
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Surface puffs
      softBlob(ctx, cx - planetR * 0.45, cy + planetR * 0.25, planetR * 0.38, state.cloudPhase + 1.2, energy, 1.1);
      ctx.fillStyle = "rgba(147, 197, 253, 0.55)";
      ctx.fill();
      softBlob(ctx, cx + planetR * 0.4, cy - planetR * 0.2, planetR * 0.32, state.cloudPhase + 2.0, energy, 2.0);
      ctx.fillStyle = "rgba(167, 139, 250, 0.5)";
      ctx.fill();

      // Faint orbit ring
      var orbitR = planetR * (2.15 + flowLevel * 0.15);
      ctx.beginPath();
      ctx.ellipse(cx, cy, orbitR, orbitR * 0.55, 0.15, 0, Math.PI * 2);
      ctx.strokeStyle = "rgba(147, 197, 253," + (0.12 + energy * 0.1) + ")";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // ===== SPEED: ramps with music, keeps climbing a bit over time =====
      var targetSpeed = 1.0 + flowLevel * 4.5 + flowBass * 3.5 + flowTreble * 2.0 + crazy * 2.5;
      // slow drift upward so it gets "super fast over time"
      orbitSpeed += dt * (0.08 + energy * 0.25);
      // ease toward target, but never fully forget the accumulated speed
      orbitSpeed += (targetSpeed + orbitSpeed * 0.15 - orbitSpeed) * 0.04;
      // soft cap so it stays readable
      if (orbitSpeed > 28) orbitSpeed = 28;

      orbitAngle += dt * orbitSpeed;

      // Orbiter position on tilted ellipse
      var ox = cx + Math.cos(orbitAngle) * orbitR;
      var oy = cy + Math.sin(orbitAngle) * orbitR * 0.55;

      // Trail (longer when faster)
      var trailN = Math.min(24, 8 + Math.floor(orbitSpeed * 0.7));
      ctx.beginPath();
      for (var t = 0; t < trailN; t++) {
        var ta = orbitAngle - t * (0.12 + orbitSpeed * 0.008);
        var tx = cx + Math.cos(ta) * orbitR;
        var ty = cy + Math.sin(ta) * orbitR * 0.55;
        if (t === 0) ctx.moveTo(tx, ty); else ctx.lineTo(tx, ty);
      }
      var trailA = Math.min(0.55, 0.15 + orbitSpeed * 0.02 + energy * 0.15);
      ctx.strokeStyle = "rgba(167, 139, 250," + trailA + ")";
      ctx.lineWidth = 2 + Math.min(4, orbitSpeed * 0.12);
      ctx.stroke();

      // ===== ORBITER BLOB =====
      var orbR = scale * (0.035 + flowTreble * 0.015 + flowLevel * 0.01) * state.logoPulse;
      // glow
      var og = ctx.createRadialGradient(ox, oy, 0, ox, oy, orbR * 2.8);
      og.addColorStop(0, "rgba(196, 181, 253," + (0.45 + energy * 0.25) + ")");
      og.addColorStop(0.5, "rgba(99, 102, 241, 0.2)");
      og.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = og;
      ctx.beginPath();
      ctx.arc(ox, oy, orbR * 2.8, 0, Math.PI * 2);
      ctx.fill();

      softBlob(ctx, ox, oy, orbR, state.cloudPhase * 1.4 + orbitAngle, energy, 3.5);
      var of = ctx.createLinearGradient(ox - orbR, oy - orbR, ox + orbR, oy + orbR);
      of.addColorStop(0, "rgba(224, 231, 255, 0.95)");
      of.addColorStop(0.4, "rgba(147, 197, 253, 0.92)");
      of.addColorStop(1, "rgba(99, 102, 241, 0.85)");
      ctx.fillStyle = of;
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255," + (0.3 + energy * 0.2) + ")";
      ctx.lineWidth = 1.2;
      ctx.stroke();

      // Speed streaks when very fast
      if (orbitSpeed > 8) {
        var streak = Math.min(1, (orbitSpeed - 8) / 12);
        for (var s = 0; s < 5; s++) {
          var sa = orbitAngle - s * 0.04;
          var sx = cx + Math.cos(sa) * orbitR;
          var sy = cy + Math.sin(sa) * orbitR * 0.55;
          ctx.beginPath();
          ctx.arc(sx, sy, orbR * (0.3 - s * 0.04), 0, Math.PI * 2);
          ctx.fillStyle = "rgba(199, 210, 254," + (streak * (0.4 - s * 0.06)) + ")";
          ctx.fill();
        }
      }

      // Beat pulse from planet
      if (energy > 0.5) {
        var burst = (state.flowT * 1.7) % 1.25;
        if (burst < 1) {
          softBlob(ctx, cx, cy, planetR * (1.4 + burst * 3.5) * (0.9 + energy * 0.25), state.cloudPhase + burst, energy, 8);
          ctx.strokeStyle = "rgba(167, 139, 250," + ((1 - burst) * 0.4 * energy) + ")";
          ctx.lineWidth = 2 + energy * 2;
          ctx.stroke();
        }
      }
    }
  };
})();

// --- RUBBER DUCKS ON A WAVE ---
(function () {
  function duckPath(ctx, x, y, s, facing) {
    // facing: 1 = right, -1 = left
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(facing, 1);

    // Body
    ctx.beginPath();
    ctx.ellipse(0, 0, s * 0.55, s * 0.38, 0, 0, Math.PI * 2);
    ctx.fill();

    // Head
    ctx.beginPath();
    ctx.arc(s * 0.42, -s * 0.28, s * 0.28, 0, Math.PI * 2);
    ctx.fill();

    // Beak
    ctx.beginPath();
    ctx.moveTo(s * 0.62, -s * 0.28);
    ctx.lineTo(s * 0.92, -s * 0.22);
    ctx.lineTo(s * 0.62, -s * 0.16);
    ctx.closePath();
    ctx.fill();

    // Eye
    ctx.beginPath();
    ctx.arc(s * 0.5, -s * 0.32, s * 0.06, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
    ctx.fill();

    // Wing
    ctx.beginPath();
    ctx.ellipse(-s * 0.05, s * 0.02, s * 0.22, s * 0.14, -0.3, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.fill();

    ctx.restore();
  }

  var duckCount = 7;
  var ducks = [];
  for (var i = 0; i < duckCount; i++) {
    ducks.push({
      x: Math.random(),           // 0..1 along width
      phase: Math.random() * Math.PI * 2,
      size: 0.7 + Math.random() * 0.5,
      facing: Math.random() > 0.5 ? 1 : -1,
      bob: Math.random() * Math.PI * 2
    });
  }
  var waveSpeed = 0.8; // accumulates over time

  window.PulseVizThemes.ducks = {
    id: "ducks",
    name: "Ducks",
    update: function (state) { state.splash *= 0.9; },
    draw: function (ctx, w, h, state) {
      var dt = state.dt;
      var flowLevel = state.flowLevel;
      var flowBass = state.flowBass;
      var flowTreble = state.flowTreble;
      var beatEnergy = state.beatEnergy;
      var crazy = state.crazy;

      state.flowT += dt * (0.4 + flowLevel * 0.7);
      state.cloudPhase += dt * (0.5 + flowBass);

      var energy = Math.min(1.4, beatEnergy);
      var pulse = 0.5 + 0.5 * Math.sin(state.flowT * 1.8);
      state.logoPulse += ((0.94 + pulse * 0.08 + flowBass * 0.12) - state.logoPulse) * 0.1;

      // Speed ramps with music + slowly climbs forever
      var target = 0.7 + flowLevel * 2.8 + flowBass * 2.2 + flowTreble * 1.2 + crazy * 1.5;
      waveSpeed += dt * (0.06 + energy * 0.2);
      waveSpeed += (target + waveSpeed * 0.12 - waveSpeed) * 0.05;
      if (waveSpeed > 18) waveSpeed = 18;

      state.flowT += dt * waveSpeed * 0.15; // extra scroll from speed

      // Ambient top glow
      var bg = ctx.createRadialGradient(w * 0.5, h * 0.3, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.7);
      bg.addColorStop(0, "rgba(76, 29, 149," + (0.2 + energy * 0.15) + ")");
      bg.addColorStop(0.5, "rgba(37, 99, 235," + (0.08 + energy * 0.06) + ")");
      bg.addColorStop(1, "rgba(3, 7, 18, 0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Wave surface
      var midY = h * 0.58;
      var baseAmp = h * (0.06 + flowLevel * 0.1 + flowBass * 0.06);
      var steps = Math.max(80, Math.floor(w / 5));

      function surfaceY(nx) {
        // nx is 0..1
        return midY - (
          Math.sin(nx * Math.PI * 2 * 1.4 - state.flowT * 0.9) * 1.0 +
          Math.sin(nx * Math.PI * 2 * 0.7 - state.flowT * 0.55) * 0.55 +
          Math.sin(nx * Math.PI * 2 * 2.3 + state.flowT * 0.35) * 0.25
        ) * baseAmp;
      }

      // Water fill
      ctx.beginPath();
      ctx.moveTo(0, h);
      for (var i = 0; i <= steps; i++) {
        var nx = i / steps;
        ctx.lineTo(nx * w, surfaceY(nx));
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      var water = ctx.createLinearGradient(0, midY - baseAmp - 20, 0, h);
      water.addColorStop(0, "rgba(147, 197, 253, 0.55)");
      water.addColorStop(0.35, "rgba(99, 102, 241, 0.45)");
      water.addColorStop(0.7, "rgba(67, 56, 202, 0.4)");
      water.addColorStop(1, "rgba(30, 27, 75, 0.55)");
      ctx.fillStyle = water;
      ctx.fill();

      // Surface highlight line
      ctx.beginPath();
      for (var i = 0; i <= steps; i++) {
        var nx = i / steps;
        var y = surfaceY(nx);
        if (i === 0) ctx.moveTo(nx * w, y); else ctx.lineTo(nx * w, y);
      }
      ctx.strokeStyle = "rgba(224, 231, 255," + (0.35 + energy * 0.25) + ")";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Foam peaks on high energy
      if (energy > 0.25) {
        for (var i = 0; i <= steps; i += 3) {
          var nx = i / steps;
          var y = surfaceY(nx);
          var local = Math.abs(Math.sin(nx * Math.PI * 4 - state.flowT));
          if (local > 0.85) {
            ctx.beginPath();
            ctx.arc(nx * w, y - 2, 2 + energy * 3 * local, 0, Math.PI * 2);
            ctx.fillStyle = "rgba(255,255,255," + (0.25 + energy * 0.3) + ")";
            ctx.fill();
          }
        }
      }

      // ===== DUCKS =====
      var duckBase = Math.min(w, h) * 0.035;
      for (var d = 0; d < ducks.length; d++) {
        var duck = ducks[d];
        // Move along the wave — faster with waveSpeed
        var dir = duck.facing;
        duck.x += dir * dt * (0.04 + waveSpeed * 0.012 + flowLevel * 0.02);
        // Wrap
        if (duck.x > 1.08) { duck.x = -0.08; duck.facing = Math.random() > 0.3 ? 1 : -1; }
        if (duck.x < -0.08) { duck.x = 1.08; duck.facing = Math.random() > 0.3 ? -1 : 1; }

        duck.bob += dt * (2.5 + waveSpeed * 0.15 + flowBass * 1.5);
        var nx = duck.x;
        var sy = surfaceY(nx);
        // Slope for tilt
        var slope = (surfaceY(Math.min(1, nx + 0.01)) - surfaceY(Math.max(0, nx - 0.01))) / (0.02 * w);
        var tilt = Math.atan(slope) * 0.7;
        var bobY = Math.sin(duck.bob) * (3 + energy * 4);

        var dx = nx * w;
        var dy = sy - duckBase * duck.size * 0.35 + bobY;
        var s = duckBase * duck.size * state.logoPulse;

        ctx.save();
        ctx.translate(dx, dy);
        ctx.rotate(tilt);

        // Duck body color — warm yellow but tinted into purple-blue world with soft glow
        // Soft shadow on water
        ctx.beginPath();
        ctx.ellipse(0, s * 0.25, s * 0.5, s * 0.12, 0, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(30, 27, 75, 0.25)";
        ctx.fill();

        // Yellow rubber duck (classic look) with purple rim light
        ctx.fillStyle = "#fde047";
        duckPath(ctx, 0, 0, s, duck.facing);

        // Purple-blue rim / wet sheen so it fits the palette
        ctx.globalCompositeOperation = "source-atop";
        // redraw isn't easy; instead draw a soft violet edge
        ctx.globalCompositeOperation = "source-over";
        ctx.beginPath();
        ctx.ellipse(0, 0, s * 0.55, s * 0.38, 0, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(167, 139, 250," + (0.25 + energy * 0.2) + ")";
        ctx.lineWidth = 1.2;
        ctx.stroke();

        // Beak accent already in path; recolor beak area roughly
        ctx.fillStyle = "#fb923c";
        ctx.beginPath();
        var bf = duck.facing;
        ctx.moveTo(bf * s * 0.62, -s * 0.28);
        ctx.lineTo(bf * s * 0.9, -s * 0.22);
        ctx.lineTo(bf * s * 0.62, -s * 0.16);
        ctx.closePath();
        ctx.fill();

        // Eye
        ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
        ctx.beginPath();
        ctx.arc(bf * s * 0.5, -s * 0.32, s * 0.055, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      // Splash droplets when bass hits
      if (energy > 0.55) {
        for (var p = 0; p < 12; p++) {
          var px = ((p * 0.17 + state.flowT * 0.1) % 1) * w;
          var py = surfaceY(px / w) - (8 + energy * 20) * Math.abs(Math.sin(state.flowT * 3 + p));
          ctx.beginPath();
          ctx.arc(px, py, 1.5 + energy * 2, 0, Math.PI * 2);
          ctx.fillStyle = "rgba(191, 219, 254," + (0.3 + energy * 0.3) + ")";
          ctx.fill();
        }
      }
    }
  };
})();

// --- ORANGE CAT THEME (Looney Tunes character) ---
(function () {
  var cat = {
    x: 0.5, y: 0.64,
    facing: 1,
    phase: 0,
    dance: 0,
    mood: "walk",
    moodT: 0,
    clawT: 0,
    clawSide: 1,
    blink: 0,
    tail: 0,
    squash: 1,
    stretch: 1,
    eyePop: 0,
    grin: 0,
    hop: 0
  };

  // Classic LT palette
  var ORANGE = "#f97316";
  var ORANGE_DK = "#c2410c";
  var ORANGE_LT = "#fdba74";
  var CREAM = "#fff7ed";
  var INK = "#1c1917";
  var NOSE = "#e11d48";
  var PINK = "#fda4af";

  function drawLTCat(ctx, cx, cy, s, state, energy) {
    var facing = cat.facing;
    var phase = cat.phase;
    var clawT = cat.clawT;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(facing * cat.stretch, cat.squash);

    // Drop shadow
    ctx.beginPath();
    ctx.ellipse(0, s * 0.72, s * 0.65, s * 0.12, 0, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    ctx.fill();

    var bob = Math.sin(phase * 2) * s * 0.05;
    if (cat.mood === "dance") bob = -Math.abs(Math.sin(state.flowT * 10)) * s * 0.14;
    if (cat.mood === "claw") bob = -s * 0.06;
    ctx.translate(0, bob + cat.hop);

    // ---- RUBBER-HOSE LEGS ----
    var swing = Math.sin(phase) * 0.55;
    if (cat.mood === "dance") swing = Math.sin(state.flowT * 11) * 0.85;
    if (cat.mood === "claw" || cat.mood === "sit") swing = 0.05;

    function hoseLeg(lx, ang, len, thick) {
      ctx.save();
      ctx.translate(lx, s * 0.22);
      ctx.rotate(ang);
      // hose
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(thick * 0.3 * Math.sin(phase), len * 0.5, 0, len);
      ctx.strokeStyle = ORANGE;
      ctx.lineWidth = thick;
      ctx.lineCap = "round";
      ctx.stroke();
      ctx.strokeStyle = INK;
      ctx.lineWidth = Math.max(2, thick * 0.12);
      ctx.stroke();
      // white glove / big cartoon paw (LT trademark)
      ctx.beginPath();
      ctx.ellipse(0, len, thick * 0.85, thick * 0.55, 0, 0, Math.PI * 2);
      ctx.fillStyle = CREAM;
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2;
      ctx.stroke();
      // three fingers
      for (var f = -1; f <= 1; f++) {
        ctx.beginPath();
        ctx.arc(f * thick * 0.35, len + thick * 0.25, thick * 0.22, 0, Math.PI * 2);
        ctx.fillStyle = CREAM;
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }

    if (cat.mood !== "claw") {
      hoseLeg(-s * 0.3, swing, s * 0.48, s * 0.18);
      hoseLeg(s * 0.25, -swing, s * 0.48, s * 0.18);
      hoseLeg(-s * 0.05, -swing * 0.55, s * 0.44, s * 0.16);
      hoseLeg(s * 0.4, swing * 0.55, s * 0.44, s * 0.16);
    } else {
      hoseLeg(-s * 0.22, 0.25, s * 0.45, s * 0.17);
      hoseLeg(s * 0.28, -0.2, s * 0.45, s * 0.17);
    }

    // ---- TAIL (springy) ----
    cat.tail += 0.14 + energy * 0.12;
    ctx.beginPath();
    ctx.moveTo(-s * 0.55, s * 0.05);
    var t1 = -s * 0.9 + Math.sin(cat.tail) * s * 0.3;
    var t2 = -s * 0.45 + Math.cos(cat.tail * 1.5) * s * 0.25;
    var t3 = -s * 1.15 + Math.sin(cat.tail * 1.2 + 0.8) * s * 0.25;
    var t4 = -s * 0.85 + Math.cos(cat.tail * 0.9) * s * 0.2;
    ctx.bezierCurveTo(-s * 0.7, -s * 0.15, t1, t2, t3, t4);
    ctx.strokeStyle = ORANGE;
    ctx.lineWidth = s * 0.16;
    ctx.lineCap = "round";
    ctx.stroke();
    ctx.strokeStyle = INK;
    ctx.lineWidth = Math.max(2, s * 0.03);
    ctx.stroke();
    // tip
    ctx.beginPath();
    ctx.arc(t3, t4, s * 0.11, 0, Math.PI * 2);
    ctx.fillStyle = ORANGE_LT;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();

    // ---- BODY (pear-shaped, classic cartoon) ----
    ctx.beginPath();
    ctx.ellipse(0, s * 0.02, s * 0.58, s * 0.48, 0, 0, Math.PI * 2);
    var bg = ctx.createRadialGradient(-s * 0.2, -s * 0.15, 0, 0, 0, s * 0.65);
    bg.addColorStop(0, ORANGE_LT);
    bg.addColorStop(0.5, ORANGE);
    bg.addColorStop(1, ORANGE_DK);
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = s * 0.045;
    ctx.stroke();

    // Cream belly oval
    ctx.beginPath();
    ctx.ellipse(s * 0.08, s * 0.12, s * 0.32, s * 0.26, 0, 0, Math.PI * 2);
    ctx.fillStyle = CREAM;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Thick bold stripes (Sylvester-ish)
    ctx.strokeStyle = ORANGE_DK;
    ctx.lineWidth = s * 0.07;
    ctx.lineCap = "round";
    for (var si = -2; si <= 2; si++) {
      ctx.beginPath();
      ctx.moveTo(si * s * 0.16 - s * 0.22, -s * 0.32);
      ctx.quadraticCurveTo(si * s * 0.14, s * 0.05, si * s * 0.1 + s * 0.02, s * 0.32);
      ctx.stroke();
    }

    // ---- HEAD (almost as big as body — LT proportion) ----
    var hx = s * 0.42;
    var hy = -s * 0.48;
    if (cat.mood === "dance") {
      hy += Math.sin(state.flowT * 12) * s * 0.07;
      hx += Math.cos(state.flowT * 9) * s * 0.06;
    }
    var hr = s * 0.5 * (1 + cat.eyePop * 0.12);

    // Head
    ctx.beginPath();
    ctx.arc(hx, hy, hr, 0, Math.PI * 2);
    var hg = ctx.createRadialGradient(hx - hr * 0.25, hy - hr * 0.25, 0, hx, hy, hr);
    hg.addColorStop(0, ORANGE_LT);
    hg.addColorStop(0.55, ORANGE);
    hg.addColorStop(1, ORANGE_DK);
    ctx.fillStyle = hg;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = s * 0.045;
    ctx.stroke();

    // Muzzle / cheeks (cream)
    ctx.beginPath();
    ctx.ellipse(hx + hr * 0.05, hy + hr * 0.35, hr * 0.45, hr * 0.32, 0, 0, Math.PI * 2);
    ctx.fillStyle = CREAM;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Ears — tall triangles with black outline
    function ear(ex, ey, flip) {
      ctx.beginPath();
      ctx.moveTo(ex, ey);
      ctx.lineTo(ex + flip * hr * 0.15, ey - hr * 1.05);
      ctx.lineTo(ex + flip * hr * 0.7, ey - hr * 0.1);
      ctx.closePath();
      ctx.fillStyle = ORANGE;
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = s * 0.035;
      ctx.stroke();
      // inner pink
      ctx.beginPath();
      ctx.moveTo(ex + flip * hr * 0.12, ey - hr * 0.1);
      ctx.lineTo(ex + flip * hr * 0.2, ey - hr * 0.7);
      ctx.lineTo(ex + flip * hr * 0.48, ey - hr * 0.12);
      ctx.closePath();
      ctx.fillStyle = PINK;
      ctx.fill();
    }
    ear(hx - hr * 0.55, hy - hr * 0.35, -1);
    ear(hx + hr * 0.2, hy - hr * 0.45, 1);

    // ---- FACE ----
    var eyeY = hy - hr * 0.05;
    var eyeOpen = cat.blink > 0 ? 0.08 : 1;
    eyeOpen *= (1 + cat.eyePop * 0.5);

    function bigEye(ex) {
      var er = hr * 0.32 * eyeOpen;
      if (er < hr * 0.05) {
        // blink line
        ctx.beginPath();
        ctx.moveTo(ex - hr * 0.28, eyeY);
        ctx.lineTo(ex + hr * 0.28, eyeY);
        ctx.strokeStyle = INK;
        ctx.lineWidth = s * 0.04;
        ctx.stroke();
        return;
      }
      // white sclera
      ctx.beginPath();
      ctx.ellipse(ex, eyeY, er * 1.05, er * 1.15, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#fff";
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = s * 0.03;
      ctx.stroke();
      // pupil
      var look = (cat.mood === "claw" ? 0.35 : 0.12) * er;
      ctx.beginPath();
      ctx.arc(ex + look, eyeY + er * 0.08, er * 0.5, 0, Math.PI * 2);
      ctx.fillStyle = INK;
      ctx.fill();
      // pie-cut shine (classic)
      ctx.beginPath();
      ctx.arc(ex + look - er * 0.18, eyeY - er * 0.2, er * 0.18, 0, Math.PI * 2);
      ctx.fillStyle = "#fff";
      ctx.fill();
      // tiny second shine
      ctx.beginPath();
      ctx.arc(ex + look + er * 0.15, eyeY + er * 0.15, er * 0.08, 0, Math.PI * 2);
      ctx.fill();
    }
    bigEye(hx - hr * 0.3);
    bigEye(hx + hr * 0.35);

    // Eyebrows (expressive)
    ctx.strokeStyle = INK;
    ctx.lineWidth = s * 0.04;
    ctx.lineCap = "round";
    if (cat.mood === "claw" || cat.eyePop > 0.4) {
      // angry / surprised arches
      ctx.beginPath();
      ctx.moveTo(hx - hr * 0.55, eyeY - hr * 0.4);
      ctx.quadraticCurveTo(hx - hr * 0.3, eyeY - hr * 0.55, hx - hr * 0.05, eyeY - hr * 0.38);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(hx + hr * 0.1, eyeY - hr * 0.38);
      ctx.quadraticCurveTo(hx + hr * 0.35, eyeY - hr * 0.55, hx + hr * 0.6, eyeY - hr * 0.4);
      ctx.stroke();
    } else if (cat.mood === "dance") {
      ctx.beginPath();
      ctx.moveTo(hx - hr * 0.5, eyeY - hr * 0.35);
      ctx.lineTo(hx - hr * 0.1, eyeY - hr * 0.42);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(hx + hr * 0.15, eyeY - hr * 0.42);
      ctx.lineTo(hx + hr * 0.55, eyeY - hr * 0.35);
      ctx.stroke();
    }

    // Nose — small triangle
    ctx.beginPath();
    ctx.moveTo(hx + hr * 0.05, hy + hr * 0.22);
    ctx.lineTo(hx - hr * 0.1, hy + hr * 0.38);
    ctx.lineTo(hx + hr * 0.2, hy + hr * 0.38);
    ctx.closePath();
    ctx.fillStyle = NOSE;
    ctx.fill();
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Mouth
    ctx.strokeStyle = INK;
    ctx.lineWidth = s * 0.04;
    ctx.lineCap = "round";
    if (cat.grin > 0.4 || cat.mood === "claw") {
      // huge LT grin
      ctx.beginPath();
      ctx.arc(hx + hr * 0.05, hy + hr * 0.35, hr * (0.32 + cat.grin * 0.12), 0.15, Math.PI - 0.15);
      ctx.stroke();
      // upper teeth row
      if (cat.grin > 0.55 || cat.mood === "claw") {
        ctx.fillStyle = "#fff";
        ctx.strokeStyle = INK;
        ctx.lineWidth = 1.5;
        for (var ti = 0; ti < 4; ti++) {
          var tx = hx - hr * 0.15 + ti * hr * 0.12;
          ctx.beginPath();
          ctx.moveTo(tx, hy + hr * 0.48);
          ctx.lineTo(tx + hr * 0.05, hy + hr * 0.62);
          ctx.lineTo(tx + hr * 0.1, hy + hr * 0.48);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      }
    } else {
      // small cat mouth
      ctx.beginPath();
      ctx.moveTo(hx + hr * 0.05, hy + hr * 0.4);
      ctx.quadraticCurveTo(hx - hr * 0.05, hy + hr * 0.55, hx - hr * 0.22, hy + hr * 0.42);
      ctx.moveTo(hx + hr * 0.05, hy + hr * 0.4);
      ctx.quadraticCurveTo(hx + hr * 0.15, hy + hr * 0.55, hx + hr * 0.3, hy + hr * 0.42);
      ctx.stroke();
    }

    // Long whiskers
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = Math.max(1.5, s * 0.018);
    for (var wi = -1; wi <= 1; wi++) {
      ctx.beginPath();
      ctx.moveTo(hx - hr * 0.2, hy + hr * 0.32 + wi * hr * 0.14);
      ctx.lineTo(hx - hr * 1.15, hy + hr * 0.1 + wi * hr * 0.25);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(hx + hr * 0.35, hy + hr * 0.32 + wi * hr * 0.14);
      ctx.lineTo(hx + hr * 1.2, hy + hr * 0.1 + wi * hr * 0.25);
      ctx.stroke();
    }

    // ---- GIANT CLAW ARM ----
    if (clawT > 0) {
      var prog = clawT;
      var armAng = -1.5 + prog * 2.6;
      var armLen = s * (0.85 + prog * 1.1);
      ctx.save();
      ctx.translate(s * 0.35, -s * 0.2);
      ctx.rotate(armAng);
      // arm hose
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(armLen, 0);
      ctx.strokeStyle = ORANGE;
      ctx.lineWidth = s * 0.22;
      ctx.lineCap = "round";
      ctx.stroke();
      ctx.strokeStyle = INK;
      ctx.lineWidth = s * 0.04;
      ctx.stroke();
      // white glove
      ctx.translate(armLen, 0);
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.2, 0, Math.PI * 2);
      ctx.fillStyle = CREAM;
      ctx.fill();
      ctx.strokeStyle = INK;
      ctx.lineWidth = 2.5;
      ctx.stroke();
      // claws out of glove
      ctx.fillStyle = "#e7e5e4";
      for (var c = -1; c <= 1; c++) {
        ctx.beginPath();
        ctx.moveTo(s * 0.05, c * s * 0.12);
        ctx.lineTo(s * 0.42, c * s * 0.2);
        ctx.lineTo(s * 0.1, c * s * 0.05);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = INK;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.restore();
    }

    ctx.restore();
  }

  function drawScratches(ctx, w, h, clawT, catX, catY, facing) {
    if (clawT < 0.28 || clawT > 0.98) return;
    var a = Math.min(1, (clawT - 0.28) / 0.35);
    var fade = clawT > 0.72 ? 1 - (clawT - 0.72) / 0.26 : 1;
    ctx.save();
    ctx.lineCap = "round";
    var bx = catX + facing * w * 0.1;
    var by = catY - h * 0.1;
    for (var i = 0; i < 5; i++) {
      var yy = by + i * h * 0.045;
      var len = w * (0.3 + i * 0.05) * a;
      ctx.strokeStyle = "rgba(251, 146, 60," + (0.9 * a * fade) + ")";
      ctx.lineWidth = 5 + i * 1.2;
      ctx.beginPath();
      ctx.moveTo(bx, yy);
      ctx.lineTo(bx + facing * len, yy + i * 5);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,255,255," + (0.55 * a * fade) + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(bx, yy);
      ctx.lineTo(bx + facing * len * 0.95, yy + i * 5);
      ctx.stroke();
    }
    ctx.restore();
  }

  window.PulseVizThemes.cat = {
    id: "cat",
    name: "Cat",
    update: function (state) { state.splash *= 0.9; },
    onTrackChange: function () {
      cat.mood = "claw";
      cat.moodT = 0;
      cat.clawT = 0;
      cat.clawSide = cat.facing;
      cat.eyePop = 1;
      cat.grin = 1;
      cat.squash = 0.65;
      cat.stretch = 1.45;
      cat.hop = 0;
    },
    draw: function (ctx, w, h, state) {
      var dt = state.dt;
      var flowLevel = state.flowLevel;
      var flowBass = state.flowBass;
      var flowTreble = state.flowTreble;
      var energy = Math.min(1.5, state.beatEnergy);

      state.flowT += dt * (0.4 + flowLevel * 0.8);
      state.cloudPhase += dt * (0.5 + flowBass);

      var bg = ctx.createRadialGradient(w * 0.5, h * 0.3, 0, w * 0.5, h * 0.5, Math.max(w, h) * 0.8);
      bg.addColorStop(0, "rgba(76, 29, 149," + (0.3 + energy * 0.2) + ")");
      bg.addColorStop(0.5, "rgba(37, 99, 235," + (0.12 + energy * 0.08) + ")");
      bg.addColorStop(1, "rgba(3, 7, 18, 0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      // Stage floor
      var floorY = h * 0.88;
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(0, floorY);
      for (var i = 0; i <= 40; i++) {
        var nx = i / 40;
        ctx.lineTo(nx * w, floorY + Math.sin(nx * Math.PI * 2 - state.flowT * 0.5) * (6 + flowLevel * 12));
      }
      ctx.lineTo(w, h);
      ctx.closePath();
      var fl = ctx.createLinearGradient(0, floorY - 20, 0, h);
      fl.addColorStop(0, "rgba(167, 139, 250, 0.4)");
      fl.addColorStop(1, "rgba(30, 27, 75, 0.6)");
      ctx.fillStyle = fl;
      ctx.fill();

      cat.moodT += dt;
      cat.phase += dt * (2.2 + flowLevel * 3 + (cat.mood === "dance" ? 9 : 0));
      cat.squash += (1 - cat.squash) * 0.1;
      cat.stretch += (1 - cat.stretch) * 0.1;
      cat.eyePop += (0 - cat.eyePop) * 0.05;
      cat.grin += ((cat.mood === "dance" || cat.mood === "claw" ? 0.85 : 0) - cat.grin) * 0.12;
      cat.hop *= 0.85;

      if (cat.blink > 0) cat.blink -= dt * 5;
      else if (Math.random() < dt * 0.22) cat.blink = 1;

      if (cat.mood === "claw") {
        cat.clawT += dt * 1.5;
        if (cat.clawT > 0.4 && cat.clawT < 0.55) {
          cat.squash = 0.6;
          cat.stretch = 1.5;
          cat.hop = -Math.min(w, h) * 0.02;
        }
        if (cat.clawT >= 1) {
          cat.clawT = 0;
          cat.mood = energy > 0.2 ? "dance" : "walk";
          cat.moodT = 0;
        }
      } else {
        cat.clawT = 0;
        if (cat.mood === "walk" && energy > 0.28 && cat.moodT > 1) {
          cat.mood = "dance"; cat.moodT = 0;
          cat.squash = 1.25; cat.stretch = 0.8;
        } else if (cat.mood === "dance" && energy < 0.12 && cat.moodT > 2.2) {
          cat.mood = "walk"; cat.moodT = 0;
        } else if (cat.mood === "walk" && cat.moodT > 5) {
          if (Math.random() < 0.2) { cat.mood = "sit"; cat.moodT = 0; }
          else cat.moodT = 0;
        } else if (cat.mood === "sit" && cat.moodT > 2.2) {
          cat.mood = energy > 0.2 ? "dance" : "walk";
          cat.moodT = 0;
        }
      }

      cat.dance += ((cat.mood === "dance" ? 1 : 0) - cat.dance) * 0.12;

      if (cat.mood === "walk") {
        var speed = 0.065 + flowLevel * 0.09;
        cat.x += cat.facing * speed * dt;
        if (cat.x > 0.78) { cat.x = 0.78; cat.facing = -1; }
        if (cat.x < 0.22) { cat.x = 0.22; cat.facing = 1; }
        cat.y = 0.64 + Math.sin(state.flowT * 0.3) * 0.025;
        cat.squash = 1 + Math.sin(cat.phase * 2) * 0.08;
        cat.stretch = 1 - Math.sin(cat.phase * 2) * 0.06;
      } else if (cat.mood === "dance") {
        cat.x += Math.sin(state.flowT * 4.5) * dt * 0.1;
        cat.y = 0.6 + Math.abs(Math.sin(state.flowT * 9)) * 0.1;
        cat.x = Math.max(0.22, Math.min(0.78, cat.x));
        cat.squash = 0.8 + Math.abs(Math.sin(state.flowT * 9)) * 0.35;
        cat.stretch = 1.2 - Math.abs(Math.sin(state.flowT * 9)) * 0.25;
        cat.eyePop = 0.35 + energy * 0.4;
      } else if (cat.mood === "sit") {
        cat.y = 0.7;
        cat.squash = 0.88;
        cat.stretch = 1.18;
      } else if (cat.mood === "claw") {
        cat.facing = cat.clawSide;
      }

      // Screen-filling size
      var catSize = Math.min(w, h) * 0.48 * (1 + flowBass * 0.05);
      var catPx = cat.x * w;
      var catPy = cat.y * h;

      if (cat.mood === "claw") drawScratches(ctx, w, h, cat.clawT, catPx, catPy, cat.facing);
      drawLTCat(ctx, catPx, catPy, catSize, state, energy);

      // Impact text
      if (cat.mood === "claw" && cat.clawT > 0.4 && cat.clawT < 0.75) {
        var words = ["POW!", "ZING!", "SCRATCH!", "RAWR!"];
        ctx.save();
        ctx.font = "bold " + Math.floor(Math.min(w, h) * 0.08) + "px Impact, Haettenschweiler, sans-serif";
        ctx.textAlign = "center";
        ctx.lineWidth = 4;
        ctx.strokeStyle = "#1c1917";
        ctx.fillStyle = "#fbbf24";
        var word = words[Math.floor(cat.clawT * 10) % words.length];
        var wx = catPx + cat.facing * catSize * 0.9;
        var wy = catPy - catSize * 0.5;
        ctx.strokeText(word, wx, wy);
        ctx.fillText(word, wx, wy);
        ctx.restore();
      }

      if (cat.dance > 0.4) {
        for (var n = 0; n < 5; n++) {
          var na = state.flowT * 2.2 + n * 1.2;
          ctx.font = "bold " + (22 + n * 4) + "px serif";
          ctx.fillStyle = "rgba(253, 186, 116," + (0.6 * cat.dance) + ")";
          ctx.fillText(n % 2 ? "♫" : "♪",
            catPx + Math.cos(na) * catSize * 1.15,
            catPy - catSize * 0.95 - Math.sin(state.flowT * 3 + n) * catSize * 0.3);
        }
      }
    }
  };
})();

// --- VINYL / RECORD PLAYER THEME ---
(function () {
  var spin = 0;
  var armAngle = 0.12;   // on-record resting pose
  var armVel = 0;
  var seekDir = 0;       // -1 back, 0 none, 1 forward
  var seekBoost = 0;     // decays after scrub
  var lastNowCurrent = null;
  var lastLoadKey = "";
  var lastLoadAt = 0;
  var isPlayingLed = false;
  var hitPrev = null;
  var hitPlay = null;
  var hitNext = null;

  var __lastSendCmd = "";
  var __lastSendAt = 0;
  function sendTransport(cmd) {
    var now = Date.now();
    if (cmd === __lastSendCmd && (now - __lastSendAt) < 500) return;
    __lastSendCmd = cmd;
    __lastSendAt = now;
    window.dispatchEvent(new CustomEvent("sonicly:visualizer-transport", { detail: { cmd: cmd } }));
  }
  var volume = 80;
  try {
    var sv = localStorage.getItem("pulse-vol");
    if (sv != null) volume = Math.max(0, Math.min(100, Number(sv) || 80));
  } catch (e) {}
  var artMode = "full"; // full | center
  try {
    var am = localStorage.getItem("pulse-vinyl-art");
    if (am === "center" || am === "full") artMode = am;
  } catch (e) {}

  var volFlash = 0;
  var hitVolMinus = null;
  var hitVolPlus = null;
  var hitVolPanel = null;

  function setVolume(v, silent) {
    volume = Math.max(0, Math.min(100, Math.round(v)));
    volFlash = 1;
    try { localStorage.setItem("pulse-vol", String(volume)); } catch (e) {}
    if (!silent) {
      window.dispatchEvent(new CustomEvent("sonicly:visualizer-volume", { detail: { value: volume / 100 } }));
    }
  }
  // Phases: 0 idle | 1 lift needle | 2 record lifts off | 3 empty platter pause
  //         4 new record flies in | 5 settles | 6 needle drops
  var phase = 0;
  var t = 1;
  var discScale = 1;
  var discAlpha = 1;
  var discY = 0;
  var discX = 0;
  var discRotExtra = 0;
  var spinMul = 1;
  var loadRing = 0;

  var ORBITERS = [
    { dist: 0.55, size: 0.028, speed: 1.4, seed: 0.3 },
    { dist: 0.72, size: 0.038, speed: 0.85, seed: 1.1 },
    { dist: 0.88, size: 0.022, speed: 0.55, seed: 2.0 },
    { dist: 1.02, size: 0.032, speed: 0.35, seed: 2.8 }
  ];
  var angles = ORBITERS.map(function (_, i) { return (i / ORBITERS.length) * Math.PI * 2; });

  function softBlob(ctx, cx, cy, R, phaseP, energy, seed) {
    var steps = 40;
    ctx.beginPath();
    for (var i = 0; i <= steps; i++) {
      var a = (i / steps) * Math.PI * 2;
      var puff =
        0.75 +
        0.14 * Math.sin(a * 2.5 + phaseP + seed) +
        0.1 * Math.sin(a * 4.1 - phaseP * 1.2 + seed) +
        0.06 * Math.sin(a * 6 + phaseP) * (0.5 + energy);
      var r = R * puff;
      var x = cx + Math.cos(a) * r;
      var y = cy + Math.sin(a) * r * 0.92;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }

  function ease(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  // Arm angles (canvas rotate): pivot is top-right of disc.
  // ON = needle over the grooves; UP = parked to the right of the platter.
  var ARM_ON = 2.52;
  var ARM_UP = 0.22;

  window.PulseVizThemes.vinyl = {
    id: "vinyl",
    name: "Vinyl",
    update: function (state) { state.splash *= 0.9; },
    onTrackChange: function (key) {
      var nowMs = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
      // Ignore spam / same track / mid-sequence re-triggers
      if (phase > 0 && phase < 6) return;
      if (key && key === lastLoadKey && (nowMs - lastLoadAt) < 4000) return;
      if ((nowMs - lastLoadAt) < 2500) return;
      lastLoadKey = key || "";
      lastLoadAt = nowMs;
      phase = 1;
      t = 0;
      armVel = 0;
      seekDir = 0;
      seekBoost = 0;
    },
    onSeek: function (dir, seeking) {
      // dir: -1 rewind/scrub back, 1 forward, 0 release
      if (dir < 0) {
        seekDir = -1;
        seekBoost = Math.max(seekBoost, 4.5);
      } else if (dir > 0) {
        seekDir = 1;
        seekBoost = Math.max(seekBoost, 3.2);
      }
      if (!seeking) {
        // keep spinning reverse briefly after release if we were going back
        if (seekDir < 0) seekBoost = Math.max(seekBoost, 2.5);
      }
    },
    onPosition: function (current) {
      if (lastNowCurrent != null && typeof current === "number") {
        var delta = current - lastNowCurrent;
        // Only treat large jumps as seeks (ignore normal 0.5s poll ticks)
        if (delta < -1.2) {
          seekDir = -1;
          seekBoost = Math.max(seekBoost, Math.min(8, 2 + Math.abs(delta) * 0.6));
        } else if (delta > 2.5) {
          seekDir = 1;
          seekBoost = Math.max(seekBoost, Math.min(6, 1.2 + delta * 0.3));
        }
      }
      lastNowCurrent = current;
    },
    setVolume: function (v) { setVolume(v); },
    getVolume: function () { return volume; },
    setArtMode: function (m) {
      artMode = (m === "center") ? "center" : "full";
      try { localStorage.setItem("pulse-vinyl-art", artMode); } catch (e) {}
    },
    getArtMode: function () { return artMode; },
    hitTest: function (x, y) {
      function inside(r, pad) {
        pad = pad || 6;
        return r && x >= r.x - pad && x <= r.x + r.w + pad && y >= r.y - pad && y <= r.y + r.h + pad;
      }
      if (inside(hitVolMinus)) { setVolume(volume - 5); return "vol-"; }
      if (inside(hitVolPlus)) { setVolume(volume + 5); return "vol+"; }
      if (inside(hitPrev)) { sendTransport("prev"); return "prev"; }
      if (inside(hitPlay)) { sendTransport("toggle"); return "play"; }
      if (inside(hitNext)) { sendTransport("next"); return "next"; }
      return null;
    },
    setPlaying: function (p) { isPlayingLed = !!p; },
    draw: function (ctx, w, h, state) {
      var dt = state.dt;
      var flowLevel = state.flowLevel;
      var flowBass = state.flowBass;
      var energy = Math.min(1.5, state.beatEnergy);
      var crazy = state.crazy;
      var busy = phase > 0;
      // Keep in sync with main player volume (shared localStorage)
      try {
        var sv = localStorage.getItem("pulse-vol");
        if (sv != null) {
          var nv = Math.max(0, Math.min(100, Number(sv)));
          if (!isNaN(nv) && nv !== volume) volume = nv;
        }
      } catch (e) {}

      state.flowT += dt * (0.35 + flowLevel * 0.7);
      state.cloudPhase += dt * (0.5 + flowBass);
      var pulse = 0.5 + 0.5 * Math.sin(state.flowT * 2);
      state.logoPulse += ((0.94 + pulse * 0.08 + flowBass * 0.15) - state.logoPulse) * 0.12;

      // ---- SEQUENCE ----
      if (phase === 1) {
        // Needle lifts OFF the record (forced, not overridden by energy)
        t = Math.min(1, t + dt * 2.0);
        armAngle = ARM_ON + (ARM_UP - ARM_ON) * ease(t);
        discScale = 1; discAlpha = 1; discY = 0; discX = 0;
        spinMul = 1;
        loadRing = 0;
        if (t >= 1) { phase = 2; t = 0; }
      } else if (phase === 2) {
        // Record lifts itself up and drifts away (no person — just the disc)
        t = Math.min(1, t + dt * 1.5);
        var e = ease(t);
        armAngle = ARM_UP;
        discY = -e * 90;
        discX = e * 30;
        discScale = 1 - e * 0.25;
        discAlpha = 1 - e * 0.85;
        discRotExtra = e * 0.8;
        spinMul = 0.25;
        loadRing = e * 0.4;
        if (t >= 1) { phase = 3; t = 0; discAlpha = 0; }
      } else if (phase === 3) {
        // Empty platter + wait for the new sleeve
        t = Math.min(1, t + dt * 1.4);
        armAngle = ARM_UP;
        discAlpha = 0;
        discScale = 0.5;
        discY = -120;
        discX = -40;
        loadRing = 0.5 + 0.5 * Math.sin(t * Math.PI);
        spinMul = 0.35;
        if (t >= 1) {
          if (state.coverReady && state.coverImg && state.coverImg.naturalWidth) {
            phase = 4; t = 0; discAlpha = 0; discY = -140; discX = -60; discScale = 0.55;
          } else {
            t = 0.7;
          }
        }
      } else if (phase === 4) {
        // New record floats in from upper-left and places itself
        t = Math.min(1, t + dt * 1.35);
        var e = ease(t);
        armAngle = ARM_UP;
        discAlpha = e;
        discX = -60 * (1 - e);
        discY = -140 * (1 - e);
        discScale = 0.55 + e * 0.45;
        discRotExtra = (1 - e) * 1.2;
        loadRing = 1 - e * 0.7;
        spinMul = 0.5 + e * 0.5;
        if (t >= 1) { phase = 5; t = 0; discX = 0; discY = 0; discScale = 1; discAlpha = 1; }
      } else if (phase === 5) {
        // Brief settle bounce
        t = Math.min(1, t + dt * 3.0);
        armAngle = ARM_UP;
        discY = Math.sin(t * Math.PI) * -8 * (1 - t);
        discScale = 1 + Math.sin(t * Math.PI) * 0.03;
        discAlpha = 1;
        loadRing = 0;
        spinMul = 1;
        if (t >= 1) { phase = 6; t = 0; discY = 0; discScale = 1; }
      } else if (phase === 6) {
        // Needle drops back onto the record
        t = Math.min(1, t + dt * 1.7);
        armAngle = ARM_UP + (ARM_ON - ARM_UP) * ease(t);
        discScale = 1; discAlpha = 1; discY = 0; discX = 0;
        loadRing = 0;
        spinMul = 1;
        if (t >= 1) { phase = 0; t = 1; armAngle = ARM_ON; }
      } else {
        // Idle
        var want = (energy > 0.08 || state.m > 0.05) ? ARM_ON + flowBass * 0.03 : ARM_UP;
        armAngle += (want - armAngle) * 0.05;
        discScale = 1; discAlpha = 1; discY = 0; discX = 0; discRotExtra = 0;
        loadRing = 0; spinMul = 1;
      }

      // Continuous platter spin (music-reactive) + seek override
      seekBoost *= 0.90;
      if (seekBoost < 0.08) { seekBoost = 0; seekDir = 0; }
      // Always keep a steady base rotation so the disc never looks stuck
      var rpm = (0.55 + flowLevel * 2.0 + flowBass * 1.4 + crazy * 1.0) * Math.max(0.25, spinMul);
      if (phase === 0) rpm = Math.max(rpm, 0.5); // never stall when idle
      if (seekDir < 0 && seekBoost > 0) {
        rpm = -(2.5 + seekBoost * 1.8);
      } else if (seekDir > 0 && seekBoost > 0) {
        rpm = rpm + seekBoost * 2.2;
      }
      spin += dt * rpm;

      var cx = w * 0.42;
      var cy = h * 0.48;
      var scale = Math.min(w, h);

      var bg = ctx.createRadialGradient(cx, cy, 0, cx, cy, scale * 0.7);
      bg.addColorStop(0, "rgba(76, 29, 149," + (0.32 + energy * 0.2) + ")");
      bg.addColorStop(0.5, "rgba(37, 99, 235," + (0.12 + energy * 0.08) + ")");
      bg.addColorStop(1, "rgba(3, 7, 18, 0)");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, w, h);

      var maxR = scale * 0.38;
      for (var i = 0; i < ORBITERS.length; i++) {
        var o = ORBITERS[i];
        var or = maxR * o.dist * (1 + flowLevel * 0.04);
        ctx.beginPath();
        ctx.ellipse(cx, cy, or, or * 0.62, 0.08, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(147, 197, 253," + (0.1 + energy * 0.08) + ")";
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
      var speedMul = 0.4 + flowLevel * 1.6 + flowBass * 1.1 + crazy * 0.8;
      for (var i = 0; i < ORBITERS.length; i++) {
        var o = ORBITERS[i];
        angles[i] += dt * o.speed * speedMul * 0.55;
        var or = maxR * o.dist * (1 + flowLevel * 0.04);
        var ell = 0.62;
        var ox = cx + Math.cos(angles[i]) * or;
        var oy = cy + Math.sin(angles[i]) * or * ell;
        var pr = maxR * o.size * (1 + flowLevel * 0.15 + flowBass * 0.1) * state.logoPulse;
        var glow = ctx.createRadialGradient(ox, oy, 0, ox, oy, pr * 2.5);
        glow.addColorStop(0, "rgba(167, 139, 250," + (0.35 + energy * 0.25) + ")");
        glow.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(ox, oy, pr * 2.5, 0, Math.PI * 2);
        ctx.fill();
        softBlob(ctx, ox, oy, pr, state.cloudPhase + o.seed, energy, o.seed);
        var fill = ctx.createLinearGradient(ox - pr, oy - pr, ox + pr, oy + pr);
        fill.addColorStop(0, "rgba(196, 181, 253, 0.95)");
        fill.addColorStop(0.5, "rgba(129, 140, 248, 0.9)");
        fill.addColorStop(1, "rgba(99, 102, 241, 0.85)");
        ctx.fillStyle = fill;
        ctx.fill();
      }

      // Plinth
      var plinthW = scale * 0.55;
      var plinthH = scale * 0.42;
      var px = cx - plinthW * 0.42;
      var py = cy - plinthH * 0.35;
      ctx.beginPath();
      var rr = 18;
      ctx.moveTo(px + rr, py);
      ctx.lineTo(px + plinthW - rr, py);
      ctx.quadraticCurveTo(px + plinthW, py, px + plinthW, py + rr);
      ctx.lineTo(px + plinthW, py + plinthH - rr);
      ctx.quadraticCurveTo(px + plinthW, py + plinthH, px + plinthW - rr, py + plinthH);
      ctx.lineTo(px + rr, py + plinthH);
      ctx.quadraticCurveTo(px, py + plinthH, px, py + plinthH - rr);
      ctx.lineTo(px, py + rr);
      ctx.quadraticCurveTo(px, py, px + rr, py);
      ctx.closePath();
      var plinthGrad = ctx.createLinearGradient(px, py, px, py + plinthH);
      plinthGrad.addColorStop(0, "rgba(49, 46, 129, 0.85)");
      plinthGrad.addColorStop(0.5, "rgba(30, 27, 75, 0.92)");
      plinthGrad.addColorStop(1, "rgba(15, 23, 42, 0.95)");
      ctx.fillStyle = plinthGrad;
      ctx.fill();
      ctx.strokeStyle = "rgba(167, 139, 250, 0.35)";
      ctx.lineWidth = 2;
      ctx.stroke();

      var discR = scale * 0.16 * state.logoPulse;

      // Empty platter (always visible under the disc)
      ctx.beginPath();
      ctx.arc(cx, cy, discR * 1.12, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(30, 27, 75, 0.95)";
      ctx.fill();
      ctx.strokeStyle = "rgba(129, 140, 248, 0.4)";
      ctx.lineWidth = 3;
      ctx.stroke();
      // Platter mat rings when disc is gone
      if (discAlpha < 0.4) {
        ctx.strokeStyle = "rgba(99, 102, 241," + ((0.4 - discAlpha) * 0.5) + ")";
        ctx.lineWidth = 1.5;
        for (var m = 0.3; m < 1; m += 0.18) {
          ctx.beginPath();
          ctx.arc(cx, cy, discR * m, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // Loading ring while empty / swapping
      if (loadRing > 0.05) {
        var lr = discR * (1.3 + 0.1 * Math.sin(state.flowT * 4));
        ctx.beginPath();
        ctx.arc(cx, cy, lr, state.flowT * 5, state.flowT * 5 + Math.PI * 1.5 * Math.min(1, loadRing));
        ctx.strokeStyle = "rgba(196, 181, 253," + (0.4 + loadRing * 0.5) + ")";
        ctx.lineWidth = 4;
        ctx.lineCap = "round";
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cx, cy, lr * 0.86, -state.flowT * 4.2, -state.flowT * 4.2 + Math.PI * loadRing);
        ctx.strokeStyle = "rgba(129, 140, 248," + (0.3 + loadRing * 0.4) + ")";
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.font = "600 " + Math.floor(scale * 0.026) + "px Segoe UI, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = "rgba(224, 231, 255," + (0.55 + loadRing * 0.45) + ")";
        var dots = Math.floor((state.flowT * 3) % 4);
        ctx.fillText("Loading" + ["", ".", "..", "..."][dots], cx, cy + discR * 1.55);
      }

      // Floating disc (places itself — no hand)
      if (discAlpha > 0.02) {
        ctx.save();
        ctx.globalAlpha = Math.max(0, Math.min(1, discAlpha));
        ctx.translate(cx + discX, cy + discY);
        ctx.scale(discScale, discScale);
        ctx.rotate(spin + discRotExtra);

        // Soft shadow under floating disc
        if (Math.abs(discY) > 5 || Math.abs(discX) > 5) {
          ctx.beginPath();
          ctx.ellipse(8, discR * 0.15 + Math.abs(discY) * 0.05, discR * 0.9, discR * 0.18, 0, 0, Math.PI * 2);
          ctx.fillStyle = "rgba(0,0,0," + (0.25 * discAlpha) + ")";
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(0, 0, discR, 0, Math.PI * 2);
        ctx.closePath();
        ctx.save();
        ctx.clip();

        // Vinyl base grooves always
        var vinylGrad = ctx.createRadialGradient(0, 0, discR * 0.12, 0, 0, discR);
        vinylGrad.addColorStop(0, "#312e81");
        vinylGrad.addColorStop(0.25, "#1e1b4b");
        vinylGrad.addColorStop(0.55, "#312e81");
        vinylGrad.addColorStop(0.8, "#1e1b4b");
        vinylGrad.addColorStop(1, "#0f172a");
        ctx.fillStyle = vinylGrad;
        ctx.fillRect(-discR, -discR, discR * 2, discR * 2);

        var mode = artMode || "full";
        var artImg = state.coverImg;
        var artOk = !!(state.coverReady && state.coverImg && state.coverImg.naturalWidth > 0);
        if (phase === 1 || phase === 2) {
          if (state.coverOutReady && state.coverOut && state.coverOut.naturalWidth > 0) {
            artImg = state.coverOut;
            artOk = true;
          }
        } else if (phase === 3) {
          artOk = false;
        }
        if (artOk && artImg && artImg.naturalWidth > 0) {
          var iw = artImg.naturalWidth;
          var ih = artImg.naturalHeight;
          if (mode === "center") {
            // Centered label only (classic vinyl sticker)
            var labelR = discR * 0.38;
            ctx.save();
            ctx.beginPath();
            ctx.arc(0, 0, labelR, 0, Math.PI * 2);
            ctx.closePath();
            ctx.clip();
            var destC = labelR * 2 * 1.06;
            var scC = Math.max(destC / iw, destC / ih);
            var dwC = iw * scC, dhC = ih * scC;
            ctx.drawImage(artImg, -dwC / 2, -dhC / 2, dwC, dhC);
            ctx.fillStyle = "rgba(79, 70, 229, 0.12)";
            ctx.fillRect(-labelR, -labelR, labelR * 2, labelR * 2);
            ctx.restore();
            // Label ring
            ctx.beginPath();
            ctx.arc(0, 0, labelR, 0, Math.PI * 2);
            ctx.strokeStyle = "rgba(196, 181, 253, 0.5)";
            ctx.lineWidth = 2;
            ctx.stroke();
            // Groove rings outside the label
            ctx.strokeStyle = "rgba(99, 102, 241, 0.22)";
            ctx.lineWidth = 1;
            for (var g = 0.42; g < 0.96; g += 0.06) {
              ctx.beginPath();
              ctx.arc(0, 0, discR * g, 0, Math.PI * 2);
              ctx.stroke();
            }
          } else {
            // Full disc art (current default)
            var dest = discR * 2 * 1.08;
            var sc = Math.max(dest / iw, dest / ih);
            var dw = iw * sc, dh = ih * sc;
            ctx.drawImage(artImg, -dw / 2, -dh / 2, dw, dh);
            var vig = ctx.createRadialGradient(0, 0, discR * 0.75, 0, 0, discR);
            vig.addColorStop(0, "rgba(15, 23, 42, 0)");
            vig.addColorStop(1, "rgba(49, 46, 129, 0.22)");
            ctx.fillStyle = vig;
            ctx.fillRect(-discR, -discR, discR * 2, discR * 2);
            ctx.strokeStyle = "rgba(15, 23, 42, 0.08)";
            ctx.lineWidth = 1;
            for (var g2 = 0.35; g2 < 0.96; g2 += 0.12) {
              ctx.beginPath();
              ctx.arc(0, 0, discR * g2, 0, Math.PI * 2);
              ctx.stroke();
            }
          }
        } else {
          ctx.fillStyle = "rgba(255,255,255,0.9)";
          ctx.font = "bold " + Math.floor(discR * 0.32) + "px Segoe UI, sans-serif";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText("♪", 0, 2);
          ctx.strokeStyle = "rgba(99, 102, 241, 0.2)";
          ctx.lineWidth = 1;
          for (var g3 = 0.35; g3 < 0.96; g3 += 0.1) {
            ctx.beginPath();
            ctx.arc(0, 0, discR * g3, 0, Math.PI * 2);
            ctx.stroke();
          }
        }
        ctx.restore();

        ctx.beginPath();
        ctx.arc(0, 0, discR, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(196, 181, 253, 0.5)";
        ctx.lineWidth = 2.5;
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(0, 0, discR * 0.045, 0, Math.PI * 2);
        ctx.fillStyle = "#0f172a";
        ctx.fill();
        ctx.restore();
      }

      // Tonearm — pivot top-right; when ON, needle hovers over the disc
      var pivotX = cx + discR * 1.28;
      var pivotY = cy - discR * 0.72;
      // Length reaches ~55% of radius from center (groove area)
      var armLen = discR * 1.42;
      ctx.save();
      ctx.translate(pivotX, pivotY);
      ctx.rotate(armAngle);

      // Pivot
      ctx.beginPath();
      ctx.arc(0, 0, scale * 0.02, 0, Math.PI * 2);
      ctx.fillStyle = "#c4b5fd";
      ctx.fill();
      ctx.strokeStyle = "#e0e7ff";
      ctx.lineWidth = 2;
      ctx.stroke();
      // Arm shadow
      ctx.beginPath();
      ctx.moveTo(2, 3);
      ctx.lineTo(armLen + 2, 3);
      ctx.strokeStyle = "rgba(0,0,0,0.25)";
      ctx.lineWidth = 5;
      ctx.lineCap = "round";
      ctx.stroke();
      // Arm body
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(armLen, 0);
      ctx.strokeStyle = "#e0e7ff";
      ctx.lineWidth = 5;
      ctx.stroke();
      ctx.strokeStyle = "#a78bfa";
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // Headshell + needle
      ctx.translate(armLen, 0);
      ctx.beginPath();
      ctx.moveTo(0, -7);
      ctx.lineTo(16, -5);
      ctx.lineTo(16, 5);
      ctx.lineTo(0, 7);
      ctx.closePath();
      ctx.fillStyle = "#818cf8";
      ctx.fill();
      ctx.strokeStyle = "#e0e7ff";
      ctx.lineWidth = 1;
      ctx.stroke();
      // Needle tip
      ctx.beginPath();
      ctx.moveTo(16, 0);
      ctx.lineTo(26, 6);
      ctx.strokeStyle = "#f8fafc";
      ctx.lineWidth = 2.5;
      ctx.lineCap = "round";
      ctx.stroke();
      // Glow on needle when moving
      if (busy) {
        ctx.beginPath();
        ctx.arc(26, 6, 5, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(196, 181, 253, 0.35)";
        ctx.fill();
      }
      ctx.restore();

      if (!busy && energy > 0.45) {
        var burst = (state.flowT * 1.7) % 1.3;
        if (burst < 1) {
          ctx.beginPath();
          ctx.arc(cx, cy, discR * (1.2 + burst * 3) * (0.9 + energy * 0.3), 0, Math.PI * 2);
          ctx.strokeStyle = "rgba(167, 139, 250," + ((1 - burst) * 0.4 * energy) + ")";
          ctx.lineWidth = 2 + energy * 2;
          ctx.stroke();
        }
      }

      // ===== DIGITAL VOLUME PANEL (bottom-right of plinth, compact) =====
      volFlash *= 0.92;
      var panelW = Math.max(88, plinthW * 0.26);
      var panelH = Math.max(26, plinthH * 0.10);
      var panelX = px + plinthW - panelW - plinthW * 0.05;
      // Sit on the bottom edge of the plinth (slightly overlapping the lower rim)
      var panelY = py + plinthH - panelH * 0.55;
      var btnW = panelH * 0.9;

      // Panel bezel
      ctx.beginPath();
      var prr = 8;
      ctx.moveTo(panelX + prr, panelY);
      ctx.lineTo(panelX + panelW - prr, panelY);
      ctx.quadraticCurveTo(panelX + panelW, panelY, panelX + panelW, panelY + prr);
      ctx.lineTo(panelX + panelW, panelY + panelH - prr);
      ctx.quadraticCurveTo(panelX + panelW, panelY + panelH, panelX + panelW - prr, panelY + panelH);
      ctx.lineTo(panelX + prr, panelY + panelH);
      ctx.quadraticCurveTo(panelX, panelY + panelH, panelX, panelY + panelH - prr);
      ctx.lineTo(panelX, panelY + prr);
      ctx.quadraticCurveTo(panelX, panelY, panelX + prr, panelY);
      ctx.closePath();
      var pGrad = ctx.createLinearGradient(panelX, panelY, panelX, panelY + panelH);
      pGrad.addColorStop(0, "rgba(30, 27, 75, 0.95)");
      pGrad.addColorStop(1, "rgba(15, 23, 42, 0.98)");
      ctx.fillStyle = pGrad;
      ctx.fill();
      ctx.strokeStyle = "rgba(167, 139, 250, 0.45)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Left arrow button
      hitVolMinus = { x: panelX + 4, y: panelY + 4, w: btnW, h: panelH - 8 };
      ctx.fillStyle = "rgba(79, 70, 229, 0.45)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hitVolMinus.x, hitVolMinus.y, hitVolMinus.w, hitVolMinus.h, 6); else ctx.rect(hitVolMinus.x, hitVolMinus.y, hitVolMinus.w, hitVolMinus.h);
      ctx.fill();
      ctx.fillStyle = "#e0e7ff";
      ctx.font = "bold " + Math.floor(panelH * 0.45) + "px Segoe UI, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("◀", hitVolMinus.x + hitVolMinus.w / 2, hitVolMinus.y + hitVolMinus.h / 2 + 1);

      // Right arrow button
      hitVolPlus = { x: panelX + panelW - btnW - 4, y: panelY + 4, w: btnW, h: panelH - 8 };
      ctx.fillStyle = "rgba(79, 70, 229, 0.45)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hitVolPlus.x, hitVolPlus.y, hitVolPlus.w, hitVolPlus.h, 6); else ctx.rect(hitVolPlus.x, hitVolPlus.y, hitVolPlus.w, hitVolPlus.h);
      ctx.fill();
      ctx.fillStyle = "#e0e7ff";
      ctx.fillText("▶", hitVolPlus.x + hitVolPlus.w / 2, hitVolPlus.y + hitVolPlus.h / 2 + 1);

      // Digital screen in the middle
      var screenX = hitVolMinus.x + hitVolMinus.w + 6;
      var screenW = hitVolPlus.x - screenX - 6;
      var screenY = panelY + 5;
      var screenH = panelH - 10;
      hitVolPanel = { x: screenX, y: screenY, w: screenW, h: screenH };
      ctx.fillStyle = "rgba(6, 16, 40, 0.95)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(screenX, screenY, screenW, screenH, 4); else ctx.rect(screenX, screenY, screenW, screenH);
      ctx.fill();
      // Screen glow edge
      ctx.strokeStyle = "rgba(56, 189, 248," + (0.35 + volFlash * 0.5) + ")";
      ctx.lineWidth = 1;
      ctx.stroke();
      // LCD text
      var glow = 0.75 + volFlash * 0.25;
      ctx.fillStyle = "rgba(125, 211, 252," + glow + ")";
      ctx.font = "600 " + Math.floor(screenH * 0.48) + "px ui-monospace, SFMono-Regular, Menlo, monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      var volStr = (volume < 10 ? "0" : "") + String(volume);
      ctx.fillText(volStr, screenX + screenW / 2, screenY + screenH / 2 + 0.5);
      // tiny bar meter under text
      var meterW = screenW * 0.75;
      var meterX = screenX + (screenW - meterW) / 2;
      var meterY = screenY + screenH * 0.82;
      ctx.fillStyle = "rgba(37, 99, 235, 0.35)";
      ctx.fillRect(meterX, meterY, meterW, 3);
      ctx.fillStyle = "rgba(96, 165, 250, 0.9)";
      ctx.fillRect(meterX, meterY, meterW * (volume / 100), 3);

      // ===== TRANSPORT PANEL (bottom-left — same size language as volume) =====
      var tpW = panelW; // exact same width as volume panel
      var tpH = panelH; // exact same height
      var tpX = px + plinthW * 0.05;
      var tpY = panelY;
      var tpBtn = btnW; // same arrow button size as volume

      // Bezel
      ctx.beginPath();
      var tr = 8;
      ctx.moveTo(tpX + tr, tpY);
      ctx.lineTo(tpX + tpW - tr, tpY);
      ctx.quadraticCurveTo(tpX + tpW, tpY, tpX + tpW, tpY + tr);
      ctx.lineTo(tpX + tpW, tpY + tpH - tr);
      ctx.quadraticCurveTo(tpX + tpW, tpY + tpH, tpX + tpW - tr, tpY + tpH);
      ctx.lineTo(tpX + tr, tpY + tpH);
      ctx.quadraticCurveTo(tpX, tpY + tpH, tpX, tpY + tpH - tr);
      ctx.lineTo(tpX, tpY + tr);
      ctx.quadraticCurveTo(tpX, tpY, tpX + tr, tpY);
      ctx.closePath();
      var tGrad = ctx.createLinearGradient(tpX, tpY, tpX, tpY + tpH);
      tGrad.addColorStop(0, "rgba(30, 27, 75, 0.95)");
      tGrad.addColorStop(1, "rgba(15, 23, 42, 0.98)");
      ctx.fillStyle = tGrad;
      ctx.fill();
      ctx.strokeStyle = "rgba(167, 139, 250, 0.45)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Prev button
      hitPrev = { x: tpX + 4, y: tpY + 4, w: tpBtn, h: tpH - 8 };
      ctx.fillStyle = "rgba(79, 70, 229, 0.45)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hitPrev.x, hitPrev.y, hitPrev.w, hitPrev.h, 6);
      else ctx.rect(hitPrev.x, hitPrev.y, hitPrev.w, hitPrev.h);
      ctx.fill();
      ctx.fillStyle = "#e0e7ff";
      ctx.font = "bold " + Math.floor(tpH * 0.42) + "px Segoe UI, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("⏮", hitPrev.x + hitPrev.w / 2, hitPrev.y + hitPrev.h / 2 + 1);

      // Next button
      hitNext = { x: tpX + tpW - tpBtn - 4, y: tpY + 4, w: tpBtn, h: tpH - 8 };
      ctx.fillStyle = "rgba(79, 70, 229, 0.45)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(hitNext.x, hitNext.y, hitNext.w, hitNext.h, 6);
      else ctx.rect(hitNext.x, hitNext.y, hitNext.w, hitNext.h);
      ctx.fill();
      ctx.fillStyle = "#e0e7ff";
      ctx.fillText("⏭", hitNext.x + hitNext.w / 2, hitNext.y + hitNext.h / 2 + 1);

      // LED play/pause display (center)
      var ledX = hitPrev.x + hitPrev.w + 5;
      var ledW = hitNext.x - ledX - 5;
      var ledY = tpY + 4;
      var ledH = tpH - 8;
      hitPlay = { x: ledX, y: ledY, w: ledW, h: ledH };
      // Dark LED glass
      ctx.fillStyle = "rgba(6, 16, 40, 0.96)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(ledX, ledY, ledW, ledH, 4);
      else ctx.rect(ledX, ledY, ledW, ledH);
      ctx.fill();
      // Glow border
      var ledOn = isPlayingLed;
      ctx.strokeStyle = ledOn ? "rgba(52, 211, 153, 0.55)" : "rgba(56, 189, 248, 0.4)";
      ctx.lineWidth = 1;
      ctx.stroke();
      // LED symbol
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      if (ledOn) {
        // Pause bars as LED
        ctx.fillStyle = "rgba(52, 211, 153, 0.95)";
        var bw = Math.max(3, ledW * 0.12);
        var bh = ledH * 0.48;
        var gap = bw * 0.7;
        ctx.fillRect(ledX + ledW / 2 - gap / 2 - bw, ledY + (ledH - bh) / 2, bw, bh);
        ctx.fillRect(ledX + ledW / 2 + gap / 2, ledY + (ledH - bh) / 2, bw, bh);
        // soft glow
        ctx.fillStyle = "rgba(52, 211, 153, 0.2)";
        ctx.fillRect(ledX + 2, ledY + 2, ledW - 4, ledH - 4);
      } else {
        // Play triangle LED
        ctx.fillStyle = "rgba(125, 211, 252, 0.95)";
        var cxL = ledX + ledW / 2 + 1;
        var cyL = ledY + ledH / 2;
        var s = ledH * 0.28;
        ctx.beginPath();
        ctx.moveTo(cxL - s * 0.7, cyL - s);
        ctx.lineTo(cxL - s * 0.7, cyL + s);
        ctx.lineTo(cxL + s, cyL);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "rgba(56, 189, 248, 0.15)";
        ctx.fillRect(ledX + 2, ledY + 2, ledW - 4, ledH - 4);
      }

      // Publish hit areas for click handler
      window.PulseVizThemes.vinyl._hits = {
        minus: hitVolMinus,
        plus: hitVolPlus,
        prev: hitPrev,
        play: hitPlay,
        next: hitNext
      };

      var floorY = h * 0.82;
      ctx.beginPath();
      ctx.ellipse(cx, floorY, discR * 1.3, discR * 0.18, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(99, 102, 241," + (0.12 + energy * 0.1) + ")";
      ctx.fill();
    }
  };
})();



