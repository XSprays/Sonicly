const { execFileSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

function envWithAppFlags(root) {
  const env = { ...process.env };
  try {
    const parsed = JSON.parse(fs.readFileSync(path.join(root, ".grok", "app-env.json"), "utf8"));
    for (const [key, value] of Object.entries(parsed)) {
      if (!key.startsWith("VITE_") || typeof value !== "string") continue;
      if (env[key] === undefined) env[key] = value;
    }
  } catch {
    // Missing app-env is fine. Vite still builds.
  }
  return env;
}

/**
 * electron-builder hook. Builds the player pages before packaging.
 * Calls the local vite.js so Windows does not need `vite` on PATH
 * (spawn "vite" fails with ENOENT outside an npm script).
 */
module.exports = async function beforePack() {
  const root = process.cwd();
  const node = process.execPath;
  const viteJs = path.join(root, "node_modules", "vite", "bin", "vite.js");
  if (!fs.existsSync(viteJs)) {
    throw new Error("vite is not installed. Run npm install in this folder first.");
  }
  execFileSync(node, [viteJs, "build", "--config", "vite.desktop.config.ts"], {
    cwd: root,
    stdio: "inherit",
    env: envWithAppFlags(root),
  });
  execFileSync(node, [path.join(root, "scripts", "copy-desktop-dist.mjs")], {
    cwd: root,
    stdio: "inherit",
  });
  const index = path.join(root, "desktop-dist", "index.html");
  if (!fs.existsSync(index)) {
    throw new Error("Desktop build did not produce desktop-dist/index.html");
  }
};
