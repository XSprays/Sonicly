import { cpSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const source = "dist/client";
const target = "desktop-dist";

rmSync(target, { recursive: true, force: true });
cpSync(source, target, { recursive: true });

const assets = readdirSync(join(target, "assets"));
const css = assets.find((name) => name.startsWith("styles-") && name.endsWith(".css"));
let html = readFileSync(join(target, "index.html"));
html = Buffer.from(html.filter((byte) => byte !== 0));
if (css) {
  const text = html.toString("utf8").replace(/\/assets\/styles-[^"]+\.css/g, `/assets/${css}`);
  writeFileSync(join(target, "index.html"), text);
} else {
  writeFileSync(join(target, "index.html"), html);
}
