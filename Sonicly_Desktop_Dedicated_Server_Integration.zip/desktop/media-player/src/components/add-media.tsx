import { FilePlus, FolderOpen } from "lucide-react";
import { useEffect, useRef } from "react";
import { Button } from "@/components/bits";
import { canPickDirectory, pickDirectory } from "@/player/files";
import { desktop } from "@/player/desktop";
import { usePlayer } from "@/player/store";

const ACCEPT =
  "audio/*,video/*,image/*,.mp3,.flac,.m4a,.aac,.wav,.ogg,.opus,.mp4,.mkv,.webm,.mov,.avi,.mpeg,.mpg,.jpg,.jpeg,.png,.webp,.gif";

function layoutClass(stacked: boolean, compact: boolean) {
  if (compact) return "size-11 px-0";
  if (stacked) return "w-full";
  return undefined;
}

export function AddMedia({ stacked = false, compact = false }: { stacked?: boolean; compact?: boolean }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const dirRef = useRef<HTMLInputElement>(null);
  const addLoose = usePlayer((state) => state.addLoose);
  const linkFolder = usePlayer((state) => state.linkFolder);
  const linkDesktop = usePlayer((state) => state.linkDesktop);

  useEffect(() => {
    if (dirRef.current) dirRef.current.webkitdirectory = true;
  }, []);

  async function chooseFolder() {
    const api = desktop();
    if (api) {
      const picked = await api.pickFolder();
      if (picked) await linkDesktop(picked);
      return;
    }
    if (canPickDirectory()) {
      try {
        const handle = await pickDirectory();
        await linkFolder(handle);
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
      }
    }
    dirRef.current?.click();
  }

  return (
    <div className={stacked ? "flex flex-col gap-2" : "flex flex-wrap gap-2"}>
      <Button onClick={() => void chooseFolder()} aria-label="Choose folder" className={layoutClass(stacked, compact)}>
        <FolderOpen className="size-4" aria-hidden="true" />
        {compact ? null : "Choose folder"}
      </Button>
      <Button variant="ghost" onClick={() => fileRef.current?.click()} aria-label="Add files" className={layoutClass(stacked, compact)}>
        <FilePlus className="size-4" aria-hidden="true" />
        {compact ? null : "Add files"}
      </Button>
      <input
        ref={fileRef}
        type="file"
        multiple
        accept={ACCEPT}
        className="hidden"
        onChange={(event) => {
          const files = [...(event.target.files ?? [])];
          event.target.value = "";
          if (files.length) void addLoose(files);
        }}
      />
      <input
        ref={dirRef}
        type="file"
        multiple
        className="hidden"
        onChange={(event) => {
          const files = [...(event.target.files ?? [])];
          event.target.value = "";
          if (files.length) void addLoose(files);
        }}
      />
    </div>
  );
}
