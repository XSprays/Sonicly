import type { ButtonHTMLAttributes, ReactNode } from "react";
import { urlFor } from "@/player/files";
import type { MediaItem } from "@/player/types";
import { cn } from "@/lib/utils";

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        variant === "primary" && "bg-accent text-bg hover:bg-accent/90",
        variant === "ghost" && "bg-raised text-fg hover:bg-line",
        variant === "danger" && "bg-transparent text-danger hover:bg-raised",
        className,
      )}
      {...props}
    />
  );
}

export function IconButton({
  className,
  active,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex size-11 items-center justify-center rounded-full text-fg transition-colors disabled:cursor-not-allowed disabled:opacity-40",
        active ? "bg-accent text-bg" : "hover:bg-raised",
        className,
      )}
      {...props}
    />
  );
}

export function EmptyState({
  icon,
  title,
  body,
  children,
}: {
  icon: ReactNode;
  title: string;
  body: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 px-6 py-16 text-center">
      <div className="flex size-16 items-center justify-center rounded-2xl bg-raised text-accent">{icon}</div>
      <div className="max-w-md">
        <h2 className="font-display text-2xl font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 text-base leading-relaxed text-muted">{body}</p>
      </div>
      {children ? <div className="flex flex-wrap items-center justify-center gap-2">{children}</div> : null}
    </div>
  );
}

export function SearchField({
  value,
  onChange,
  placeholder,
  label,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  label: string;
}) {
  return (
    <label className="block">
      <span className="sr-only">{label}</span>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg outline-none placeholder:text-muted focus-visible:border-accent"
      />
    </label>
  );
}

export function coverUrl(item: MediaItem, artUrls: Record<string, string>) {
  if (artUrls[item.id]) return artUrls[item.id];
  if (item.embeddedArtUrl) return item.embeddedArtUrl;
  if (item.artworkUrl) return item.artworkUrl;
  if (item.siblingArtId) return urlFor(item.siblingArtId);
  return null;
}

export function Artwork({
  src,
  className,
  icon,
}: {
  src: string | null;
  className?: string;
  icon: ReactNode;
}) {
  if (!src) {
    return (
      <div className={cn("flex items-center justify-center bg-raised text-muted", className)}>{icon}</div>
    );
  }
  return <img src={src} alt="" className={cn("object-cover", className)} />;
}
