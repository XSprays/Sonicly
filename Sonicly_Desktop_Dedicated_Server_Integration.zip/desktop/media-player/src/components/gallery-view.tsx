import { ChevronLeft, ChevronRight, Image as ImageIcon } from "lucide-react";
import { AddMedia } from "@/components/add-media";
import { EmptyState, IconButton, SearchField } from "@/components/bits";
import { urlFor } from "@/player/files";
import { selectActiveItems, usePlayer } from "@/player/store";
import { cn } from "@/lib/utils";

export function GalleryView() {
  const items = usePlayer(selectActiveItems);
  const librarySource = usePlayer((state) => state.settings.librarySource);
  const galleryQuery = usePlayer((state) => state.galleryQuery);
  const previewId = usePlayer((state) => state.previewId);
  const booted = usePlayer((state) => state.booted);
  const setGalleryQuery = usePlayer((state) => state.setGalleryQuery);
  const setPreview = usePlayer((state) => state.setPreview);
  const images = items.filter((item) => item.kind === "image");
  const query = galleryQuery.trim().toLowerCase();
  const visible = images.filter((item) => !query || item.name.toLowerCase().includes(query) || item.relPath.toLowerCase().includes(query));
  const selected = visible.find((item) => item.id === previewId) ?? visible[0] ?? null;
  const index = selected ? visible.findIndex((item) => item.id === selected.id) : -1;

  if (!booted) {
    return <EmptyState icon={<ImageIcon className="size-7" />} title="Opening library" body="Checking this browser for folders you linked earlier." />;
  }

  if (!images.length) {
    return (
      <EmptyState
        icon={<ImageIcon className="size-7" />}
        title="Your pictures"
        body={librarySource === "server" ? "No photos are available in the connected server library. Add pictures to the server’s photos folder, then refresh it from the Server page." : "Add a pictures folder or drop images here. A picture with the same name as a video or song is also used as its cover."}
      >
        {librarySource === "local" ? <AddMedia /> : null}
      </EmptyState>
    );
  }

  return (
    <div className="flex h-full flex-col gap-4 overflow-auto p-4">
      <div className="relative flex min-h-64 items-center justify-center overflow-hidden rounded-xl border border-line bg-bg">
        {selected ? (
          <img src={selected.streamUrl || urlFor(selected.id) || ""} alt={selected.name} className="max-h-[50vh] w-full object-contain" />
        ) : (
          <p className="text-muted">No pictures match.</p>
        )}
        {selected ? (
          <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-2 bg-bg/70 px-3 py-2">
            <p className="min-w-0 truncate text-sm">
              {selected.name}
              <span className="text-muted"> · {selected.folderLabel}</span>
            </p>
            <div className="flex shrink-0">
              <IconButton
                aria-label="Previous picture"
                disabled={index <= 0}
                onClick={() => visible[index - 1] && setPreview(visible[index - 1].id)}
              >
                <ChevronLeft className="size-5" />
              </IconButton>
              <IconButton
                aria-label="Next picture"
                disabled={index < 0 || index >= visible.length - 1}
                onClick={() => visible[index + 1] && setPreview(visible[index + 1].id)}
              >
                <ChevronRight className="size-5" />
              </IconButton>
            </div>
          </div>
        ) : null}
      </div>
      <SearchField value={galleryQuery} onChange={setGalleryQuery} placeholder="Search pictures" label="Search pictures" />
      <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        {visible.map((item) => {
          const active = item.id === selected?.id;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => setPreview(item.id)}
                className={cn("block w-full overflow-hidden rounded-lg border", active ? "border-accent" : "border-transparent")}
              >
                <img src={item.streamUrl || urlFor(item.id) || ""} alt="" className="aspect-square w-full object-cover" loading="lazy" />
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
