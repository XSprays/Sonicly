import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Captions, Maximize2, Minimize2, X } from "lucide-react";
import { getClock, subscribeClock } from "@/player/clock";

type LyricLine = { time: number; text: string };
type LyricsResult = {
  plainLyrics?: string | null;
  syncedLyrics?: string | null;
  instrumental?: boolean;
  trackName?: string;
  artistName?: string;
};

type LookupState = "loading" | "found" | "empty" | "error";
const lyricsCache = new Map<string, Promise<LyricsResult | null>>();
const clientHeaders = {
  Accept: "application/json",
  "Lrclib-Client": "Sonicly/1.0 (https://xspraysyt.com/)",
};

function normalize(value: string) {
  return value.toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

function parseLrc(value: string): LyricLine[] {
  const rows: LyricLine[] = [];
  const pattern = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
  for (const row of value.split(/\r?\n/)) {
    const stamps = [...row.matchAll(pattern)];
    if (!stamps.length) continue;
    const text = row.replace(pattern, "").trim();
    for (const stamp of stamps) {
      rows.push({
        time: Number(stamp[1]) * 60 + Number(stamp[2]) + (stamp[3] ? Number(`0.${stamp[3]}`) : 0),
        text,
      });
    }
  }
  return rows.sort((a, b) => a.time - b.time);
}

async function lookupLyrics(title: string, artist: string, album: string, duration: number) {
  const key = [title, artist, album, String(Math.round(duration))].map(normalize).join("|");
  const cached = lyricsCache.get(key);
  if (cached) return cached;

  const request = (async (): Promise<LyricsResult | null> => {
    if (artist.trim() && duration > 0 && duration < 3600) {
      const exact = new URLSearchParams({ track_name: title, artist_name: artist });
      if (album) exact.set("album_name", album);
      exact.set("duration", String(Math.round(duration)));
      const response = await fetch(`https://lrclib.net/api/get?${exact}`, { headers: clientHeaders });
      if (response.status === 429) {
        const retry = response.headers.get("Retry-After");
        throw new Error(retry ? `Lyrics service rate limit. Try again in ${retry} seconds.` : "Lyrics service rate limit. Try again shortly.");
      }
      if (response.ok) {
        const data = await response.json() as LyricsResult;
        if (data.syncedLyrics || data.plainLyrics || data.instrumental) return data;
      }
    }

    const search = new URLSearchParams({ q: `${title} ${artist}`.trim() });
    const response = await fetch(`https://lrclib.net/api/search?${search}`, { headers: clientHeaders });
    if (response.status === 429) {
      const retry = response.headers.get("Retry-After");
      throw new Error(retry ? `Lyrics service rate limit. Try again in ${retry} seconds.` : "Lyrics service rate limit. Try again shortly.");
    }
    if (!response.ok) return null;
    const results = await response.json() as LyricsResult[];
    const wantedTitle = normalize(title);
    const wantedArtist = normalize(artist);
    return results.find((candidate) => {
      const candidateTitle = normalize(candidate.trackName ?? "");
      const candidateArtist = normalize(candidate.artistName ?? "");
      const titleMatches = candidateTitle === wantedTitle;
      const artistMatches = !wantedArtist || candidateArtist === wantedArtist ||
        candidateArtist.includes(wantedArtist) || wantedArtist.includes(candidateArtist);
      return titleMatches && artistMatches;
    }) ?? null;
  })();

  lyricsCache.set(key, request);
  try {
    return await request;
  } catch (error) {
    lyricsCache.delete(key);
    throw error;
  }
}

export function IntegratedLyricsPanel({
  trackId,
  title,
  artist,
  album,
}: {
  trackId: string;
  title: string;
  artist: string;
  album: string;
}) {
  const clock = useSyncExternalStore(subscribeClock, getClock, getClock);
  const [result, setResult] = useState<LyricsResult | null>(null);
  const [status, setStatus] = useState("Finding lyrics…");
  const [lookupState, setLookupState] = useState<LookupState>("loading");
  const [expanded, setExpanded] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const activeLineRef = useRef<HTMLParagraphElement | null>(null);
  const lines = useMemo(() => result?.syncedLyrics ? parseLrc(result.syncedLyrics) : [], [result]);
  const activeIndex = lines.reduce((found, line, index) => line.time <= clock.time ? index : found, -1);
  const currentIndex = Math.max(0, activeIndex);

  const closeFullscreen = useCallback(() => setFullscreen(false), []);

  useEffect(() => {
    let cancelled = false;
    setResult(null);
    setLookupState("loading");
    setStatus("Finding lyrics…");
    setExpanded(false);
    setFullscreen(false);
    if (!title.trim() || clock.duration <= 0) return () => { cancelled = true; };

    void lookupLyrics(title.trim(), artist.trim(), album.trim(), clock.duration).then((data) => {
      if (cancelled) return;
      setResult(data);
      if (data && !data.instrumental && (data.syncedLyrics || data.plainLyrics)) {
        setLookupState("found");
        setStatus(data.syncedLyrics ? "Synchronized lyrics" : "Plain lyrics");
        setExpanded(true);
      } else {
        setLookupState("empty");
        setStatus(data?.instrumental ? "This track is instrumental." : "No lyrics found for this track.");
      }
    }).catch((error: unknown) => {
      if (cancelled) return;
      setLookupState("error");
      setStatus(error instanceof Error ? error.message : "Lyrics service unavailable.");
    });
    return () => { cancelled = true; };
  }, [trackId, title, artist, album, clock.duration]);

  useEffect(() => {
    const onToggle = () => setExpanded((value) => !value);
    const onFullscreen = () => {
      setExpanded(true);
      setFullscreen(true);
    };
    window.addEventListener("sonicly:toggle-audio-lyrics", onToggle);
    window.addEventListener("sonicly:fullscreen-audio-lyrics", onFullscreen);
    return () => {
      window.removeEventListener("sonicly:toggle-audio-lyrics", onToggle);
      window.removeEventListener("sonicly:fullscreen-audio-lyrics", onFullscreen);
    };
  }, []);

  useEffect(() => {
    if (!fullscreen || !activeLineRef.current) return;
    activeLineRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [fullscreen, activeIndex]);

  useEffect(() => {
    if (!fullscreen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        closeFullscreen();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [fullscreen, closeFullscreen]);

  if (!expanded && !fullscreen) return null;

  const previous = lines[currentIndex - 1];
  const current = lines[currentIndex];
  const next = lines[currentIndex + 1];

  return (
    <>
      {!fullscreen ? (
        <section className="shrink-0 border-t border-line bg-surface/95 px-4 py-3" aria-label="Integrated lyrics">
          <div className="mx-auto flex w-full max-w-5xl items-start gap-4">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent/15 text-accent">
              <Captions className="size-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="mb-2 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs font-semibold uppercase tracking-wider text-accent">Now playing · Lyrics</p>
                  <p className="truncate text-xs text-muted">{title} · {artist}</p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <button type="button" onClick={() => setFullscreen(true)} title="Fullscreen lyrics" aria-label="Fullscreen lyrics" className="inline-flex size-9 items-center justify-center rounded-lg text-muted hover:bg-raised hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                    <Maximize2 className="size-4" />
                  </button>
                  <button type="button" onClick={() => setExpanded(false)} title="Hide lyrics" aria-label="Hide lyrics" className="inline-flex size-9 items-center justify-center rounded-lg text-muted hover:bg-raised hover:text-fg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
                    <X className="size-4" />
                  </button>
                </div>
              </div>
              {lookupState === "loading" ? <p className="py-2 text-sm text-muted">{status}</p> : lines.length ? (
                <div className="space-y-1 text-center">
                  {previous ? <p className="truncate text-sm text-muted/70">{previous.text || "♪"}</p> : null}
                  {current ? <p className="text-base font-semibold leading-snug text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-blue-300 to-violet-400 sm:text-lg">{current.text || "♪"}</p> : <p className="text-sm text-muted">♪</p>}
                  {next ? <p className="truncate text-sm text-muted/80">{next.text || "♪"}</p> : null}
                </div>
              ) : result?.plainLyrics ? (
                <p className="line-clamp-2 whitespace-pre-line text-sm leading-relaxed text-fg/85">{result.plainLyrics}</p>
              ) : <p className="py-2 text-sm text-muted">{status}</p>}
              <p className="mt-2 text-[10px] text-muted/70">Lyrics provided by LRCLIB</p>
            </div>
          </div>
        </section>
      ) : null}

      {fullscreen ? (
        <div className="fixed inset-0 z-[120] flex flex-col bg-gradient-to-br from-[#080d1a] via-[#111b35] to-[#321d50] p-5 text-white sm:p-8" role="dialog" aria-modal="true" aria-label="Fullscreen lyrics">
          <header className="flex items-center gap-3 border-b border-white/15 pb-4">
            <Captions className="size-6 text-sky-300" />
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-xl font-semibold">Sonicly Lyrics</h2>
              <p className="truncate text-sm text-white/65">{title} · {artist}</p>
            </div>
            <button type="button" onClick={closeFullscreen} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-white/20 bg-white/10 px-3 text-sm font-semibold hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
              <Minimize2 className="size-4" /> Back to player
            </button>
            <button type="button" aria-label="Close fullscreen lyrics" onClick={closeFullscreen} className="inline-flex size-10 items-center justify-center rounded-lg hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"><X className="size-5" /></button>
          </header>
          {lookupState === "loading" ? <div className="flex flex-1 items-center justify-center text-white/70">{status}</div> : lines.length ? (
            <div className="min-h-0 flex-1 overflow-y-auto py-6 text-center">
              <div className="mx-auto flex max-w-4xl flex-col gap-5">
                {lines.map((line, index) => (
                  <p key={`${line.time}-${index}`} ref={index === currentIndex ? activeLineRef : undefined}
                    className={`text-lg font-semibold leading-relaxed transition-colors sm:text-2xl md:text-3xl ${index === activeIndex ? "bg-gradient-to-r from-sky-300 via-blue-300 to-violet-400 bg-clip-text text-transparent" : index < activeIndex ? "text-white/35" : "text-white/75"}`}>
                    {line.text || "♪"}
                  </p>
                ))}
              </div>
            </div>
          ) : result?.plainLyrics ? (
            <div className="min-h-0 flex-1 overflow-y-auto px-2 py-6 text-center text-base leading-8 sm:text-xl sm:leading-10"><p className="mx-auto max-w-3xl whitespace-pre-wrap">{result.plainLyrics}</p></div>
          ) : <div className="flex flex-1 items-center justify-center text-sm text-white/70">{status}</div>}
        </div>
      ) : null}
    </>
  );
}
