import * as Dialog from "@radix-ui/react-dialog";
import { Clapperboard, Image as ImageIcon, Music, Pencil, Trash2, X } from "lucide-react";
import { useState } from "react";
import { AddMedia } from "@/components/add-media";
import { Button, SearchField } from "@/components/bits";
import { formatBytes } from "@/player/format";
import { selectActiveItems, usePlayer } from "@/player/store";
import { metaOf, type MediaKind } from "@/player/types";
import { cn } from "@/lib/utils";

const filters: Array<{ id: "all" | MediaKind; label: string }> = [
  { id: "all", label: "All" },
  { id: "audio", label: "Music" },
  { id: "video", label: "Videos" },
  { id: "image", label: "Pictures" },
];

export function LibraryView() {
  const items = usePlayer(selectActiveItems);
  const librarySource = usePlayer((state) => state.settings.librarySource);
  const overrides = usePlayer((state) => state.overrides);
  const libraryQuery = usePlayer((state) => state.libraryQuery);
  const libraryKind = usePlayer((state) => state.libraryKind);
  const editingId = usePlayer((state) => state.editingId);
  const setLibraryQuery = usePlayer((state) => state.setLibraryQuery);
  const setLibraryKind = usePlayer((state) => state.setLibraryKind);
  const setEditing = usePlayer((state) => state.setEditing);
  const play = usePlayer((state) => state.play);
  const removeItem = usePlayer((state) => state.removeItem);
  const setOverride = usePlayer((state) => state.setOverride);
  const setCover = usePlayer((state) => state.setCover);
  const clearCover = usePlayer((state) => state.clearCover);
  const editing = librarySource === "local" ? items.find((item) => item.id === editingId) ?? null : null;
  const query = libraryQuery.trim().toLowerCase();
  const visible = items
    .filter((item) => libraryKind === "all" || item.kind === libraryKind)
    .filter((item) => {
      if (!query) return true;
      const meta = metaOf(item, overrides);
      return `${meta.title} ${meta.artist} ${meta.album} ${item.relPath}`.toLowerCase().includes(query);
    })
    .sort((a, b) => metaOf(a, overrides).title.localeCompare(metaOf(b, overrides).title, undefined, { sensitivity: "base" }));
  const counts = {
    audio: items.filter((item) => item.kind === "audio").length,
    video: items.filter((item) => item.kind === "video").length,
    image: items.filter((item) => item.kind === "image").length,
  };

  return (
    <div className="flex h-full flex-col gap-4 overflow-auto p-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-semibold tracking-tight">Library</h2>
          <p className="mt-1 text-sm text-muted">
            {counts.audio} tracks · {counts.video} videos · {counts.image} pictures
          </p>
        </div>
        {librarySource === "local" ? <AddMedia /> : null}
      </div>
      <SearchField value={libraryQuery} onChange={setLibraryQuery} placeholder="Search the library" label="Search the library" />
      <div className="flex gap-2 overflow-x-auto">
        {filters.map((filter) => (
          <button
            key={filter.id}
            type="button"
            onClick={() => setLibraryKind(filter.id)}
            className={cn(
              "min-h-11 shrink-0 rounded-full px-3 text-sm font-medium",
              libraryKind === filter.id ? "bg-accent text-bg" : "bg-raised text-fg",
            )}
          >
            {filter.label}
          </button>
        ))}
      </div>
      <ul className="overflow-hidden rounded-xl border border-line">
        {visible.map((item) => {
          const meta = metaOf(item, overrides);
          const Icon = item.kind === "audio" ? Music : item.kind === "video" ? Clapperboard : ImageIcon;
          return (
            <li key={item.id} className="flex items-center gap-3 border-b border-line px-3 py-2 last:border-b-0">
              <button type="button" onClick={() => (item.kind === "image" && librarySource === "local" ? setEditing(item.id) : play(item.id))} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-raised text-muted">
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate font-medium">{meta.title}</span>
                  <span className="block truncate text-sm text-muted">
                    {item.kind === "audio" ? `${meta.artist} · ${meta.album} · ` : ""}
                    {item.rootName} · {formatBytes(item.size)}
                  </span>
                </span>
              </button>
              {librarySource === "local" ? <>
                <button type="button" className="inline-flex size-11 items-center justify-center rounded-full hover:bg-raised" aria-label={`Edit ${meta.title}`} onClick={() => setEditing(item.id)}><Pencil className="size-4" /></button>
                <button type="button" className="inline-flex size-11 items-center justify-center rounded-full text-danger hover:bg-raised" aria-label={`Remove ${meta.title} from library`} onClick={() => removeItem(item.id)}><Trash2 className="size-4" /></button>
              </> : null}
            </li>
          );
        })}
        {!visible.length ? <li className="px-4 py-10 text-center text-muted">Nothing in this view yet.</li> : null}
      </ul>
      <Dialog.Root open={librarySource === "local" && Boolean(editing)} onOpenChange={(open) => !open && setEditing(null)}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/70" />
          <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-xl border border-line bg-surface p-5">
            {editing ? <EditForm key={editing.id} id={editing.id} onClose={() => setEditing(null)} setOverride={setOverride} setCover={setCover} clearCover={clearCover} removeItem={removeItem} /> : null}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </div>
  );
}

function EditForm({
  id,
  onClose,
  setOverride,
  setCover,
  clearCover,
  removeItem,
}: {
  id: string;
  onClose: () => void;
  setOverride: (id: string, patch: { title?: string; artist?: string; album?: string }) => void;
  setCover: (id: string, file: File) => Promise<void>;
  clearCover: (id: string) => Promise<void>;
  removeItem: (id: string) => void;
}) {
  const item = usePlayer((state) => state.items.find((candidate) => candidate.id === id));
  const overrides = usePlayer((state) => state.overrides);
  const meta = item ? metaOf(item, overrides) : null;
  const [title, setTitle] = useState(meta?.title ?? "");
  const [artist, setArtist] = useState(meta?.artist ?? "");
  const [album, setAlbum] = useState(meta?.album ?? "");
  if (!item || !meta) return null;

  return (
    <form
      className="flex flex-col gap-3"
      onSubmit={(event) => {
        event.preventDefault();
        setOverride(item.id, {
          title,
          artist: item.kind === "audio" ? artist : undefined,
          album: item.kind === "audio" ? album : undefined,
        });
        onClose();
      }}
    >
      <div className="flex items-start justify-between gap-3">
        <Dialog.Title className="font-display text-xl font-semibold">Edit details</Dialog.Title>
        <Dialog.Close className="inline-flex size-11 items-center justify-center rounded-full hover:bg-raised" aria-label="Close">
          <X className="size-4" />
        </Dialog.Close>
      </div>
      <p className="text-sm text-muted">This only changes how the file is labeled here. The file on disk stays as it is.</p>
      <label className="text-sm text-muted">
        Title
        <input value={title} onChange={(event) => setTitle(event.target.value)} className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg" />
      </label>
      {item.kind === "audio" ? (
        <>
          <label className="text-sm text-muted">
            Artist
            <input value={artist} onChange={(event) => setArtist(event.target.value)} className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg" />
          </label>
          <label className="text-sm text-muted">
            Album
            <input value={album} onChange={(event) => setAlbum(event.target.value)} className="mt-1 min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg" />
          </label>
        </>
      ) : null}
      <label className="text-sm text-muted">
        {item.kind === "video" ? "Thumbnail" : "Cover image"}
        <input
          type="file"
          accept="image/*"
          className="mt-1 block w-full text-sm text-fg file:mr-3 file:min-h-11 file:rounded-lg file:border-0 file:bg-raised file:px-3 file:text-fg"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void setCover(item.id, file);
            event.target.value = "";
          }}
        />
      </label>
      <div className="mt-2 flex flex-wrap gap-2">
        <Button type="submit">Save</Button>
        <Button type="button" variant="ghost" onClick={() => void clearCover(item.id)}>
          Clear image
        </Button>
        <Button
          type="button"
          variant="danger"
          onClick={() => {
            removeItem(item.id);
            onClose();
          }}
        >
          Remove from library
        </Button>
      </div>
    </form>
  );
}
