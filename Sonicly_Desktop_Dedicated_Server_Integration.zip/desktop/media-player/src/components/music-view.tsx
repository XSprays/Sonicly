import { Disc3, Music, Pause, Play } from "lucide-react";
import { useMemo, type ReactNode } from "react";
import { AddMedia } from "@/components/add-media";
import { Artwork, EmptyState, IconButton, SearchField, coverUrl } from "@/components/bits";
import { selectActiveItems, usePlayer, audioPool } from "@/player/store";
import { metaOf } from "@/player/types";
import { cn } from "@/lib/utils";

function sortLabels(values: string[]) {
  return values.sort((a, b) => {
    if (a === "Unknown") return 1;
    if (b === "Unknown") return -1;
    return a.localeCompare(b, undefined, { sensitivity: "base" });
  });
}

export function MusicView() {
  const items = usePlayer(selectActiveItems);
  const overrides = usePlayer((state) => state.overrides);
  const artUrls = usePlayer((state) => state.artUrls);
  const musicArtist = usePlayer((state) => state.musicArtist);
  const musicAlbum = usePlayer((state) => state.musicAlbum);
  const musicQuery = usePlayer((state) => state.musicQuery);
  const currentId = usePlayer((state) => state.currentId);
  const playing = usePlayer((state) => state.playing);
  const booted = usePlayer((state) => state.booted);
  const librarySource = usePlayer((state) => state.settings.librarySource);
  const play = usePlayer((state) => state.play);
  const toggle = usePlayer((state) => state.toggle);
  const setMusicArtist = usePlayer((state) => state.setMusicArtist);
  const setMusicAlbum = usePlayer((state) => state.setMusicAlbum);
  const setMusicQuery = usePlayer((state) => state.setMusicQuery);

  const tracks = items.filter((item) => item.kind === "audio");
  const artists = useMemo(() => {
    const names = new Set<string>();
    for (const item of tracks) names.add(metaOf(item, overrides).artist);
    return sortLabels([...names]);
  }, [tracks, overrides]);
  const albums = useMemo(() => {
    const names = new Set<string>();
    for (const item of tracks) {
      const meta = metaOf(item, overrides);
      if (musicArtist !== "all" && meta.artist !== musicArtist) continue;
      names.add(meta.album);
    }
    return sortLabels([...names]);
  }, [tracks, overrides, musicArtist]);
  const visible = audioPool({ items, overrides, musicArtist, musicAlbum, musicQuery });
  const current = items.find((item) => item.id === currentId && item.kind === "audio") ?? visible[0] ?? null;
  const meta = current ? metaOf(current, overrides) : null;

  if (!booted) {
    return <EmptyState icon={<Music className="size-7" />} title="Opening library" body="Checking this browser for folders you linked earlier." />;
  }

  if (!tracks.length) {
    return (
      <EmptyState
        icon={<Music className="size-7" />}
        title="Your music"
        body={librarySource === "server" ? "No music is available in the connected server library. Add music to the server’s music folder, then refresh it from the Server page." : "Add MP3s or a music folder. Tags fill in the artist and album when the file has them. Otherwise the folder names are used."}
      >
        {librarySource === "local" ? <AddMedia /> : null}
      </EmptyState>
    );
  }

  return (
    <div className="h-full overflow-auto lg:overflow-hidden">
      <div className="flex flex-col gap-4 p-4 lg:h-full lg:min-h-0">
        <section className="flex flex-col gap-4 rounded-xl border border-line bg-surface/80 p-4 sm:flex-row sm:items-center">
          <Artwork
            src={current ? coverUrl(current, artUrls) : null}
            className="size-36 shrink-0 rounded-xl sm:size-44"
            icon={<Disc3 className="size-10" />}
          />
          <div className="min-w-0">
            <p className="text-sm font-medium text-accent">Now playing</p>
            <h2 className="mt-1 truncate font-display text-3xl font-semibold tracking-tight">{meta?.title ?? "Select a track"}</h2>
            <p className="mt-1 truncate text-muted">{meta ? `${meta.artist} · ${meta.album}` : "Your library is ready"}</p>
            <div className="mt-3">
              <IconButton
                aria-label={playing && current?.id === currentId ? "Pause" : "Play"}
                disabled={!current}
                onClick={() => {
                  if (!current) return;
                  if (current.id === currentId) toggle();
                  else play(current.id);
                }}
                className="bg-accent text-bg hover:bg-accent/90"
              >
                {playing && current?.id === currentId ? <Pause className="size-5" /> : <Play className="size-5" />}
              </IconButton>
            </div>
          </div>
        </section>
        <div className="grid gap-3 lg:min-h-0 lg:flex-1 lg:grid-cols-[13rem_13rem_minmax(0,1fr)] lg:overflow-hidden">
          <NameColumn title="Artists" active={musicArtist === "all"} allLabel="All music" onAll={() => setMusicArtist("all")}>
            {artists.map((artist) => (
              <NameButton key={artist} active={musicArtist === artist} label={artist} onClick={() => setMusicArtist(artist)} />
            ))}
          </NameColumn>
          <NameColumn title="Albums" active={musicAlbum === "all"} allLabel="All albums" onAll={() => setMusicAlbum("all")}>
            {albums.map((album) => (
              <NameButton key={album} active={musicAlbum === album} label={album} onClick={() => setMusicAlbum(album)} />
            ))}
          </NameColumn>
          <section className="flex min-h-64 flex-col rounded-xl border border-line bg-surface/80 lg:min-h-0">
            <div className="flex items-center justify-between gap-3 border-b border-line px-3 py-2">
              <h3 className="font-display text-sm font-semibold">Tracks</h3>
              <span className="text-sm text-muted">{visible.length}</span>
            </div>
            <div className="p-2">
              <SearchField value={musicQuery} onChange={setMusicQuery} placeholder="Search tracks, artists, albums" label="Search music" />
            </div>
            <ul className="min-h-0 flex-1 overflow-auto px-2 pb-2">
              {visible.map((item) => {
                const info = metaOf(item, overrides);
                const active = item.id === currentId;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => play(item.id)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left",
                        active ? "bg-accent text-bg" : "hover:bg-raised",
                      )}
                    >
                      <Artwork src={coverUrl(item, artUrls)} className="size-11 shrink-0 rounded-md" icon={<Music className="size-4" />} />
                      <span className="min-w-0">
                        <span className="block truncate font-medium">{info.title}</span>
                        <span className={cn("block truncate text-sm", active ? "text-bg/80" : "text-muted")}>
                          {info.artist} · {info.album}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
              {!visible.length ? <li className="px-2 py-6 text-sm text-muted">No tracks match.</li> : null}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}

function NameColumn({
  title,
  active,
  allLabel,
  onAll,
  children,
}: {
  title: string;
  active: boolean;
  allLabel: string;
  onAll: () => void;
  children: ReactNode;
}) {
  return (
    <section className="flex max-h-64 flex-col rounded-xl border border-line bg-surface/80 lg:max-h-none lg:min-h-0">
      <h3 className="border-b border-line px-3 py-2 font-display text-sm font-semibold">{title}</h3>
      <ul className="min-h-0 flex-1 overflow-auto p-2">
        <li>
          <NameButton active={active} label={allLabel} onClick={onAll} />
        </li>
        {children}
      </ul>
    </section>
  );
}

function NameButton({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "block min-h-11 w-full truncate rounded-lg px-3 text-left text-sm",
        active ? "bg-accent font-semibold text-bg" : "hover:bg-raised",
      )}
    >
      {label}
    </button>
  );
}
