import { Clapperboard, Disc3, Image as ImageIcon, Library, Music, Server, Settings, Waves, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { AddMedia } from "@/components/add-media";
import { GalleryView } from "@/components/gallery-view";
import { LibraryView } from "@/components/library-view";
import { MusicView } from "@/components/music-view";
import { SettingsView } from "@/components/settings-view";
import { ServerView } from "@/components/server-view";
import { Transport } from "@/components/transport";
import { IntegratedLyricsPanel } from "@/components/integrated-lyrics-panel";
import { VisualizerView } from "@/components/visualizer-view";
import { VideosView } from "@/components/videos-view";
import { publishClock } from "@/player/clock";
import { media } from "@/player/media";
import { desktop } from "@/player/desktop";
import { selectActiveItems, usePlayer } from "@/player/store";
import { metaOf, type ViewId } from "@/player/types";
import { cn } from "@/lib/utils";

const nav: Array<{ id: ViewId; label: string; icon: typeof Music; flag?: "videosEnabled" | "musicEnabled" | "galleryEnabled" }> = [
  { id: "videos", label: "Videos", icon: Clapperboard, flag: "videosEnabled" },
  { id: "music", label: "Music", icon: Music, flag: "musicEnabled" },
  { id: "gallery", label: "Gallery", icon: ImageIcon, flag: "galleryEnabled" },
  { id: "library", label: "Library", icon: Library },
  { id: "server", label: "Server", icon: Server },
  { id: "visualizer", label: "Visualizer", icon: Waves },
  { id: "settings", label: "Settings", icon: Settings },
];

export function PlayerApp() {
  const view = usePlayer((state) => state.view);
  const settings = usePlayer((state) => state.settings);
  const setView = usePlayer((state) => state.setView);
  const boot = usePlayer((state) => state.boot);
  const importDrop = usePlayer((state) => state.importDrop);
  const notice = usePlayer((state) => state.notice);
  const dismissNotice = usePlayer((state) => state.dismissNotice);
  const folders = usePlayer((state) => state.folders);
  const scan = usePlayer((state) => state.scan);
  const backgroundUrl = usePlayer((state) => state.backgroundUrl);
  const currentId = usePlayer((state) => state.currentId);
  const playing = usePlayer((state) => state.playing);
  const items = usePlayer(selectActiveItems);
  const overrides = usePlayer((state) => state.overrides);
  const toggle = usePlayer((state) => state.toggle);
  const seek = usePlayer((state) => state.seek);
  const updateSettings = usePlayer((state) => state.updateSettings);
  const setPreview = usePlayer((state) => state.setPreview);
  const [dragging, setDragging] = useState(false);
  const depth = useRef(0);
  const visibleNav = nav.filter((item) => !item.flag || settings[item.flag]);
  const needs = folders.filter((folder) => folder.needsPermission);
  const currentItem = items.find((candidate) => candidate.id === currentId) ?? null;
  const currentAudio = currentItem?.kind === "audio" && playing ? currentItem : null;
  const currentAudioMeta = currentAudio ? metaOf(currentAudio, overrides) : null;

  useEffect(() => {
    void boot();
  }, [boot]);

  useEffect(() => {
    const item = items.find((candidate) => candidate.id === currentId);
    const meta = item ? metaOf(item, overrides) : null;
    document.title = meta ? `${meta.title} · Sonicly` : "Sonicly";
  }, [currentId, items, overrides]);

  useEffect(() => {
    const api = desktop();
    if (!api) return;
    const syncPresence = () => {
      const item = items.find((candidate) => candidate.id === currentId && candidate.kind === "audio");
      const meta = item ? metaOf(item, overrides) : null;
      const element = item && media.audio?.dataset.mediaId === item.id ? media.audio : null;
      void api.setDiscordPresence({
        enabled: settings.discordPresenceEnabled,
        clientId: settings.discordClientId,
        title: meta?.title ?? "",
        artist: meta?.artist ?? "",
        album: meta?.album ?? "",
        playing: Boolean(playing && element && !element.paused),
        position: element?.currentTime ?? 0,
        duration: element?.duration ?? 0,
      });
    };
    syncPresence();
    const interval = window.setInterval(syncPresence, 15000);
    return () => window.clearInterval(interval);
  }, [currentId, items, overrides, playing, settings.discordPresenceEnabled, settings.discordClientId]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLSelectElement ||
        target instanceof HTMLButtonElement
      ) {
        return;
      }
      if (event.code === "Space") {
        event.preventDefault();
        toggle();
        return;
      }
      if ((event.code === "ArrowRight" || event.code === "ArrowLeft") && view !== "gallery") {
        const element =
          media.audio?.dataset.mediaId === currentId
            ? media.audio
            : media.video?.dataset.mediaId === currentId
              ? media.video
              : null;
        if (!element?.duration) return;
        const delta = event.code === "ArrowRight" ? 5 : -5;
        seek(Math.min(element.duration, Math.max(0, element.currentTime + delta)) / element.duration);
        return;
      }
      if (event.code === "ArrowUp") {
        event.preventDefault();
        updateSettings({ volume: Math.min(1, settings.volume + 0.05) });
      } else if (event.code === "ArrowDown") {
        event.preventDefault();
        updateSettings({ volume: Math.max(0, settings.volume - 0.05) });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, seek, updateSettings, settings.volume, currentId, view]);

  useEffect(() => {
    if (view !== "gallery") return;
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      if (event.code !== "ArrowLeft" && event.code !== "ArrowRight") return;
      const images = items.filter((item) => item.kind === "image");
      if (!images.length) return;
      const current = usePlayer.getState().previewId;
      const index = Math.max(0, images.findIndex((item) => item.id === current));
      const next = event.code === "ArrowRight" ? Math.min(images.length - 1, index + 1) : Math.max(0, index - 1);
      setPreview(images[next]?.id ?? null);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [view, items, setPreview]);

  return (
    <div
      className="flex h-dvh flex-col overflow-hidden bg-bg text-fg"
      onDragEnter={(event) => {
        event.preventDefault();
        depth.current += 1;
        setDragging(true);
      }}
      onDragOver={(event) => event.preventDefault()}
      onDragLeave={(event) => {
        event.preventDefault();
        depth.current -= 1;
        if (depth.current <= 0) {
          depth.current = 0;
          setDragging(false);
        }
      }}
      onDrop={(event) => {
        event.preventDefault();
        depth.current = 0;
        setDragging(false);
        if (settings.librarySource === "local" && (event.dataTransfer.files.length || event.dataTransfer.items.length)) void importDrop(event.dataTransfer);
      }}
    >
      {backgroundUrl ? (
        <div className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-40" style={{ backgroundImage: `url("${backgroundUrl}")` }} />
      ) : null}
      <div className="pointer-events-none absolute inset-0 bg-bg/80" />
      <div className="relative flex min-h-0 flex-1">
        <aside className="hidden w-56 shrink-0 flex-col border-r border-line bg-surface/90 md:flex">
          <div className="flex items-center gap-3 px-4 py-5">
            <div className="flex size-10 items-center justify-center rounded-lg bg-accent text-bg">
              <Disc3 className="size-5" aria-hidden="true" />
            </div>
            <div>
              <p className="font-display text-lg font-semibold leading-none">Sonicly</p>
              <p className="mt-1 text-sm text-muted">{settings.librarySource === "server" ? "Server files" : "Local files"}</p>
            </div>
          </div>
          <nav className="flex flex-col gap-1 px-3" aria-label="Library">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const active = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setView(item.id)}
                  className={cn(
                    "flex min-h-11 items-center gap-3 rounded-lg px-3 text-left font-medium",
                    active ? "bg-accent text-bg" : "text-fg hover:bg-raised",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </nav>
          {settings.librarySource === "local" ? <div className="mt-auto p-3"><AddMedia stacked /></div> : null}
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 md:hidden">
            <p className="font-display text-lg font-semibold">Sonicly · {settings.librarySource === "server" ? "Server files" : "Local files"}</p>
            {settings.librarySource === "local" ? <AddMedia compact /> : null}
          </header>
          {scan ? (
            <div className="border-b border-line px-4 py-2">
              <p className="text-sm text-muted">
                Reading {scan.label} · {scan.done} / {scan.total}
              </p>
              <div className="mt-1 h-1 overflow-hidden rounded-full bg-line">
                <div className="h-full bg-accent" style={{ width: `${scan.total ? Math.min(100, (scan.done / scan.total) * 100) : 0}%` }} />
              </div>
            </div>
          ) : null}
          {notice ? (
            <div className="flex items-start justify-between gap-3 border-b border-line bg-raised px-4 py-2 text-sm">
              <p>{notice}</p>
              <button type="button" className="inline-flex size-11 items-center justify-center" aria-label="Dismiss notice" onClick={() => dismissNotice()}>
                <X className="size-4" />
              </button>
            </div>
          ) : null}
          {settings.librarySource === "local" && needs.length ? (
            <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-2 text-sm">
              <p className="text-muted">A saved folder needs a click before it can be read again.</p>
              {needs.map((folder) => (
                <button key={folder.id} type="button" className="min-h-11 rounded-lg bg-accent px-3 font-semibold text-bg" onClick={() => void usePlayer.getState().reconnect(folder.id)}>
                  Reconnect {folder.name}
                </button>
              ))}
            </div>
          ) : null}
          <main className="relative min-h-0 flex-1">
            <section className={cn("h-full", view !== "videos" && "hidden")} aria-hidden={view !== "videos"}>
              <VideosView />
            </section>
            {view === "music" ? (
              <section className="h-full">
                <MusicView />
              </section>
            ) : null}
            {view === "gallery" ? (
              <section className="h-full">
                <GalleryView />
              </section>
            ) : null}
            {view === "library" ? (
              <section className="h-full">
                <LibraryView />
              </section>
            ) : null}
            {view === "server" ? (
              <section className="h-full"><ServerView /></section>
            ) : null}
            {view === "visualizer" ? (
              <section className="h-full">
                <VisualizerView />
              </section>
            ) : null}
            {view === "settings" ? (
              <section className="h-full">
                <SettingsView />
              </section>
            ) : null}
          </main>
          {currentAudio && currentAudioMeta ? (
            <IntegratedLyricsPanel
              key={currentAudio.id}
              trackId={currentAudio.id}
              title={currentAudioMeta.title}
              artist={currentAudioMeta.artist}
              album={currentAudioMeta.album}
            />
          ) : null}
        </div>
      </div>
      <audio
        ref={(node) => {
          media.audio = node;
        }}
        className="pointer-events-none absolute h-px w-px opacity-0"
        preload="metadata"
        onTimeUpdate={(event) => {
          if (event.currentTarget.dataset.mediaId !== usePlayer.getState().currentId) return;
          publishClock(event.currentTarget.currentTime, event.currentTarget.duration || 0);
        }}
        onLoadedMetadata={(event) => {
          if (event.currentTarget.dataset.mediaId !== usePlayer.getState().currentId) return;
          publishClock(event.currentTarget.currentTime, event.currentTarget.duration || 0);
        }}
        onPlay={() => usePlayer.getState().notePlay()}
        onPause={() => usePlayer.getState().notePause()}
        onEnded={(event) => {
          if (event.currentTarget.dataset.mediaId !== usePlayer.getState().currentId) return;
          usePlayer.getState().next(true);
        }}
        onError={() => {
          const id = media.audio?.dataset.mediaId;
          if (!id || id !== usePlayer.getState().currentId) return;
          usePlayer.getState().fail("This browser can't decode that audio file. MP3, WAV, and OGG usually work.");
        }}
      />
      <div className="relative">
        <Transport />
        <nav className="flex border-t border-line bg-surface md:hidden" aria-label="Library">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={cn(
                  "flex min-h-16 flex-1 flex-col items-center justify-center gap-1 text-xs font-medium",
                  active ? "text-accent" : "text-muted",
                )}
              >
                <Icon className="size-5" aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>
      {dragging ? (
        <div className="pointer-events-none absolute inset-0 z-50 flex items-center justify-center bg-bg/80 p-6">
          <div className="rounded-2xl border border-accent bg-surface px-8 py-6 text-center">
            <p className="font-display text-2xl font-semibold">Drop to add</p>
            <p className="mt-2 text-muted">Files or a folder of music, video, and pictures.</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
