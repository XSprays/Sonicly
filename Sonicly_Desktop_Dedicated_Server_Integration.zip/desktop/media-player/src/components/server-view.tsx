import {
  AlertCircle,
  CheckCircle2,
  Clapperboard,
  HardDrive,
  Image as ImageIcon,
  KeyRound,
  Music2,
  RefreshCw,
  Server,
  Unplug,
  Wifi,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button, SearchField } from "@/components/bits";
import { desktop } from "@/player/desktop";
import { fetchRemoteMedia, type RemoteMedia } from "@/player/remote";
import { usePlayer } from "@/player/store";

type RemoteServer = {
  baseUrl: string;
  token: string;
  deviceId?: string;
  hostId?: string;
};

type RemoteStatus = {
  name: string;
  version: string;
  protocol: number;
  streaming: boolean;
  photos: boolean;
  serverType: string;
};

type ApiError = Error & { status?: number };

const SESSION_KEY = "sonicly.remote-server.v1";

type ApiOptions = {
  token?: string;
  method?: string;
  body?: unknown;
};

function normalizeServerUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) throw new Error("Enter your Sonicly server address.");
  const candidate = /^[a-z][a-z\d+.-]*:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    throw new Error("Enter a valid address, such as https://media.example.com:47831.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("Sonicly servers must use HTTP or HTTPS.");
  }
  if (url.username || url.password || url.search || url.hash) {
    throw new Error("Remove credentials, query strings, and fragments from the server address.");
  }
  if (url.protocol === "http:" && !url.port) url.port = "47831";
  return url.toString().replace(/\/+$/, "");
}

async function apiJson<T>(baseUrl: string, path: string, options: ApiOptions = {}): Promise<T> {
  const headers = new Headers({ accept: "application/json" });
  if (options.token) headers.set("authorization", `Bearer ${options.token}`);
  if (options.body !== undefined) headers.set("content-type", "application/json");
  let response: Response;
  try {
    response = await fetch(`${baseUrl}${path}`, {
      method: options.method || "GET",
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      cache: "no-store",
      signal: AbortSignal.timeout(15000),
    });
  } catch {
    throw new Error("Couldn't reach that server. Check the address, port, firewall, and HTTPS setup.");
  }
  let payload: Record<string, unknown> = {};
  try {
    payload = (await response.json()) as Record<string, unknown>;
  } catch {
    // A non-JSON response is reported as a normal connection error below.
  }
  if (!response.ok) {
    const message = typeof payload.message === "string"
      ? payload.message
      : typeof payload.error === "string"
        ? payload.error.replaceAll("_", " ")
        : `Server returned HTTP ${response.status}.`;
    const error = new Error(message) as ApiError;
    error.status = response.status;
    throw error;
  }
  return payload as T;
}

async function readSavedConnection(): Promise<RemoteServer | null> {
  const api = desktop();
  if (api?.getRemoteServer) return api.getRemoteServer();
  try {
    const raw = window.sessionStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as RemoteServer) : null;
  } catch {
    return null;
  }
}

async function saveConnection(connection: RemoteServer) {
  const api = desktop();
  if (api?.saveRemoteServer) {
    await api.saveRemoteServer(connection);
    return;
  }
  // Browser previews only keep the token for the current tab session.
  window.sessionStorage.setItem(SESSION_KEY, JSON.stringify(connection));
}

async function clearConnection() {
  const api = desktop();
  if (api?.clearRemoteServer) {
    await api.clearRemoteServer();
    return;
  }
  window.sessionStorage.removeItem(SESSION_KEY);
}

function formatBytes(value: number) {
  if (!Number.isFinite(value) || value < 0) return "—";
  if (value < 1024) return `${value} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let size = value / 1024;
  let index = 0;
  while (size >= 1024 && index < units.length - 1) {
    size /= 1024;
    index += 1;
  }
  return `${size.toFixed(size >= 100 ? 0 : 1)} ${units[index]}`;
}

function mediaLabel(kind: RemoteMedia["mediaType"]) {
  if (kind === "audio") return "Music";
  if (kind === "video") return "Video";
  return "Photo";
}

function mediaIcon(kind: RemoteMedia["mediaType"]) {
  if (kind === "audio") return Music2;
  if (kind === "video") return Clapperboard;
  return ImageIcon;
}

export function ServerView() {
  const [serverUrl, setServerUrl] = useState("");
  const [pairCode, setPairCode] = useState("");
  const [challengeId, setChallengeId] = useState("");
  const [connection, setConnection] = useState<RemoteServer | null>(null);
  const [serverStatus, setServerStatus] = useState<RemoteStatus | null>(null);
  const [items, setItems] = useState<RemoteMedia[]>([]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | RemoteMedia["mediaType"]>("all");
  const [busy, setBusy] = useState(false);
  const [loadingSaved, setLoadingSaved] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const loadLibrary = useCallback(async (saved: RemoteServer, persist = false) => {
    const result = await fetchRemoteMedia(saved);
    // Persist only after the server status and full library have been validated.
    if (persist) await saveConnection(saved);
    setConnection(saved);
    setServerStatus(result.status);
    setItems(result.media);
    usePlayer.getState().setRemoteLibrary(result.items, true);
    setMessage(result.truncated
      ? `Connected. Loaded ${result.items.length.toLocaleString()} of at least ${result.total.toLocaleString()} files (client safety limit reached).`
      : `Connected and loaded ${result.items.length.toLocaleString()} server files. Select “Server files” in Settings to use them in Sonicly.`);
    setChallengeId("");
    setPairCode("");
  }, []);

  useEffect(() => {
    let active = true;
    void (async () => {
      try {
        const saved = await readSavedConnection();
        if (!active || !saved) return;
        setServerUrl(saved.baseUrl);
        if (saved.token) {
          try {
            await loadLibrary(saved);
          } catch (reason) {
            if (active) {
              setConnection(null);
              usePlayer.getState().setRemoteLibrary([], false);
              setError(reason instanceof Error ? reason.message : "Couldn't reconnect to the saved server.");
            }
          }
        }
      } catch (reason) {
        if (active) setError(reason instanceof Error ? reason.message : "Couldn't read the saved server connection.");
      } finally {
        if (active) setLoadingSaved(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [loadLibrary]);

  const startPairing = async () => {
    setBusy(true);
    setError("");
    setMessage("");
    setChallengeId("");
    setConnection(null);
    setServerStatus(null);
    setItems([]);
    usePlayer.getState().setRemoteLibrary([], false);
    try {
      const baseUrl = normalizeServerUrl(serverUrl);
      setServerUrl(baseUrl);
      const discovery = await apiJson<{ name: string; protocol: number; serverType: string }>(baseUrl, "/api/v1/discover");
      if (discovery.name !== "Sonicly" || discovery.protocol !== 1 || discovery.serverType !== "dedicated") {
        throw new Error("That address did not identify a compatible Sonicly dedicated server.");
      }
      const challenge = await apiJson<{ challengeId: string; expiresIn: number; pairingRequired: boolean }>(
        baseUrl,
        "/api/v1/pair/request",
        { method: "POST", body: { deviceName: "Sonicly Desktop", platform: "desktop" } },
      );
      setChallengeId(challenge.challengeId);
      setMessage(`Server found. Enter the four-digit pairing code printed in its console for this request within ${challenge.expiresIn} seconds.`);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Couldn't start pairing.");
    } finally {
      setBusy(false);
    }
  };

  const completePairing = async () => {
    if (!challengeId) return;
    if (!/^\d{4}$/.test(pairCode.trim())) {
      setError("Enter the four-digit code printed in the server console for this pairing request.");
      return;
    }
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const baseUrl = normalizeServerUrl(serverUrl);
      const result = await apiJson<{ token: string; deviceId: string; hostId: string }>(
        baseUrl,
        "/api/v1/pair/complete",
        { method: "POST", body: { challengeId, code: pairCode.trim() } },
      );
      const saved: RemoteServer = {
        baseUrl,
        token: result.token,
        deviceId: result.deviceId,
        hostId: result.hostId,
      };
      await loadLibrary(saved, true);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Pairing failed.");
    } finally {
      setBusy(false);
    }
  };

  const refresh = async () => {
    if (!connection) return;
    setBusy(true);
    setError("");
    try {
      await loadLibrary(connection);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Couldn't refresh the remote library.");
    } finally {
      setBusy(false);
    }
  };

  const disconnect = async () => {
    setBusy(true);
    setError("");
    try {
      await clearConnection();
      setConnection(null);
      setServerStatus(null);
      setItems([]);
      usePlayer.getState().setRemoteLibrary([], false);
      setChallengeId("");
      setPairCode("");
      setMessage("Disconnected from this app. The paired device token remains on the server until revoked there.");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Couldn't clear the saved connection.");
    } finally {
      setBusy(false);
    }
  };

  const visibleItems = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => {
      if (filter !== "all" && item.mediaType !== filter) return false;
      if (!needle) return true;
      return `${item.title} ${item.fileName} ${item.path} ${item.folder}`.toLowerCase().includes(needle);
    });
  }, [filter, items, query]);

  const counts = useMemo(() => ({
    audio: items.filter((item) => item.mediaType === "audio").length,
    video: items.filter((item) => item.mediaType === "video").length,
    photo: items.filter((item) => item.mediaType === "photo").length,
  }), [items]);

  return (
    <div className="h-full overflow-auto">
      <div className="mx-auto flex max-w-5xl flex-col gap-6 p-4 pb-8 md:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Server className="size-6 text-accent" aria-hidden="true" />
              <h2 className="font-display text-2xl font-semibold tracking-tight">Sonicly Server</h2>
            </div>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
              Connect to a Sonicly dedicated server hosted on your VPS or another computer. Your local library stays separate.
            </p>
          </div>
          {connection ? (
            <div className="flex gap-2">
              <Button type="button" variant="ghost" disabled={busy} onClick={() => void refresh()}>
                <RefreshCw className={`size-4 ${busy ? "animate-spin" : ""}`} /> Refresh
              </Button>
              <Button type="button" variant="ghost" disabled={busy} onClick={() => void disconnect()}>
                <Unplug className="size-4" /> Disconnect
              </Button>
            </div>
          ) : null}
        </div>

        {error ? (
          <div role="alert" className="flex items-start gap-2 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
            <AlertCircle className="mt-0.5 size-4 shrink-0" />
            <p>{error}</p>
          </div>
        ) : null}
        {message ? (
          <div role="status" className="flex items-start gap-2 rounded-lg border border-accent/30 bg-accent/10 p-3 text-sm">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-accent" />
            <p>{message}</p>
          </div>
        ) : null}

        {!connection ? (
          <section className="rounded-xl border border-line bg-surface/80 p-4 md:p-5">
            <div className="flex items-center gap-2">
              <Wifi className="size-5 text-accent" />
              <h3 className="font-display text-lg font-semibold">Connect to a server</h3>
            </div>
            <p className="mt-1 text-sm leading-relaxed text-muted">
              Enter the server's public IP or domain and port. The default port is <span className="font-mono">47831</span>. A unique pairing code is printed in the server console when you request pairing. Each device gets its own short-lived code.
            </p>
            <label className="mt-4 block text-sm font-medium" htmlFor="sonicly-server-url">Server address</label>
            <input
              id="sonicly-server-url"
              value={serverUrl}
              onChange={(event) => setServerUrl(event.target.value)}
              onKeyDown={(event) => { if (event.key === "Enter" && !challengeId) void startPairing(); }}
              placeholder="https://media.example.com:47831"
              autoComplete="url"
              spellCheck={false}
              disabled={busy || loadingSaved}
              className="mt-2 min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm text-fg outline-none focus:border-accent disabled:opacity-50"
            />
            {challengeId ? (
              <>
                <label className="mt-4 block text-sm font-medium" htmlFor="sonicly-pair-code">Four-digit pairing code</label>
                <input
                  id="sonicly-pair-code"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={4}
                  value={pairCode}
                  onChange={(event) => setPairCode(event.target.value.replace(/\D/g, "").slice(0, 4))}
                  onKeyDown={(event) => { if (event.key === "Enter") void completePairing(); }}
                  placeholder="1234"
                  className="mt-2 min-h-11 w-full max-w-xs rounded-lg border border-line bg-bg px-3 font-mono text-lg tracking-[0.35em] text-fg outline-none focus:border-accent"
                />
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button type="button" disabled={busy || pairCode.length !== 4} onClick={() => void completePairing()}>
                    <KeyRound className="size-4" /> {busy ? "Pairing…" : "Pair device"}
                  </Button>
                  <Button type="button" variant="ghost" disabled={busy} onClick={() => { setChallengeId(""); setPairCode(""); setMessage(""); }}>
                    Cancel
                  </Button>
                </div>
              </>
            ) : (
              <div className="mt-4">
                <Button type="button" disabled={busy || loadingSaved || !serverUrl.trim()} onClick={() => void startPairing()}>
                  <Wifi className="size-4" /> {busy ? "Connecting…" : loadingSaved ? "Loading saved connection…" : "Find server and pair"}
                </Button>
              </div>
            )}
            <p className="mt-4 text-xs leading-relaxed text-muted">
              Use HTTPS or a VPN when connecting over the public internet. Plain HTTP is suitable only for a trusted local network. Pairing grants this desktop its own revocable device token.
            </p>
          </section>
        ) : (
          <>
            <section className="rounded-xl border border-line bg-surface/80 p-4 md:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="size-2.5 rounded-full bg-emerald-400" />
                    <h3 className="font-display text-lg font-semibold">{serverStatus?.name || "Sonicly"}</h3>
                  </div>
                  <p className="mt-1 break-all font-mono text-xs text-muted">{connection.baseUrl}</p>
                  <p className="mt-2 text-xs text-muted">Dedicated server · API v{serverStatus?.protocol ?? 1} · Server version {serverStatus?.version || "—"}</p>
                </div>
                <div className="inline-flex items-center gap-2 rounded-lg bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300">
                  <CheckCircle2 className="size-4" /> Connected
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Stat icon={HardDrive} label="Remote files" value={items.length.toLocaleString()} />
                <Stat icon={Music2} label="Music" value={counts.audio.toLocaleString()} />
                <Stat icon={Clapperboard} label="Videos" value={counts.video.toLocaleString()} />
                <Stat icon={ImageIcon} label="Photos" value={counts.photo.toLocaleString()} />
              </div>
            </section>

            <section className="flex min-h-0 flex-1 flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-lg font-semibold">Remote library</h3>
                  <p className="text-xs text-muted">Files hosted on your dedicated server.</p>
                </div>
                <div className="w-full sm:max-w-xs">
                  <SearchField value={query} onChange={setQuery} placeholder="Search remote media…" label="Search remote media" />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {(["all", "audio", "video", "photo"] as const).map((kind) => (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setFilter(kind)}
                    className={`min-h-10 rounded-lg px-3 text-sm font-medium transition-colors ${filter === kind ? "bg-accent text-bg" : "bg-raised text-muted hover:text-fg"}`}
                  >
                    {kind === "all" ? "Everything" : kind === "audio" ? "Music" : kind === "video" ? "Videos" : "Photos"}
                  </button>
                ))}
              </div>
              {visibleItems.length ? (
                <div className="overflow-hidden rounded-xl border border-line bg-surface/70">
                  {visibleItems.map((item) => {
                    const Icon = mediaIcon(item.mediaType);
                    return (
                      <div key={item.id} className="flex min-w-0 items-center gap-3 border-b border-line px-3 py-3 last:border-b-0">
                        <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-raised text-accent">
                          <Icon className="size-5" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium" title={item.title}>{item.title}</p>
                          <p className="truncate text-xs text-muted" title={item.path}>{item.path}</p>
                        </div>
                        <div className="hidden shrink-0 text-right sm:block">
                          <p className="text-xs text-muted">{mediaLabel(item.mediaType)}</p>
                          <p className="text-xs tabular-nums text-muted">{formatBytes(item.size)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-xl border border-dashed border-line px-4 py-10 text-center">
                  <HardDrive className="mx-auto size-8 text-muted" />
                  <p className="mt-2 font-medium">No files found</p>
                  <p className="mt-1 text-sm text-muted">Try another filter or add media to the server's music, videos, or photos folders.</p>
                </div>
              )}
              <p className="text-xs text-muted">
                Showing {visibleItems.length.toLocaleString()} of {items.length.toLocaleString()} loaded files. Choose “Server files” in Settings to use this library in Sonicly’s Music, Videos, and Gallery players.
              </p>
            </section>
          </>
        )}
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof HardDrive; label: string; value: string }) {
  return (
    <div className="rounded-lg bg-bg p-3">
      <div className="flex items-center gap-2 text-muted">
        <Icon className="size-4" />
        <span className="text-xs">{label}</span>
      </div>
      <p className="mt-1 font-display text-xl font-semibold tabular-nums">{value}</p>
    </div>
  );
}
