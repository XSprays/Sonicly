import * as Switch from "@radix-ui/react-switch";
import { useState } from "react";
import { Button } from "@/components/bits";
import { usePlayer } from "@/player/store";
import { desktop } from "@/player/desktop";

export function SettingsView() {
  const settings = usePlayer((state) => state.settings);
  const folders = usePlayer((state) => state.folders);
  const backgroundUrl = usePlayer((state) => state.backgroundUrl);
  const updateSettings = usePlayer((state) => state.updateSettings);
  const reconnect = usePlayer((state) => state.reconnect);
  const rescan = usePlayer((state) => state.rescan);
  const removeFolder = usePlayer((state) => state.removeFolder);
  const setBackground = usePlayer((state) => state.setBackground);
  const clearLibrary = usePlayer((state) => state.clearLibrary);
  const remoteConnected = usePlayer((state) => state.remoteConnected);
  const remoteItems = usePlayer((state) => state.remoteItems);
  const setView = usePlayer((state) => state.setView);
  const [confirmClear, setConfirmClear] = useState(false);
  const [discordTestBusy, setDiscordTestBusy] = useState(false);
  const [discordTestResult, setDiscordTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  return (
    <div className="h-full overflow-auto">
      <div className="mx-auto flex max-w-2xl flex-col gap-6 p-4 pb-8">
        <div>
          <h2 className="font-display text-2xl font-semibold tracking-tight">Settings</h2>
          <p className="mt-2 text-base leading-relaxed text-muted">
            Manage your library source, connected devices, playback features, and appearance. Local files stay on this device; server files stream from your paired Sonicly server.
          </p>
        </div>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Active media library</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted">Choose which files Sonicly shows in Music, Videos, Gallery, and Library. Local files and your dedicated server stay separate; switching sources never moves or deletes files.</p>
          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            <button type="button" aria-pressed={settings.librarySource === "local"} onClick={() => updateSettings({ librarySource: "local" })} className={`min-h-16 rounded-lg border px-4 py-3 text-left transition-colors ${settings.librarySource === "local" ? "border-accent bg-accent/10" : "border-line bg-bg hover:bg-raised"}`}>
              <span className="block font-semibold">Local files</span><span className="mt-1 block text-xs text-muted">Folders and files on this computer</span>
            </button>
            <button type="button" aria-pressed={settings.librarySource === "server"} onClick={() => updateSettings({ librarySource: "server" })} className={`min-h-16 rounded-lg border px-4 py-3 text-left transition-colors ${settings.librarySource === "server" ? "border-accent bg-accent/10" : "border-line bg-bg hover:bg-raised"}`}>
              <span className="block font-semibold">Server files</span><span className="mt-1 block text-xs text-muted">Music, videos and photos hosted remotely</span>
            </button>
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-bg px-3 py-2">
            <p className="text-sm text-muted">{remoteConnected ? `Server connected · ${remoteItems.length.toLocaleString()} files available` : "No dedicated server connected yet"}{settings.librarySource === "server" && !remoteConnected ? " · Connect one in the Server section." : ""}</p>
            {!remoteConnected ? <Button type="button" variant="ghost" onClick={() => setView("server")}>Open Server connection</Button> : null}
          </div>
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4">
          <h3 className="border-b border-line py-3 font-display font-semibold">Library sections</h3>
          <Toggle label="Videos" detail="Show the video browser." checked={settings.videosEnabled} onChange={(videosEnabled) => updateSettings({ videosEnabled })} />
          <Toggle label="Music" detail="Show the music browser." checked={settings.musicEnabled} onChange={(musicEnabled) => updateSettings({ musicEnabled })} />
          <Toggle label="Gallery" detail="Show pictures." checked={settings.galleryEnabled} onChange={(galleryEnabled) => updateSettings({ galleryEnabled })} />
          <Toggle
            label="Video view counts"
            detail="Count a view once each time you start a video in this browser."
            checked={settings.viewCountsEnabled}
            onChange={(viewCountsEnabled) => updateSettings({ viewCountsEnabled })}
          />
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Sonicly mobile connection</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Connect an Android Sonicly app to this computer to browse and stream music from your desktop library. Keep both devices on the same Wi-Fi network.
          </p>
          {desktop() ? (() => {
            const connection = desktop()!.mobileConnectionInfo();
            const primaryUrl = connection.baseUrls[0] || `http://YOUR-PC-IP:${connection.port || 47831}`;
            return (
              <div className="mt-3 space-y-3">
                <div className="rounded-lg bg-bg p-3">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted">Server status</p>
                  <p className="mt-1 font-medium">{connection.running ? `Running on port ${connection.port}` : "Starting / unavailable"}</p>
                  <p className="mt-2 text-xs text-muted">Server address</p>
                  {connection.baseUrls.length ? connection.baseUrls.map((url) => <p key={url} className="break-all font-mono text-sm">{url}</p>) : <p className="font-mono text-sm">{primaryUrl}</p>}
                  <p className="mt-2 text-xs text-muted">Paired devices</p>
                  {connection.pairedDevices.length ? connection.pairedDevices.map((device) => (
                    <div key={device.deviceId} className="mt-2 flex items-center justify-between gap-3 rounded-md border border-line p-2">
                      <div className="min-w-0"><p className="truncate text-sm font-medium">{device.name}</p><p className="text-xs text-muted">Paired {new Date(device.pairedAt).toLocaleString()}</p></div>
                      <Button type="button" variant="ghost" onClick={() => void desktop()!.unpairMobileDevice(device.deviceId).then(() => window.location.reload())}>Unpair</Button>
                    </div>
                  )) : <p className="mt-1 text-sm text-muted">No devices paired yet. Start pairing from the Android app.</p>}
                </div>
                <p className="text-xs leading-relaxed text-muted">
                  Pair from the Android app. Sonicly will show a temporary 4-digit code here in a desktop popup. Each device receives its own permanent credential, which can be revoked above. The server is available while Sonicly is running; allow it through the Windows firewall on Private networks.
                </p>
              </div>
            );
          })() : <p className="mt-3 text-sm text-muted">The mobile streaming server is available in the installed desktop app.</p>}
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Discord Rich Presence</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Show the song you are playing on your Discord profile. Discord for desktop must be running, and this feature works in the installed Electron app.
          </p>
          <div className="mt-3">
            <Toggle
              label="Show listening status on Discord"
              detail="Automatically update your status when music starts, pauses, or changes."
              checked={settings.discordPresenceEnabled}
              onChange={(discordPresenceEnabled) => updateSettings({ discordPresenceEnabled })}
            />
          </div>
          <label className="mt-3 block text-sm font-medium" htmlFor="discord-client-id">Discord Application ID</label>
          <input
            id="discord-client-id"
            type="text"
            inputMode="numeric"
            autoComplete="off"
            spellCheck={false}
            value={settings.discordClientId}
            onChange={(event) => updateSettings({ discordClientId: event.target.value.replace(/\D/g, "").slice(0, 25) })}
            placeholder="Paste your Discord Application ID"
            disabled={!settings.discordPresenceEnabled}
            className="mt-2 min-h-11 w-full rounded-lg border border-line bg-bg px-3 text-sm text-fg outline-none focus:border-accent disabled:opacity-50"
          />
          <p className="mt-2 text-xs leading-relaxed text-muted">
            Create an application in the Discord Developer Portal, copy its Application ID from General Information, and paste it here. You do not need a bot token. Add an image asset named <span className="font-mono">app_icon</span> under Rich Presence → Art Assets if you want a large image beside the status.
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={discordTestBusy || !settings.discordClientId.trim()}
              onClick={async () => {
                const api = desktop();
                if (!api) {
                  setDiscordTestResult({ ok: false, message: "Discord Rich Presence only works in the installed Windows desktop app." });
                  return;
                }
                setDiscordTestBusy(true);
                setDiscordTestResult(null);
                try {
                  const result = await api.testDiscordConnection(settings.discordClientId.trim());
                  setDiscordTestResult({ ok: result.ok, message: result.message || result.error || (result.ok ? "Connected to Discord." : "Connection failed.") });
                } catch (error) {
                  setDiscordTestResult({ ok: false, message: error instanceof Error ? error.message : "The Discord test failed." });
                } finally {
                  setDiscordTestBusy(false);
                }
              }}
              className="min-h-10 rounded-lg bg-accent px-4 text-sm font-semibold text-bg disabled:cursor-not-allowed disabled:opacity-50"
            >
              {discordTestBusy ? "Testing connection…" : "Test Discord Connection"}
            </button>
            {discordTestResult ? (
              <p role="status" className={`text-sm ${discordTestResult.ok ? "text-emerald-400" : "text-red-400"}`}>
                {discordTestResult.message}
              </p>
            ) : null}
          </div>
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Background</h3>
          <p className="mt-1 text-sm text-muted">A picture behind the player. The interface stays readable on top of it.</p>
          {backgroundUrl ? <img src={backgroundUrl} alt="" className="mt-3 h-28 w-full rounded-lg object-cover" /> : null}
          <div className="mt-3 flex flex-wrap gap-2">
            <label className="inline-flex min-h-11 cursor-pointer items-center rounded-lg bg-accent px-3 text-sm font-semibold text-bg">
              Choose image
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void setBackground(file);
                  event.target.value = "";
                }}
              />
            </label>
            {backgroundUrl ? (
              <Button variant="ghost" onClick={() => void setBackground(null)}>
                Remove background
              </Button>
            ) : null}
          </div>
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Linked folders</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            Choose folder saves that folder on this PC. Close Sonicly and open it again, and the same folders come back. Removing a folder here does not delete it from your drive.
          </p>
          <ul className="mt-3 flex flex-col gap-2">
            {folders.map((folder) => (
              <li key={folder.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-bg px-3 py-2">
                <div className="min-w-0">
                  <p className="truncate font-medium">{folder.name}</p>
                  <p className="text-sm text-muted">{folder.needsPermission ? "Needs permission" : "Ready"}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {folder.needsPermission ? (
                    <Button onClick={() => void reconnect(folder.id)}>Reconnect</Button>
                  ) : (
                    <Button variant="ghost" onClick={() => void rescan(folder.id)}>
                      Rescan
                    </Button>
                  )}
                  <Button variant="danger" onClick={() => void removeFolder(folder.id)}>
                    Forget
                  </Button>
                </div>
              </li>
            ))}
            {!folders.length ? <li className="text-sm text-muted">No folders linked yet. Use Choose folder in the library.</li> : null}
          </ul>
        </section>

        <section className="rounded-xl border border-line bg-surface/80 px-4 py-4">
          <h3 className="font-display font-semibold">Clear library</h3>
          <p className="mt-1 text-sm text-muted">Clears the local library list, covers, and background from this app. It does not delete files on your computer or anything stored on the dedicated server.</p>
          <div className="mt-3">
            {confirmClear ? (
              <div className="flex flex-wrap gap-2">
                <Button
                  variant="danger"
                  onClick={() => {
                    void clearLibrary();
                    setConfirmClear(false);
                  }}
                >
                  Clear everything
                </Button>
                <Button variant="ghost" onClick={() => setConfirmClear(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <Button variant="ghost" onClick={() => setConfirmClear(true)}>
                Clear library
              </Button>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

function Toggle({
  label,
  detail,
  checked,
  onChange,
}: {
  label: string;
  detail: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-line py-3 last:border-b-0">
      <div>
        <p className="font-medium">{label}</p>
        <p className="text-sm text-muted">{detail}</p>
      </div>
      <Switch.Root
        checked={checked}
        onCheckedChange={onChange}
        aria-label={label}
        className="relative h-8 w-14 shrink-0 rounded-full bg-line data-[state=checked]:bg-accent"
      >
        <Switch.Thumb className="block size-6 translate-x-1 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-7" />
      </Switch.Root>
    </div>
  );
}
