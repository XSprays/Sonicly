import { useSyncExternalStore, useState } from "react";
import { Pause, Play, Repeat, Repeat1, Shuffle, SkipBack, SkipForward, Volume2, VolumeX, Mic2, Maximize2 } from "lucide-react";
import { IconButton } from "@/components/bits";
import { getClock, subscribeClock } from "@/player/clock";
import { formatTime } from "@/player/format";
import { selectActiveItems, usePlayer } from "@/player/store";
import { metaOf } from "@/player/types";

function useClock() {
  return useSyncExternalStore(subscribeClock, getClock, getClock);
}

export function Transport() {
  const currentId = usePlayer((state) => state.currentId);
  const items = usePlayer(selectActiveItems);
  const overrides = usePlayer((state) => state.overrides);
  const playing = usePlayer((state) => state.playing);
  const settings = usePlayer((state) => state.settings);
  const error = usePlayer((state) => state.error);
  const toggle = usePlayer((state) => state.toggle);
  const next = usePlayer((state) => state.next);
  const prev = usePlayer((state) => state.prev);
  const seek = usePlayer((state) => state.seek);
  const updateSettings = usePlayer((state) => state.updateSettings);
  const cycleRepeat = usePlayer((state) => state.cycleRepeat);
  const item = items.find((candidate) => candidate.id === currentId) ?? null;
  const meta = item ? metaOf(item, overrides) : null;
  const clock = useClock();
  const [drag, setDrag] = useState<number | null>(null);
  const [heldVolume, setHeldVolume] = useState(0.8);
  const fraction = drag ?? (clock.duration > 0 ? clock.time / clock.duration : 0);
  const repeatLabel = settings.repeat === "one" ? "Repeat one" : settings.repeat === "all" ? "Repeat all" : "Repeat off";


  function toggleMute() {
    if (settings.volume > 0) {
      setHeldVolume(settings.volume);
      updateSettings({ volume: 0 });
    } else {
      updateSettings({ volume: heldVolume || 0.8 });
    }
  }

  return (
    <>
    <footer className="border-t border-line bg-surface/95 px-3 py-2 backdrop-blur md:px-4">
      {error ? <p className="mb-1 text-sm text-danger">{error}</p> : null}
      <div className="flex items-center gap-2 md:gap-4">
        <div className="hidden min-w-0 sm:block sm:w-56">
          <p className="truncate font-medium">{meta?.title ?? "Nothing playing"}</p>
          <p className="truncate text-sm text-muted">
            {item?.kind === "audio" ? meta?.artist : item?.kind === "video" ? item.folderLabel : "Add a folder or some files"}
          </p>
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-1">
          <div className="flex items-center justify-center gap-1">
            <IconButton
              aria-label={settings.shuffle ? "Shuffle on" : "Shuffle off"}
              aria-pressed={settings.shuffle}
              active={settings.shuffle}
              disabled={!item}
              onClick={() => updateSettings({ shuffle: !settings.shuffle })}
            >
              <Shuffle className="size-4" />
            </IconButton>
            <IconButton aria-label="Previous" disabled={!item} onClick={() => prev()}>
              <SkipBack className="size-5" />
            </IconButton>
            <IconButton
              aria-label={playing ? "Pause" : "Play"}
              disabled={!item}
              onClick={() => toggle()}
              className="bg-accent text-bg hover:bg-accent/90"
            >
              {playing ? <Pause className="size-5" /> : <Play className="size-5" />}
            </IconButton>
            <IconButton aria-label="Next" disabled={!item} onClick={() => next(false)}>
              <SkipForward className="size-5" />
            </IconButton>
            {item?.kind === "audio" && playing ? (
              <>
                <IconButton
                  aria-label="Toggle lyrics panel"
                  title="Toggle lyrics panel"
                  onClick={() => window.dispatchEvent(new CustomEvent("sonicly:toggle-audio-lyrics"))}
                >
                  <Mic2 className="size-4" />
                </IconButton>
                <IconButton
                  aria-label="Fullscreen lyrics"
                  title="Fullscreen lyrics"
                  onClick={() => window.dispatchEvent(new CustomEvent("sonicly:fullscreen-audio-lyrics"))}
                >
                  <Maximize2 className="size-4" />
                </IconButton>
              </>
            ) : null}
            <IconButton aria-label={repeatLabel} aria-pressed={settings.repeat !== "off"} active={settings.repeat !== "off"} disabled={!item} onClick={() => cycleRepeat()}>
              {settings.repeat === "one" ? <Repeat1 className="size-4" /> : <Repeat className="size-4" />}
            </IconButton>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-12 text-right text-xs tabular-nums text-muted">{formatTime(drag != null ? drag * clock.duration : clock.time)}</span>
            <input
              aria-label="Seek"
              type="range"
              min={0}
              max={1000}
              step={1}
              disabled={!item || clock.duration <= 0}
              value={Math.round(fraction * 1000)}
              onChange={(event) => setDrag(Number(event.target.value) / 1000)}
              onPointerUp={() => {
                if (drag != null) seek(drag);
                setDrag(null);
              }}
              onKeyUp={() => {
                if (drag != null) seek(drag);
                setDrag(null);
              }}
              onBlur={() => setDrag(null)}
              className="min-h-11 min-w-0 flex-1 accent-accent"
            />
            <span className="w-12 text-xs tabular-nums text-muted">{formatTime(clock.duration)}</span>
          </div>
        </div>
        <div className="hidden items-center gap-2 md:flex md:w-40">
          <IconButton aria-label={settings.volume === 0 ? "Unmute" : "Mute"} onClick={toggleMute}>
            {settings.volume === 0 ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
          </IconButton>
          <input
            aria-label="Volume"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={settings.volume}
            onChange={(event) => updateSettings({ volume: Number(event.target.value) })}
            className="min-h-11 min-w-0 flex-1 accent-accent"
          />
        </div>
      </div>
    </footer>
    </>
  );
}
