import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Captions, Minimize2, X } from "lucide-react";
import { getClock, subscribeClock } from "@/player/clock";

type LyricLine = { time: number; text: string };
type LyricsPayload = {
  plainLyrics?: string | null;
  syncedLyrics?: string | null;
  instrumental?: boolean;
  trackName?: string;
  artistName?: string;
};

type LyricsState =
  | { status: "loading" }
  | { status: "found"; data: LyricsPayload }
  | { status: "empty" }
  | { status: "error"; message: string };

const lyricsCache = new Map<string, Promise<LyricsPayload | null>>();
const CLIENT_HEADERS = {
  Accept: "application/json",
  "Lrclib-Client": "Sonicly/1.0 (https://xspraysyt.com/)",
};

function parseLrc(value: string): LyricLine[] {
  const rows: LyricLine[] = [];
  const pattern = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
  for (const row of value.split(/\r?\n/)) {
    const stamps = [...row.matchAll(pattern)];
    if (!stamps.length) continue;
    const text = row.replace(pattern, "").trim();
    for (const stamp of stamps) {
      const fraction = stamp[3] ? Number(`0.${stamp[3]}`) : 0;
      rows.push({
        time: Number(stamp[1]) * 60 + Number(stamp[2]) + fraction,
        text,
      });
    }
  }
  return rows.sort((a, b) => a.time - b.time);
}

function normalize(value: string) {
  return value.toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
}

async function requestLyrics(
  title: string,
  artist: string,
  album: string,
  duration: number,
): Promise<LyricsPayload | null> {
  const key = [title, artist, album, String(Math.round(duration))].map(normalize).join("|");
  const cached = lyricsCache.get(key);
  if (cached) return cached;

  const request = (async () => {
    let response: Response | null = null;
    if (artist && duration > 0 && duration < 3600) {
      const exact = new URLSearchParams({ track_name: title, artist_name: artist });
      if (album) exact.set("album_name", album);
      exact.set("duration", String(Math.round(duration)));
      response = await fetch(`https://lrclib.net/api/get?${exact}`, { headers: CLIENT_HEADERS });
      if (response.status === 429) {
        const retry = response.headers.get("Retry-After");
        throw new Error(retry ? `Lyrics service rate limit. Try again in ${retry} seconds.` : "Lyrics service rate limit. Try again shortly.");
      }
      if (response.ok) {
        const result = (await response.json()) as LyricsPayload;
        if (result.syncedLyrics || result.plainLyrics || result.instrumental) return result;
      }
    }

    const search = new URLSearchParams({ q: `${title} ${artist}`.trim() });
    response = await fetch(`https://lrclib.net/api/search?${search}`, { headers: CLIENT_HEADERS });
    if (response.status === 429) {
      const retry = response.headers.get("Retry-After");
      throw new Error(retry ? `Lyrics service rate limit. Try again in ${retry} seconds.` : "Lyrics service rate limit. Try again shortly.");
    }
    if (!response.ok) return null;

    const results = (await response.json()) as LyricsPayload[];
    const wantedTitle = normalize(title);
    const wantedArtist = normalize(artist);
    const matched = results.find((candidate) => {
      const titleMatches = normalize(candidate.trackName ?? "") === wantedTitle;
      const candidateArtist = normalize(candidate.artistName ?? "");
      const artistMatches = !wantedArtist || candidateArtist === wantedArtist ||
        candidateArtist.includes(wantedArtist) || wantedArtist.includes(candidateArtist);
      return titleMatches && artistMatches;
    });
    return matched ?? null;
  })();

  lyricsCache.set(key, request);
  try {
    return await request;
  } catch (error) {
    lyricsCache.delete(key);
    throw error;
  }
}

function usePlaybackClock() {
  return useSyncExternalStore(subscribeClock, getClock, getClock);
}

export function VideoLyricsOverlay({
  title,
  artist,
  album,
  duration,
  isFullscreen = false,
  className = "",
}: {
  title: string;
  artist: string;
  album: string;
  duration: number;
  isFullscreen?: boolean;
  className?: string;
}) {
  const clock = usePlaybackClock();
  const position = clock.time;
  const [lyrics, setLyrics] = useState<LyricsState>({ status: "loading" });
  const [overlayEnabled, setOverlayEnabled] = useState(false);
  const [fullscreenLyrics, setFullscreenLyrics] = useState(false);
  const activeLineRef = useRef<HTMLParagraphElement | null>(null);
  const overlayRootRef = useRef<HTMLDivElement | null>(null);
  const enteredFullscreenForLyrics = useRef(false);

  const closeFullscreenLyrics = useCallback(() => {
    setFullscreenLyrics(false);
    const shell = overlayRootRef.current?.closest(".sonicly-video-shell") as HTMLElement | null;
    if (enteredFullscreenForLyrics.current && shell && document.fullscreenElement === shell) {
      void document.exitFullscreen();
    }
    enteredFullscreenForLyrics.current = false;
  }, []);

  const openFullscreenLyrics = useCallback(() => {
    const shell = overlayRootRef.current?.closest(".sonicly-video-shell") as HTMLElement | null;
    if (shell && document.fullscreenElement !== shell && typeof shell.requestFullscreen === "function") {
      enteredFullscreenForLyrics.current = true;
      void shell.requestFullscreen().then(
        () => setFullscreenLyrics(true),
        () => {
          enteredFullscreenForLyrics.current = false;
          setFullscreenLyrics(true);
        },
      );
    } else {
      enteredFullscreenForLyrics.current = false;
      setFullscreenLyrics(true);
    }
  }, []);

  useEffect(() => {
    if (!fullscreenLyrics) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        closeFullscreenLyrics();
      }
    };
    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  }, [fullscreenLyrics, closeFullscreenLyrics]);

  useEffect(() => {
    const toggleOverlay = () => {
      setOverlayEnabled((value) => !value);
    };
    const openFullscreen = () => {
      openFullscreenLyrics();
    };
    window.addEventListener("sonicly:toggle-video-lyrics", toggleOverlay);
    window.addEventListener("sonicly:fullscreen-video-lyrics", openFullscreen);
    return () => {
      window.removeEventListener("sonicly:toggle-video-lyrics", toggleOverlay);
      window.removeEventListener("sonicly:fullscreen-video-lyrics", openFullscreen);
    };
  }, [openFullscreenLyrics]);

  useEffect(() => {
    let cancelled = false;
    setLyrics({ status: "loading" });
    setOverlayEnabled(false);
    setFullscreenLyrics(false);

    if (!title.trim() || duration <= 0) {
      setLyrics({ status: "loading" });
      return () => { cancelled = true; };
    }

    void requestLyrics(title.trim(), artist.trim(), album.trim(), duration).then(
      (data) => {
        if (cancelled) return;
        if (!data || data.instrumental || (!data.syncedLyrics && !data.plainLyrics)) {
          setLyrics({ status: "empty" });
          return;
        }
        setLyrics({ status: "found", data });
        const synced = data.syncedLyrics ? parseLrc(data.syncedLyrics) : [];
        // Start the overlay automatically only when genuinely timed lines exist.
        setOverlayEnabled(synced.length > 0);
      },
      (error: unknown) => {
        if (!cancelled) setLyrics({ status: "error", message: error instanceof Error ? error.message : "Lyrics service unavailable." });
      },
    );

    return () => { cancelled = true; };
  }, [title, artist, album, duration]);

  const data = lyrics.status === "found" ? lyrics.data : null;
  const timedLines = useMemo(() => data?.syncedLyrics ? parseLrc(data.syncedLyrics) : [], [data]);
  const activeIndex = timedLines.reduce((found, line, index) => line.time <= position ? index : found, -1);
  const currentIndex = activeIndex < 0 ? 0 : activeIndex;
  const current = timedLines[currentIndex];
  const previous = timedLines[currentIndex - 1];
  const next = timedLines[currentIndex + 1];

  useEffect(() => {
    if (fullscreenLyrics && activeLineRef.current) {
      activeLineRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [fullscreenLyrics, activeIndex]);

  const synced = timedLines.length > 0;

  return (
    <div ref={overlayRootRef} className={`pointer-events-none absolute inset-0 z-20 ${className}`}>
      {(lyrics.status === "loading" || lyrics.status === "error" || lyrics.status === "empty") && (
        <div className="pointer-events-none absolute left-3 top-3 max-w-[55%] rounded-lg bg-black/60 px-3 py-2 text-xs text-white/85 backdrop-blur">
          {lyrics.status === "loading" ? "Finding lyrics…" : lyrics.status === "error" ? lyrics.message : "Lyrics unavailable for this video"}
        </div>
      )}

      {overlayEnabled && synced && (
        <div className={`pointer-events-none absolute inset-x-3 ${isFullscreen ? "bottom-[18%]" : "bottom-[8%]"} flex flex-col items-center gap-1 rounded-2xl border border-white/10 bg-black/70 px-4 py-3 text-center shadow-xl backdrop-blur-sm sm:inset-x-8 sm:px-7 sm:py-4`}>
          {previous && <p className="max-w-full truncate text-xs font-medium text-white/55 sm:text-sm">{previous.text || "♪"}</p>}
          {current && (
            <p className="max-w-full text-base font-bold leading-snug text-transparent bg-clip-text bg-gradient-to-r from-sky-300 via-blue-300 to-violet-400 sm:text-xl md:text-2xl">
              {current.text || "♪"}
            </p>
          )}
          {next && <p className="max-w-full truncate text-xs font-medium text-white/65 sm:text-sm">{next.text || "♪"}</p>}
        </div>
      )}

      {overlayEnabled && !synced && data?.plainLyrics && (
        <div className={`pointer-events-none absolute inset-x-3 ${isFullscreen ? "bottom-[18%]" : "bottom-[8%]"} rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-center text-xs text-white/90 backdrop-blur sm:inset-x-8 sm:text-sm`}>
          Plain lyrics available · Open fullscreen to read
        </div>
      )}

      {fullscreenLyrics && (
        <div className="pointer-events-auto absolute inset-0 z-30 flex flex-col bg-gradient-to-br from-[#080d1a]/[.98] via-[#111b35]/[.98] to-[#321d50]/[.98] p-4 text-white sm:p-7" role="dialog" aria-modal="true" aria-label="Fullscreen lyrics">
          <header className="flex items-center gap-3 border-b border-white/15 pb-4">
            <Captions className="size-6 text-sky-300" />
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-lg font-semibold sm:text-xl">Sonicly Lyrics</h2>
              <p className="truncate text-xs text-white/65 sm:text-sm">{title} · {artist}</p>
            </div>
            <button type="button" onClick={closeFullscreenLyrics} className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-white/20 bg-white/10 px-3 text-sm font-semibold hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent">
              <Minimize2 className="size-4" /> Back to video
            </button>
            <button type="button" aria-label="Close lyrics" onClick={closeFullscreenLyrics} className="inline-flex size-10 items-center justify-center rounded-lg hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"><X className="size-5"/></button>
          </header>

          {lyrics.status === "loading" ? (
            <div className="flex flex-1 items-center justify-center text-sm text-white/70">Finding lyrics…</div>
          ) : synced ? (
            <div className="min-h-0 flex-1 overflow-y-auto py-6 text-center">
              <div className="mx-auto flex max-w-4xl flex-col gap-5">
                {timedLines.map((line, index) => (
                  <p
                    key={`${line.time}-${index}`}
                    ref={index === currentIndex ? activeLineRef : undefined}
                    className={`text-lg font-semibold leading-relaxed transition-colors sm:text-2xl md:text-3xl ${
                      index === activeIndex
                        ? "bg-gradient-to-r from-sky-300 via-blue-300 to-violet-400 bg-clip-text text-transparent"
                        : index < activeIndex ? "text-white/35" : "text-white/75"
                    }`}
                  >
                    {line.text || "♪"}
                  </p>
                ))}
              </div>
            </div>
          ) : data?.plainLyrics ? (
            <div className="min-h-0 flex-1 overflow-y-auto px-2 py-6 text-center text-base leading-8 text-white sm:text-xl sm:leading-10">
              <p className="mx-auto max-w-3xl whitespace-pre-wrap">{data.plainLyrics}</p>
            </div>
          ) : (
            <div className="flex flex-1 items-center justify-center text-sm text-white/70">
              {lyrics.status === "error" ? lyrics.message : "Lyrics are unavailable for this video."}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
