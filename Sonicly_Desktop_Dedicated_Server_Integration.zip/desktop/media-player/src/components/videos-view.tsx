import { Clapperboard, ImagePlus, Maximize, Pause, Play, RectangleHorizontal } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { AddMedia } from "@/components/add-media";
import { Artwork, Button, EmptyState, IconButton, SearchField, coverUrl } from "@/components/bits";
import { publishClock } from "@/player/clock";
import { captureFrame } from "@/player/files";
import { formatBytes } from "@/player/format";
import { media } from "@/player/media";
import { selectActiveItems, usePlayer, videoPool } from "@/player/store";
import { metaOf } from "@/player/types";
import { cn } from "@/lib/utils";
import { VideoLyricsOverlay } from "@/components/video-lyrics-overlay";

export function VideosView() {
  const videoContainerRef = useRef<HTMLDivElement | null>(null);
  const [videoFullscreen, setVideoFullscreen] = useState(false);
  const [videoMetadata, setVideoMetadata] = useState<{ mediaId: string; duration: number } | null>(null);
  const items = usePlayer(selectActiveItems);
  const overrides = usePlayer((state) => state.overrides);
  const artUrls = usePlayer((state) => state.artUrls);
  const videoFolder = usePlayer((state) => state.videoFolder);
  const videoQuery = usePlayer((state) => state.videoQuery);
  const currentId = usePlayer((state) => state.currentId);
  const playing = usePlayer((state) => state.playing);
  const theatre = usePlayer((state) => state.theatre);
  const viewCounts = usePlayer((state) => state.viewCounts);
  const countsOn = usePlayer((state) => state.settings.viewCountsEnabled);
  const librarySource = usePlayer((state) => state.settings.librarySource);
  const booted = usePlayer((state) => state.booted);
  const play = usePlayer((state) => state.play);
  const toggle = usePlayer((state) => state.toggle);
  const setVideoFolder = usePlayer((state) => state.setVideoFolder);
  const setVideoQuery = usePlayer((state) => state.setVideoQuery);
  const setTheatre = usePlayer((state) => state.setTheatre);
  const setCover = usePlayer((state) => state.setCover);
  const fail = usePlayer((state) => state.fail);
  const notePause = usePlayer((state) => state.notePause);
  const notePlay = usePlayer((state) => state.notePlay);
  const markView = usePlayer((state) => state.markView);
  const next = usePlayer((state) => state.next);

  useEffect(() => {
    const onFullscreenChange = () => {
      setVideoFullscreen(document.fullscreenElement === videoContainerRef.current);
    };
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  const videos = items.filter((item) => item.kind === "video");
  const folders = useMemo(() => {
    const map = new Map<string, string>();
    for (const item of videos) map.set(item.folderKey, item.folderLabel);
    return [...map.entries()].sort((a, b) => a[1].localeCompare(b[1], undefined, { sensitivity: "base" }));
  }, [videos]);
  const visible = videoPool({ items, overrides, videoFolder, videoQuery });
  const current = items.find((item) => item.id === currentId && item.kind === "video") ?? null;
  const meta = current ? metaOf(current, overrides) : null;

  async function saveFrame() {
    if (!media.video || !current || media.video.videoWidth === 0) return;
    const file = await captureFrame(media.video);
    await setCover(current.id, file);
  }

  if (!booted) {
    return <EmptyState icon={<Clapperboard className="size-7" />} title="Opening library" body="Checking this browser for folders you linked earlier." />;
  }

  if (!videos.length) {
    return (
      <EmptyState
        icon={<Clapperboard className="size-7" />}
        title="Your videos"
        body={
          items.some((item) => item.kind !== "video")
            ? "No videos in the library yet. Music and pictures are in their own sections."
            : librarySource === "server" ? "No videos are available in the connected server library. Add videos to the server’s videos folder, then refresh it from the Server page." : "Nothing here yet. Choose a folder or add files from this device. They stay on your computer — nothing is uploaded."
        }
      >
        {librarySource === "local" ? <AddMedia /> : null}
      </EmptyState>
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col lg:flex-row">
      <section className="flex min-w-0 flex-col gap-3 p-4 lg:flex-1 lg:overflow-auto">
        <div ref={videoContainerRef} className="sonicly-video-shell relative overflow-hidden rounded-xl bg-bg">
          <video
            ref={(node) => {
              media.video = node;
            }}
            className="block aspect-video w-full bg-bg"
            playsInline
            controls={videoFullscreen}
            onClick={() => current && toggle()}
            onTimeUpdate={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              publishClock(event.currentTarget.currentTime, event.currentTarget.duration || 0);
            }}
            onLoadedMetadata={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              setVideoMetadata({
                mediaId: currentId,
                duration: Number.isFinite(event.currentTarget.duration) ? event.currentTarget.duration : 0,
              });
              publishClock(event.currentTarget.currentTime, event.currentTarget.duration || 0);
            }}
            onPlay={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              notePlay();
              if (current) markView(current.id);
            }}
            onPause={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              notePause();
            }}
            onEnded={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              next(true);
            }}
            onError={(event) => {
              if (event.currentTarget.dataset.mediaId !== currentId) return;
              fail("This browser can't decode that video. MP4 and WebM usually work. MKV and AVI usually don't.");
            }}
          />
          {current && meta ? (
            <VideoLyricsOverlay
              title={meta.title}
              artist={meta.artist}
              album={meta.album}
              duration={videoMetadata?.mediaId === currentId ? videoMetadata.duration : 0}
              isFullscreen={videoFullscreen}
            />
          ) : null}
        </div>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="font-display text-2xl font-semibold tracking-tight">{meta?.title ?? "Choose a video"}</h2>
            <p className="mt-1 text-sm text-muted">
              {current ? `${current.folderLabel} · ${formatBytes(current.size)}` : "Pick something from the list"}
              {current && countsOn ? ` · ${viewCounts[current.id] ?? 0} views` : ""}
            </p>
          </div>
          <div className="flex items-center gap-1">
            <IconButton aria-label={playing && current ? "Pause" : "Play"} disabled={!current} onClick={() => (current ? toggle() : undefined)}>
              {playing && current ? <Pause className="size-5" /> : <Play className="size-5" />}
            </IconButton>
            <IconButton aria-label={theatre ? "Exit theatre" : "Theatre mode"} disabled={!current} active={theatre} onClick={() => setTheatre(!theatre)}>
              <RectangleHorizontal className="size-5" />
            </IconButton>
            <IconButton
              aria-label="Fullscreen"
              disabled={!current}
              onClick={() => {
                const shell = videoContainerRef.current;
                if (!shell) return;
                if (document.fullscreenElement === shell) void document.exitFullscreen();
                else void shell.requestFullscreen();
              }}
            >
              <Maximize className="size-5" />
            </IconButton>
            {librarySource === "local" ? <IconButton aria-label="Use this frame as thumbnail" disabled={!current} onClick={() => void saveFrame()}><ImagePlus className="size-5" /></IconButton> : null}
          </div>
        </div>
      </section>
      <aside className={cn("flex min-h-0 flex-1 flex-col border-t border-line lg:w-80 lg:flex-none lg:border-l lg:border-t-0", theatre && "hidden")}>
        <div className="flex flex-col gap-3 p-3">
          <SearchField value={videoQuery} onChange={setVideoQuery} placeholder="Search videos" label="Search videos" />
          <div className="flex gap-2 overflow-x-auto">
            <FolderChip active={videoFolder === "all"} onClick={() => setVideoFolder("all")} label={`All ${videos.length}`} />
            {folders.map(([key, label]) => (
              <FolderChip key={key} active={videoFolder === key} onClick={() => setVideoFolder(key)} label={label} />
            ))}
          </div>
        </div>
        <ul className="min-h-0 flex-1 overflow-auto px-2 pb-3">
          {visible.map((item) => {
            const info = metaOf(item, overrides);
            const active = item.id === currentId;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => play(item.id)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left",
                    active ? "bg-accent text-bg" : "hover:bg-raised",
                  )}
                >
                  <Artwork src={coverUrl(item, artUrls)} className="h-12 w-20 shrink-0 rounded-md" icon={<Clapperboard className="size-4" />} />
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{info.title}</span>
                    <span className={cn("block truncate text-sm", active ? "text-bg/80" : "text-muted")}>{item.folderLabel}</span>
                  </span>
                </button>
              </li>
            );
          })}
          {!visible.length ? <li className="px-2 py-6 text-sm text-muted">No videos match.</li> : null}
        </ul>
      </aside>
    </div>
  );
}

function FolderChip({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "min-h-11 shrink-0 rounded-full px-3 text-sm font-medium",
        active ? "bg-accent text-bg" : "bg-raised text-fg",
      )}
    >
      {label}
    </button>
  );
}
