import { useCallback, useEffect, useMemo, useRef, useState, type MouseEvent } from "react";
import { Activity, LoaderCircle } from "lucide-react";
import { coverUrl } from "@/components/bits";
import { media } from "@/player/media";
import { selectActiveItems, usePlayer } from "@/player/store";
import { metaOf } from "@/player/types";
import "@/components/visualizer.css";

type ThemeRect = { x: number; y: number; w: number; h: number };
type VisualizerState = {
  dt: number;
  w: number;
  h: number;
  flowLevel: number;
  flowBass: number;
  flowTreble: number;
  beatEnergy: number;
  m: number;
  crazy: number;
  flowT: number;
  cloudPhase: number;
  logoPulse: number;
  splash: number;
  splashParticles: unknown[];
  logoImg: HTMLImageElement;
  logoReady: boolean;
  coverImg: HTMLImageElement;
  coverReady: boolean;
  coverOut: HTMLImageElement | null;
  coverOutReady: boolean;
  seedSplash: (x: number, y: number, power: number) => void;
};
type VeylaraTheme = {
  id: string;
  name: string;
  update?: (state: VisualizerState) => void;
  draw?: (ctx: CanvasRenderingContext2D, width: number, height: number, state: VisualizerState) => void;
  onTrackChange?: (key?: string) => void;
  onPosition?: (position: number) => void;
  onSeek?: (direction: number, seeking: boolean) => void;
  setPlaying?: (playing: boolean) => void;
  setArtMode?: (mode: string) => void;
  getArtMode?: () => string;
  hitTest?: (x: number, y: number) => unknown;
  _hits?: Record<string, ThemeRect | null>;
};

declare global {
  interface Window {
    PulseVizThemes?: Record<string, VeylaraTheme>;
  }
}

type AudioGraph = {
  element: HTMLAudioElement;
  context: AudioContext;
  source: MediaElementAudioSourceNode;
  analyser: AnalyserNode;
  timeData: Uint8Array;
  frequencyData: Uint8Array;
};

let sharedAudioGraph: AudioGraph | null = null;
let themeScriptPromise: Promise<void> | null = null;

function loadVeylaraThemes(): Promise<void> {
  if (window.PulseVizThemes?.ring && window.PulseVizThemes?.vinyl) return Promise.resolve();
  if (themeScriptPromise) return themeScriptPromise;
  themeScriptPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "/veylara-visualizer/themes.js";
    script.async = true;
    script.onload = () => {
      if (window.PulseVizThemes?.ring && window.PulseVizThemes?.vinyl) resolve();
      else reject(new Error("The Veylara visualizer themes did not register correctly."));
    };
    script.onerror = () => reject(new Error("Couldn't load the visualizer theme pack."));
    document.head.appendChild(script);
  }).catch((error) => {
    themeScriptPromise = null;
    throw error;
  });
  return themeScriptPromise;
}

function getOrCreateAudioGraph(element: HTMLAudioElement): AudioGraph {
  if (sharedAudioGraph?.element === element && sharedAudioGraph.context.state !== "closed") {
    return sharedAudioGraph;
  }

  // This is the existing Sonicly audio element, not a second player. Keep the
  // MediaElementAudioSourceNode alive across view changes so it is never created twice.
  if (sharedAudioGraph && sharedAudioGraph.context.state !== "closed") {
    throw new Error("Sonicly's audio visualizer is already connected to a different player element. Restart Sonicly to reset the audio graph.");
  }

  const context = new AudioContext();
  const source = context.createMediaElementSource(element);
  const analyser = context.createAnalyser();
  analyser.fftSize = 1024;
  analyser.smoothingTimeConstant = 0.92;
  analyser.minDecibels = -90;
  analyser.maxDecibels = -20;
  source.connect(analyser);
  // Keep the original music audible: the existing element now routes through
  // the analyser and back to the normal output device.
  analyser.connect(context.destination);

  sharedAudioGraph = {
    element,
    context,
    source,
    analyser,
    timeData: new Uint8Array(analyser.fftSize),
    frequencyData: new Uint8Array(analyser.frequencyBinCount),
  };
  return sharedAudioGraph;
}

function readSavedNumber(key: string, fallback: number, min: number, max: number) {
  try {
    const value = Number(localStorage.getItem(key));
    return Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
  } catch {
    return fallback;
  }
}

function readSavedTheme() {
  if (typeof window === "undefined") return "ring";
  try {
    const saved = localStorage.getItem("pulse-viz-theme");
    return saved && themeChoices.some((choice) => choice.id === saved) ? saved : "ring";
  } catch {
    return "ring";
  }
}

function readSavedArtMode() {
  if (typeof window === "undefined") return "full";
  try {
    const saved = localStorage.getItem("pulse-vinyl-art");
    return saved === "center" ? "center" : "full";
  } catch {
    return "full";
  }
}

function makeImage() {
  return new Image();
}

type VisualizerImages = {
  logoImg: HTMLImageElement;
  logoReady: boolean;
  coverA: HTMLImageElement;
  coverB: HTMLImageElement;
  coverImg: HTMLImageElement;
  coverOut: HTMLImageElement | null;
  coverReady: boolean;
  coverOutReady: boolean;
  coverSrc: string;
};

function rmsFromTimeDomain(data: Uint8Array) {
  let sum = 0;
  for (let index = 0; index < data.length; index += 1) {
    const sample = (data[index] - 128) / 128;
    sum += sample * sample;
  }
  return Math.sqrt(sum / data.length);
}

const themeChoices = [
  { id: "ring", name: "Ring" },
  { id: "blobs", name: "Blobs" },
  { id: "solar", name: "Solar" },
  { id: "vinyl", name: "Vinyl" },
  { id: "ducks", name: "Ducks" },
  { id: "cat", name: "Cat" },
];

export function VisualizerView() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imagesRef = useRef<VisualizerImages | null>(null);
  const previousTrackRef = useRef("");
  const currentId = usePlayer((state) => state.currentId);
  const items = usePlayer(selectActiveItems);
  const overrides = usePlayer((state) => state.overrides);
  const artUrls = usePlayer((state) => state.artUrls);
  const playing = usePlayer((state) => state.playing);
  const settings = usePlayer((state) => state.settings);
  const updateSettings = usePlayer((state) => state.updateSettings);

  const item = items.find((candidate) => candidate.id === currentId && candidate.kind === "audio") ?? null;
  const meta = item ? metaOf(item, overrides) : null;
  const artwork = item ? coverUrl(item, artUrls) : null;
  const trackKey = item && meta ? `${item.id}|${meta.title}|${meta.artist}` : "";

  const [themesReady, setThemesReady] = useState(false);
  const [themeError, setThemeError] = useState("");
  const [themeId, setThemeId] = useState(readSavedTheme);
  const [sensitivity, setSensitivity] = useState(() => typeof window === "undefined" ? 1 : readSavedNumber("pulse-viz-sensitivity", 1, 0.4, 3));
  const [artMode, setArtMode] = useState(readSavedArtMode);
  const [visualizing, setVisualizing] = useState(() => typeof window !== "undefined" && sharedAudioGraph?.context.state === "running");
  const [audioError, setAudioError] = useState("");

  if (!imagesRef.current && typeof window !== "undefined") {
    const logoImg = makeImage();
    imagesRef.current = {
      logoImg,
      logoReady: false,
      coverA: makeImage(),
      coverB: makeImage(),
      coverImg: makeImage(),
      coverOut: null,
      coverReady: false,
      coverOutReady: false,
      coverSrc: "",
    };
    logoImg.onload = () => {
      if (imagesRef.current) imagesRef.current.logoReady = true;
    };
    logoImg.src = "/sonicly-icon.png";
  }

  useEffect(() => {
    void loadVeylaraThemes().then(() => setThemesReady(true)).catch((error: unknown) => {
      setThemeError(error instanceof Error ? error.message : "Couldn't load visualizer themes.");
    });
  }, []);

  useEffect(() => {
    if (!imagesRef.current) return;
    const images = imagesRef.current;
    if (!artwork) {
      images.coverReady = false;
      images.coverOutReady = false;
      images.coverSrc = "";
      images.coverOut = images.coverImg;
      images.coverImg.removeAttribute("src");
      return;
    }
    if (artwork === images.coverSrc) return;
    if (images.coverReady && images.coverImg.naturalWidth) {
      images.coverOut = images.coverImg;
      images.coverOutReady = true;
      images.coverImg = images.coverImg === images.coverA ? images.coverB : images.coverA;
    } else {
      images.coverOut = images.coverOut || images.coverImg;
      images.coverOutReady = Boolean(images.coverOut?.naturalWidth);
    }
    images.coverSrc = artwork;
    images.coverReady = false;
    const target = images.coverImg;
    target.onload = () => {
      if (images.coverImg === target) images.coverReady = Boolean(target.naturalWidth && target.naturalHeight);
    };
    target.onerror = () => {
      if (images.coverImg === target) images.coverReady = false;
    };
    target.src = artwork;
  }, [artwork]);

  useEffect(() => {
    try {
      localStorage.setItem("pulse-viz-theme", themeId);
      localStorage.setItem("pulse-viz-sensitivity", String(sensitivity));
      localStorage.setItem("pulse-vinyl-art", artMode);
      // Vinyl's theme polls this legacy preference while drawing its deck UI.
      localStorage.setItem("pulse-vol", String(Math.round(settings.volume * 100)));
    } catch {
      /* Preferences remain session-local if storage is unavailable. */
    }
    const vinyl = window.PulseVizThemes?.vinyl;
    if (vinyl?.setArtMode) vinyl.setArtMode(artMode);
  }, [themeId, sensitivity, artMode, settings.volume]);

  useEffect(() => {
    if (!themesReady || !trackKey) return;
    if (previousTrackRef.current !== trackKey) {
      window.PulseVizThemes?.cat?.onTrackChange?.();
      window.PulseVizThemes?.vinyl?.onTrackChange?.(trackKey);
      previousTrackRef.current = trackKey;
    }
  }, [themesReady, trackKey]);

  useEffect(() => {
    if (!themesReady) return;
    window.PulseVizThemes?.vinyl?.setPlaying?.(playing && Boolean(item));
  }, [themesReady, playing, item?.id]);

  const activateVisualizer = useCallback(async () => {
    setAudioError("");
    const audioElement = media.audio;
    if (!audioElement) {
      setAudioError("Sonicly's audio player isn't ready yet. Open your music library and start a song first.");
      return;
    }
    try {
      const graph = getOrCreateAudioGraph(audioElement);
      if (graph.context.state !== "running") await graph.context.resume();
      setVisualizing(true);
    } catch (error) {
      setAudioError(error instanceof Error ? error.message : "Sonicly couldn't connect the audio analyser.");
      setVisualizing(false);
    }
  }, []);

  const onCanvasClick = useCallback((event: MouseEvent<HTMLCanvasElement>) => {
    if (themeId !== "vinyl") return;
    const theme = window.PulseVizThemes?.vinyl;
    if (!theme?.hitTest) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    theme.hitTest(x, y);
  }, [themeId]);

  const onCanvasMove = useCallback((event: MouseEvent<HTMLCanvasElement>) => {
    const canvas = event.currentTarget;
    if (themeId !== "vinyl") {
      canvas.style.cursor = "default";
      return;
    }
    const hits = window.PulseVizThemes?.vinyl?._hits;
    if (!hits) {
      canvas.style.cursor = "default";
      return;
    }
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    const inside = (hit?: ThemeRect | null) => Boolean(hit && x >= hit.x && x <= hit.x + hit.w && y >= hit.y && y <= hit.y + hit.h);
    canvas.style.cursor = Object.values(hits).some(inside) ? "pointer" : "default";
  }, [themeId]);

  useEffect(() => {
    const onTransport = (event: Event) => {
      const command = (event as CustomEvent<{ cmd?: string }>).detail?.cmd;
      const state = usePlayer.getState();
      if (command === "prev") state.prev();
      else if (command === "next") state.next(false);
      else if (command === "toggle") state.toggle();
    };
    const onVolume = (event: Event) => {
      const value = (event as CustomEvent<{ value?: number }>).detail?.value;
      if (typeof value === "number" && Number.isFinite(value)) {
        updateSettings({ volume: Math.max(0, Math.min(1, value)) });
      }
    };
    window.addEventListener("sonicly:visualizer-transport", onTransport);
    window.addEventListener("sonicly:visualizer-volume", onVolume);
    return () => {
      window.removeEventListener("sonicly:visualizer-transport", onTransport);
      window.removeEventListener("sonicly:visualizer-volume", onVolume);
    };
  }, [updateSettings]);

  useEffect(() => {
    if (!themesReady) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    let width = 0;
    let height = 0;
    let dpr = 1;
    let frame = 0;
    let lastFrame = performance.now();
    let flowT = 0;
    let flowLevel = 0;
    let flowBass = 0;
    let flowTreble = 0;
    let circleMorph = 0;
    let crazy = 0;
    let logoPulse = 1;
    let cloudPhase = 0;
    let splash = 0;
    let splashParticles: unknown[] = [];

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const resizeObserver = typeof ResizeObserver !== "undefined" ? new ResizeObserver(resize) : null;
    resizeObserver?.observe(canvas);
    window.addEventListener("resize", resize);

    const seedSplash = (cx: number, cy: number, power: number) => {
      const count = 28 + Math.floor(power * 24);
      splashParticles = [];
      for (let index = 0; index < count; index += 1) {
        const angle = (index / count) * Math.PI * 2 + Math.random() * 0.2;
        const speed = 40 + Math.random() * 120 * power;
        splashParticles.push({
          x: cx,
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 20 * Math.random(),
          life: 1,
          decay: 0.35 + Math.random() * 0.45,
          r: 3 + Math.random() * 8 * power,
          wobble: Math.random() * Math.PI * 2,
        });
      }
    };

    const draw = (now: number) => {
      const dt = Math.min(0.05, Math.max(0.001, (now - lastFrame) / 1000));
      lastFrame = now;
      ctx.fillStyle = "#030712";
      ctx.fillRect(0, 0, width, height);

      let targetLevel = 0;
      let targetBass = 0;
      let targetTreble = 0;
      const graph = sharedAudioGraph;
      const audioActive = Boolean(
        visualizing && item && playing && graph && graph.element === media.audio &&
        !graph.element.paused && graph.context.state === "running" &&
        graph.element.dataset.mediaId === item.id
      );
      if (audioActive && graph) {
        graph.analyser.getByteTimeDomainData(graph.timeData);
        graph.analyser.getByteFrequencyData(graph.frequencyData);
        const level = rmsFromTimeDomain(graph.timeData);
        const frequencyCount = graph.frequencyData.length;
        const bassEnd = Math.max(1, Math.floor(frequencyCount * 0.12));
        const trebleStart = Math.floor(frequencyCount * 0.45);
        let bassSum = 0;
        let trebleSum = 0;
        for (let index = 0; index < bassEnd; index += 1) bassSum += graph.frequencyData[index];
        for (let index = trebleStart; index < frequencyCount; index += 1) trebleSum += graph.frequencyData[index];
        targetLevel = Math.min(1.5, level * sensitivity);
        targetBass = Math.min(1.5, ((bassSum / (bassEnd * 255)) || 0) * sensitivity);
        targetTreble = Math.min(1.3, ((trebleSum / (Math.max(1, frequencyCount - trebleStart) * 255)) || 0) * sensitivity);
      }
      flowLevel += (targetLevel - flowLevel) * (audioActive ? 0.12 : 0.035);
      flowBass += (targetBass - flowBass) * (audioActive ? 0.14 : 0.04);
      flowTreble += (targetTreble - flowTreble) * (audioActive ? 0.1 : 0.035);

      const beatEnergy = flowLevel * 0.5 + flowBass * 0.9;
      const targetMorph = beatEnergy > 0.15 ? Math.min(1, (beatEnergy - 0.06) / 0.28) : 0;
      circleMorph += (targetMorph - circleMorph) * 0.07;
      const targetCrazy = Math.max(0, (beatEnergy - 0.2) / 0.4);
      crazy += (targetCrazy - crazy) * 0.08;

      const images = imagesRef.current;
      if (images) {
        const state: VisualizerState = {
          dt,
          w: width,
          h: height,
          flowLevel,
          flowBass,
          flowTreble,
          beatEnergy,
          m: circleMorph,
          crazy,
          flowT,
          cloudPhase,
          logoPulse,
          splash,
          splashParticles,
          logoImg: images.logoImg,
          logoReady: images.logoReady,
          coverImg: images.coverImg,
          coverReady: images.coverReady,
          coverOut: images.coverOut,
          coverOutReady: images.coverOutReady,
          seedSplash,
        };
        const theme = window.PulseVizThemes?.[themeId] ?? window.PulseVizThemes?.ring;
        try {
          theme?.update?.(state);
          theme?.draw?.(ctx, width, height, state);
        } catch (error) {
          console.error("Sonicly visualizer theme error:", error);
        }
        flowT = state.flowT;
        cloudPhase = state.cloudPhase;
        logoPulse = state.logoPulse;
        splash = state.splash;
        splashParticles = state.splashParticles;
      }

      if (themeId === "vinyl" && item && graph) {
        window.PulseVizThemes?.vinyl?.onPosition?.(graph.element.currentTime);
        window.PulseVizThemes?.vinyl?.setPlaying?.(playing && !graph.element.paused);
      }
      frame = requestAnimationFrame(draw);
    };

    frame = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(frame);
      resizeObserver?.disconnect();
      window.removeEventListener("resize", resize);
    };
  }, [themesReady, visualizing, themeId, sensitivity, item?.id, playing]);

  const statusText = useMemo(() => {
    if (!visualizing) return "Visualizer ready";
    if (!item) return "Choose a song to visualize";
    if (playing) return "Visualizing Sonicly audio";
    return "Waiting for playback";
  }, [visualizing, item, playing]);

  return (
    <div className="sonicly-visualizer" aria-label="Sonicly audio visualizer">
      <canvas
        ref={canvasRef}
        className="sonicly-visualizer__canvas"
        aria-label={`${themeChoices.find((choice) => choice.id === themeId)?.name ?? "Audio"} visualizer canvas`}
        onClick={onCanvasClick}
        onMouseMove={onCanvasMove}
      />

      <div className="sonicly-visualizer__top">
        <div className="sonicly-visualizer__brand">
          <span className={`sonicly-visualizer__dot ${visualizing && playing ? "is-on" : ""}`} />
          Sonicly Visualizer
        </div>
        <div className="sonicly-visualizer__controls">
          <label className="sonicly-visualizer__theme" title="Visualizer theme">
            <span>Theme</span>
            <select value={themeId} onChange={(event) => setThemeId(event.target.value)} disabled={!themesReady} aria-label="Visualizer theme">
              {themeChoices.map((choice) => <option key={choice.id} value={choice.id}>{choice.name}</option>)}
            </select>
          </label>
          {themeId === "vinyl" ? (
            <label className="sonicly-visualizer__theme" title="Vinyl cover art style">
              <span>Art</span>
              <select value={artMode} onChange={(event) => setArtMode(event.target.value)} aria-label="Vinyl art mode">
                <option value="full">Full disc</option>
                <option value="center">Centered</option>
              </select>
            </label>
          ) : null}
          <label className="sonicly-visualizer__sensitivity" title="Visualizer sensitivity">
            <span>Sensitivity</span>
            <input type="range" min="0.4" max="3" step="0.05" value={sensitivity} onChange={(event) => setSensitivity(Number(event.target.value))} aria-label="Visualizer sensitivity" />
            <output>{sensitivity.toFixed(1)}×</output>
          </label>
          <button type="button" className="sonicly-visualizer__action" onClick={() => void activateVisualizer()} disabled={!themesReady}>
            {themesReady ? <Activity size={14} /> : <LoaderCircle size={14} className="animate-spin" />}
            {visualizing ? "Reconnect audio" : "Enable audio"}
          </button>
        </div>
      </div>

      <div className="sonicly-visualizer__hud">
        {artwork ? <img className="sonicly-visualizer__art" src={artwork} alt="" /> : <div className="sonicly-visualizer__art flex items-center justify-center"><Activity size={24} /></div>}
        <div className="sonicly-visualizer__meta">
          <div className="sonicly-visualizer__label">{statusText}</div>
          <div className="sonicly-visualizer__title">{meta?.title ?? "Nothing playing"}</div>
          <div className="sonicly-visualizer__artist">{meta?.artist || "Start music in Sonicly to bring the themes to life"}</div>
        </div>
      </div>

      {!visualizing ? (
        <div className="sonicly-visualizer__gate">
          <div className="sonicly-visualizer__gate-card">
            <h2>Bring your music to life</h2>
            <p>Connect the visualizer to Sonicly's current music player. It analyzes the audio already playing in Sonicly—no microphone, screen sharing or separate playback engine.</p>
            <button type="button" onClick={() => void activateVisualizer()} disabled={!themesReady}>Enable Sonicly audio</button>
            {audioError ? <div className="sonicly-visualizer__error">{audioError}</div> : null}
            {themeError ? <div className="sonicly-visualizer__error">{themeError}</div> : null}
          </div>
        </div>
      ) : null}
      {visualizing && audioError ? <div className="sonicly-visualizer__gate"><div className="sonicly-visualizer__gate-card"><p>{audioError}</p><button type="button" onClick={() => void activateVisualizer()}>Try again</button></div></div> : null}
    </div>
  );
}
