export type Clock = { time: number; duration: number };

let clock: Clock = { time: 0, duration: 0 };
const listeners = new Set<() => void>();

export function getClock() {
  return clock;
}

export function publishClock(time: number, duration: number) {
  const t = Number.isFinite(time) ? Math.floor(time * 4) / 4 : 0;
  const d = Number.isFinite(duration) ? duration : 0;
  if (clock.time === t && clock.duration === d) return;
  clock = { time: t, duration: d };
  listeners.forEach((listener) => listener());
}

export function subscribeClock(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
