export type DesktopFolder = { id: string; name: string; path: string };
export type DesktopFile = { relPath: string; size: number; modifiedAt?: number };

export type DiscordPresence = {
  enabled: boolean;
  clientId: string;
  title?: string;
  artist?: string;
  album?: string;
  playing: boolean;
  position: number;
  duration: number;
};

export type MobilePairedDevice = { deviceId: string; name: string; platform: string; pairedAt: number; lastSeenAt: number };
export type RemoteServerConnection = { baseUrl: string; token: string; deviceId?: string; hostId?: string };
export type MobileConnectionInfo = { running: boolean; port: number | null; hostId: string; pairedDevices: MobilePairedDevice[]; addresses: string[]; baseUrls: string[] };

export type DesktopApi = {
  pickFolder: () => Promise<string | null>;
  listSaved: () => Promise<DesktopFolder[]>;
  remember: (folderPath: string) => Promise<DesktopFolder>;
  forget: (id: string) => Promise<void>;
  clear: () => Promise<void>;
  scan: (folderPath: string) => Promise<DesktopFile[]>;
  getPathForFile: (file: File) => string;
  registerMobileFiles: (paths: string[]) => Promise<{ registered: number }>;
  mediaToken: () => string;
  mobileConnectionInfo: () => MobileConnectionInfo;
  unpairMobileDevice: (deviceId: string) => Promise<{ ok: boolean }>;
  setDiscordPresence: (presence: DiscordPresence) => Promise<{ ok: boolean; state?: string; message?: string; error?: string }>;
  testDiscordConnection: (clientId: string) => Promise<{ ok: boolean; state?: string; message?: string; error?: string }>;
  getDiscordStatus: () => Promise<{ state: string; message: string }>;
  getRemoteServer: () => Promise<RemoteServerConnection | null>;
  saveRemoteServer: (connection: RemoteServerConnection) => Promise<{ ok: boolean }>;
  clearRemoteServer: () => Promise<{ ok: boolean }>;
};

export function desktop(): DesktopApi | null {
  if (typeof window === "undefined") return null;
  const api = (window as Window & { desktop?: DesktopApi }).desktop;
  return api ?? null;
}

export function mediaUrl(absPath: string) {
  const token = desktop()?.mediaToken();
  return `/local-media?p=${encodeURIComponent(absPath)}&t=${encodeURIComponent(token || "")}`;
}

export function joinFolder(root: string, relPath: string) {
  const sep = root.includes("\\") ? "\\" : "/";
  return `${root.replace(/[\\/]+$/, "")}${sep}${relPath.replace(/[\\/]/g, sep)}`;
}
