import { mergeTags, parseId3Tag, parseId3v1, type Id3Tags } from "@/player/id3";
import { baseName, extOf } from "@/player/format";
import type { MediaItem, MediaKind } from "@/player/types";

const AUDIO = new Set(["mp3", "wav", "ogg", "oga", "opus", "m4a", "aac", "flac", "weba"]);
const VIDEO = new Set(["mp4", "m4v", "webm", "mkv", "avi", "mov", "mpeg", "mpg", "ogv"]);
const IMAGE = new Set(["jpg", "jpeg", "png", "webp", "gif", "bmp", "avif"]);
const FILE_CAP = 8000;

export type Incoming = {
  file: File;
  relPath: string;
  rootId: string;
  rootName: string;
};

const fileBin = new Map<string, File>();
const urlBin = new Map<string, string>();
const pathUrlBin = new Map<string, string>();
const pathTagCache = new Map<string, Id3Tags>();

export function rememberFile(id: string, file: File) {
  const prev = fileBin.get(id);
  if (prev && prev !== file) {
    const url = urlBin.get(id);
    if (url) {
      URL.revokeObjectURL(url);
      urlBin.delete(id);
    }
  }
  fileBin.set(id, file);
}

export function forgetFile(id: string) {
  fileBin.delete(id);
  pathUrlBin.delete(id);
  const url = urlBin.get(id);
  if (url) {
    URL.revokeObjectURL(url);
    urlBin.delete(id);
  }
}

export function rememberUrl(id: string, url: string) {
  pathUrlBin.set(id, url);
}

export function urlFor(id: string) {
  const direct = pathUrlBin.get(id);
  if (direct) return direct;
  const existing = urlBin.get(id);
  if (existing) return existing;
  const file = fileBin.get(id);
  if (!file) return null;
  const url = URL.createObjectURL(file);
  urlBin.set(id, url);
  return url;
}

export function hasFile(id: string) {
  return fileBin.has(id);
}

export function classify(file: File, relPath: string): MediaKind | null {
  const ext = extOf(relPath);
  const mime = (file.type || "").toLowerCase();
  if (mime.startsWith("audio/") || AUDIO.has(ext)) return "audio";
  if (mime.startsWith("video/") || VIDEO.has(ext)) return "video";
  if (mime.startsWith("image/") || IMAGE.has(ext)) return "image";
  return null;
}

export function classifyPath(relPath: string): MediaKind | null {
  const ext = extOf(relPath);
  if (AUDIO.has(ext)) return "audio";
  if (VIDEO.has(ext)) return "video";
  if (IMAGE.has(ext)) return "image";
  return null;
}

export async function buildPathItems(
  files: Array<{ relPath: string; size: number; modifiedAt?: number }>,
  rootId: string,
  rootName: string,
  toUrl: (relPath: string) => string,
) {
  const usable = files.filter((file) => file.size > 0 && !skipPath(file.relPath) && classifyPath(file.relPath));
  const capped = usable.slice(0, FILE_CAP);
  const items = new Array<MediaItem | undefined>(capped.length);
  let cursor = 0;
  const worker = async () => {
    while (true) {
      const index = cursor++;
      if (index >= capped.length) return;
      const entry = capped[index];
      const relPath = entry.relPath.replace(/\\/g, "/").replace(/^\/+/, "");
      const kind = classifyPath(relPath);
      if (!kind) continue;
      const name = relPath.split("/").pop() || relPath;
      const ext = extOf(name);
      const id = `${rootId}:${relPath}`;
      const pathMeta = fromPath(relPath);
      const url = toUrl(relPath);
      rememberUrl(id, url);
      let title = pathMeta.title;
      let artist = pathMeta.artist;
      let album = pathMeta.album;
      let embeddedArtUrl: string | undefined;
      if (kind === "audio" && ext === "mp3") {
        try {
          const cacheKey = `${id}:${entry.size}:${entry.modifiedAt ?? 0}`;
          let tags = pathTagCache.get(cacheKey);
          if (tags) {
            pathTagCache.delete(cacheKey);
            pathTagCache.set(cacheKey, tags);
          } else {
            tags = await readRemoteMp3Tags(url, entry.size);
            // Keep the cache bounded so a large music library cannot retain unbounded cover bytes.
            if (!tags.picture || tags.picture.byteLength <= 512 * 1024) {
              pathTagCache.set(cacheKey, tags);
              if (pathTagCache.size > 500) {
                const oldestKey = pathTagCache.keys().next().value;
                if (oldestKey) pathTagCache.delete(oldestKey);
              }
            }
          }
          title = tags.title || title;
          artist = tags.artist || artist;
          album = tags.album || album;
          if (tags.picture?.length) {
            const picture = new Uint8Array(tags.picture.byteLength);
            picture.set(tags.picture);
            embeddedArtUrl = URL.createObjectURL(new Blob([picture.buffer as ArrayBuffer], { type: tags.pictureType || "image/jpeg" }));
          }
        } catch {
          // Metadata is optional; retain filename-derived values if a file cannot be read.
        }
      }
      items[index] = {
        id,
        kind,
        rootId,
        rootName,
        relPath,
        name,
        ext,
        size: entry.size,
        mime: "",
        title,
        artist: kind === "audio" ? artist : "",
        album: kind === "audio" ? album : "",
        embeddedArtUrl,
        ...folderOf(rootId, rootName, relPath),
      };
    }
  };
  await Promise.all(Array.from({ length: Math.min(6, capped.length) }, () => worker()));
  return { items: linkSiblings(items.filter((item): item is MediaItem => Boolean(item))), truncated: usable.length > FILE_CAP };
}

async function readRemoteMp3Tags(url: string, size: number) {
  const headResponse = await fetch(url, { headers: { Range: "bytes=0-2000009" } });
  if (!headResponse.ok && headResponse.status !== 206) throw new Error("Unable to read MP3 metadata");
  const head = new Uint8Array(await headResponse.arrayBuffer());
  let tags = parseId3Tag(head);
  if (!(tags.title && tags.artist && tags.album && tags.picture) && size >= 128) {
    const tailResponse = await fetch(url, { headers: { Range: `bytes=${Math.max(0, size - 128)}-${size - 1}` } });
    if (tailResponse.ok || tailResponse.status === 206) {
      const tail = new Uint8Array(await tailResponse.arrayBuffer());
      tags = mergeTags(tags, parseId3v1(tail));
    }
  }
  return tags;
}

export function skipPath(relPath: string) {
  const lower = relPath.toLowerCase();
  if (lower.includes("__macosx/")) return true;
  return relPath.split("/").some((part) => part.startsWith(".") || part === "Thumbs.db");
}

function folderOf(rootId: string, rootName: string, relPath: string) {
  const parts = relPath.split("/").filter(Boolean);
  parts.pop();
  const relDir = parts.join("/");
  return {
    folderKey: `${rootId}/${relDir}`,
    folderLabel: relDir ? `${rootName} / ${relDir}` : rootName,
  };
}

function fromPath(relPath: string) {
  const parts = relPath.split("/").filter(Boolean);
  const filename = parts.pop() ?? relPath;
  const title = baseName(filename);
  let artist = "Unknown";
  let album = "Unknown";
  if (parts.length >= 2) {
    artist = parts[0];
    album = parts.slice(1).join(" / ");
  } else if (parts.length === 1) {
    album = parts[0];
  }
  return { title, artist, album };
}

export function linkSiblings(items: MediaItem[]) {
  const images = new Map<string, string>();
  const folderCovers = new Map<string, string>();
  const preferredCoverNames = new Set(["cover", "folder", "front", "album", "artwork"]);
  for (const item of items) {
    if (item.kind !== "image") continue;
    const stem = baseName(item.name).toLowerCase();
    images.set(`${item.folderKey}/${stem}`, item.id);
    if (!folderCovers.has(item.folderKey) && preferredCoverNames.has(stem)) {
      folderCovers.set(item.folderKey, item.id);
    }
  }
  return items.map((item) => {
    if (item.kind === "image") return { ...item, siblingArtId: undefined };
    const exactSibling = images.get(`${item.folderKey}/${baseName(item.name).toLowerCase()}`);
    const sibling = exactSibling || folderCovers.get(item.folderKey);
    return sibling ? { ...item, siblingArtId: sibling } : { ...item, siblingArtId: undefined };
  });
}

export function mergeItems(prev: MediaItem[], incoming: MediaItem[]) {
  const incomingIds = new Set(incoming.map((item) => item.id));
  const kept: MediaItem[] = [];
  for (const item of prev) {
    if (!incomingIds.has(item.id)) {
      kept.push(item);
      continue;
    }
    const next = incoming.find((candidate) => candidate.id === item.id);
    if (item.embeddedArtUrl && item.embeddedArtUrl !== next?.embeddedArtUrl) {
      URL.revokeObjectURL(item.embeddedArtUrl);
    }
  }
  return linkSiblings([...kept, ...incoming]);
}

export async function buildItems(
  incoming: Incoming[],
  onProgress?: (done: number, total: number) => void,
) {
  const usable = incoming.filter((item) => item.file.size > 0 && !skipPath(item.relPath) && classify(item.file, item.relPath));
  const capped = usable.slice(0, FILE_CAP);
  const items: MediaItem[] = [];
  for (let index = 0; index < capped.length; index += 1) {
    const entry = capped[index];
    const kind = classify(entry.file, entry.relPath);
    if (!kind) continue;
    const relPath = entry.relPath.replace(/\\/g, "/").replace(/^\/+/, "");
    const name = relPath.split("/").pop() || entry.file.name;
    const ext = extOf(name);
    const id =
      entry.rootId === "session"
        ? `session:${relPath}:${entry.file.size}:${entry.file.lastModified}`
        : `${entry.rootId}:${relPath}`;
    const pathMeta = fromPath(relPath);
    let title = pathMeta.title;
    let artist = pathMeta.artist;
    let album = pathMeta.album;
    let embeddedArtUrl: string | undefined;
    if (kind === "audio" && (ext === "mp3" || (entry.file.type || "").includes("mpeg"))) {
      try {
        const tags = await readMp3Tags(entry.file);
        if (tags.title) title = tags.title;
        if (tags.artist) artist = tags.artist;
        if (tags.album) album = tags.album;
        if (tags.picture) {
          const bytes = new Uint8Array(tags.picture.byteLength);
          bytes.set(tags.picture);
          embeddedArtUrl = URL.createObjectURL(new Blob([bytes.buffer as ArrayBuffer], { type: tags.pictureType || "image/jpeg" }));
        }
      } catch {
        /* filename metadata still works */
      }
    }
    rememberFile(id, entry.file);
    const folders = folderOf(entry.rootId, entry.rootName, relPath);
    items.push({
      id,
      kind,
      rootId: entry.rootId,
      rootName: entry.rootName,
      relPath,
      name,
      ext,
      size: entry.file.size,
      mime: entry.file.type || "",
      title,
      artist: kind === "audio" ? artist : "",
      album: kind === "audio" ? album : "",
      embeddedArtUrl,
      ...folders,
    });
    if (index > 0 && index % 20 === 0) {
      onProgress?.(index, capped.length);
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
  }
  onProgress?.(capped.length, capped.length);
  return { items, truncated: usable.length > FILE_CAP };
}

type DirWithEntries = FileSystemDirectoryHandle & {
  entries?: () => AsyncIterable<[string, FileSystemHandle]>;
  values?: () => AsyncIterable<FileSystemHandle>;
};

export async function collectHandle(dir: FileSystemDirectoryHandle, rootId: string, rootName: string) {
  const incoming: Incoming[] = [];
  async function walk(handle: FileSystemDirectoryHandle, prefix: string) {
    const directory = handle as DirWithEntries;
    const iterator = directory.entries?.() ?? directory.values?.();
    if (!iterator) return;
    for await (const entry of iterator) {
      const child = (Array.isArray(entry) ? entry[1] : entry) as FileSystemHandle;
      const name = child.name;
      if (!name || name.startsWith(".")) continue;
      const relPath = prefix ? `${prefix}/${name}` : name;
      if (child.kind === "directory") {
        if (name === "node_modules" || name === "__MACOSX") continue;
        await walk(child as FileSystemDirectoryHandle, relPath);
      } else if (child.kind === "file") {
        try {
          const file = await (child as FileSystemFileHandle).getFile();
          incoming.push({ file, relPath, rootId, rootName });
        } catch {
          /* unreadable file */
        }
      }
    }
  }
  await walk(dir, "");
  return incoming;
}

function readEntry(entry: FileSystemEntry): Promise<Array<{ file: File; relPath: string }>> {
  if (entry.isFile) {
    return new Promise((resolve, reject) => {
      (entry as FileSystemFileEntry).file((file) => {
        const relPath = entry.fullPath.replace(/^\/+/, "") || file.name;
        resolve([{ file, relPath }]);
      }, () => reject(new Error("unreadable file")));
    });
  }
  if (!entry.isDirectory) return Promise.resolve([]);
  const reader = (entry as FileSystemDirectoryEntry).createReader();
  return new Promise((resolve, reject) => {
    const batch: FileSystemEntry[] = [];
    const pull = () => {
      reader.readEntries((entries) => {
        if (!entries.length) {
          Promise.all(batch.map((child) => readEntry(child)))
            .then((groups) => resolve(groups.flat()))
            .catch(reject);
          return;
        }
        batch.push(...entries);
        pull();
      }, () => reject(new Error("unreadable folder")));
    };
    pull();
  });
}

export async function readDrop(data: DataTransfer) {
  const handles: FileSystemDirectoryHandle[] = [];
  const loose: Incoming[] = [];
  const items = [...data.items];
  for (const item of items) {
    if (item.kind !== "file") continue;
    const withHandle = item as DataTransferItem & {
      getAsFileSystemHandle?: () => Promise<FileSystemHandle | null>;
    };
    if (withHandle.getAsFileSystemHandle) {
      try {
        const handle = await withHandle.getAsFileSystemHandle();
        if (handle?.kind === "directory") {
          handles.push(handle as FileSystemDirectoryHandle);
          continue;
        }
        if (handle?.kind === "file") {
          const file = await (handle as FileSystemFileHandle).getFile();
          loose.push({ file, relPath: file.name, rootId: "session", rootName: "Added files" });
          continue;
        }
      } catch {
        /* fall through */
      }
    }
    const entry = item.webkitGetAsEntry?.();
    if (entry) {
      try {
        const files = await readEntry(entry);
        for (const file of files) {
          loose.push({ file: file.file, relPath: file.relPath, rootId: "session", rootName: "Added files" });
        }
        continue;
      } catch {
        /* fall through */
      }
    }
    const file = item.getAsFile();
    if (file) loose.push({ file, relPath: file.name, rootId: "session", rootName: "Added files" });
  }
  return { handles, loose };
}

export function looseFromList(files: FileList | File[]) {
  return [...files].map((file) => ({
    file,
    relPath: (file.webkitRelativePath || file.name).replace(/\\/g, "/"),
    rootId: "session",
    rootName: "Added files",
  }));
}

type PermHandle = FileSystemHandle & {
  queryPermission?: (descriptor: { mode: "read" }) => Promise<PermissionState>;
  requestPermission?: (descriptor: { mode: "read" }) => Promise<PermissionState>;
};

export async function permission(handle: FileSystemHandle, request: boolean): Promise<PermissionState> {
  const candidate = handle as PermHandle;
  try {
    if (request && candidate.requestPermission) return await candidate.requestPermission({ mode: "read" });
    if (candidate.queryPermission) return await candidate.queryPermission({ mode: "read" });
  } catch {
    return "denied";
  }
  return "prompt";
}

export function canPickDirectory() {
  return typeof window !== "undefined" && "showDirectoryPicker" in window;
}

export function pickDirectory() {
  const picker = (window as unknown as {
    showDirectoryPicker: (options?: { mode?: "read" }) => Promise<FileSystemDirectoryHandle>;
  }).showDirectoryPicker;
  return picker({ mode: "read" });
}

export async function captureFrame(video: HTMLVideoElement) {
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth || 640;
  canvas.height = video.videoHeight || 360;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not capture a frame");
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.85));
  if (!blob) throw new Error("Could not capture a frame");
  return new File([blob], "frame.jpg", { type: "image/jpeg" });
}
