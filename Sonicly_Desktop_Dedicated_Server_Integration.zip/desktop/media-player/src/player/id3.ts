export type Id3Tags = {
  title?: string;
  artist?: string;
  album?: string;
  picture?: Uint8Array;
  pictureType?: string;
};

function clean(value: string) {
  return value.replace(/\0/g, "").trim();
}

function synchsafe(b0: number, b1: number, b2: number, b3: number) {
  return ((b0 & 0x7f) << 21) | ((b1 & 0x7f) << 14) | ((b2 & 0x7f) << 7) | (b3 & 0x7f);
}

function be32(bytes: Uint8Array, offset: number) {
  return (
    bytes[offset] * 0x1000000 +
    bytes[offset + 1] * 0x10000 +
    bytes[offset + 2] * 0x100 +
    bytes[offset + 3]
  );
}

function decodeText(data: Uint8Array) {
  if (data.length === 0) return "";
  const enc = data[0];
  const body = data.subarray(1);
  try {
    if (enc === 0) return clean(new TextDecoder("latin1").decode(body));
    if (enc === 1) return clean(new TextDecoder("utf-16").decode(body));
    if (enc === 2) return clean(new TextDecoder("utf-16be").decode(body));
    return clean(new TextDecoder("utf-8").decode(body));
  } catch {
    return "";
  }
}

function parseApic(data: Uint8Array): { bytes: Uint8Array; type: string } | null {
  if (data.length < 4) return null;
  const enc = data[0];
  let i = 1;
  let mime = "";
  while (i < data.length && data[i] !== 0) {
    mime += String.fromCharCode(data[i]);
    i += 1;
  }
  i += 1;
  if (i >= data.length) return null;
  i += 1;
  if (enc === 1 || enc === 2) {
    while (i + 1 < data.length && !(data[i] === 0 && data[i + 1] === 0)) i += 1;
    i += 2;
  } else {
    while (i < data.length && data[i] !== 0) i += 1;
    i += 1;
  }
  if (i >= data.length) return null;
  const type = mime === "image/jpg" || mime === "" ? "image/jpeg" : mime;
  return { bytes: data.subarray(i).slice(), type };
}

function assignText(tags: Id3Tags, id: string, data: Uint8Array) {
  const text = decodeText(data);
  if (!text) return;
  if (id === "TIT2" || id === "TT2") tags.title = text;
  if (id === "TPE1" || id === "TP1") tags.artist = text;
  if (id === "TALB" || id === "TAL") tags.album = text;
}

export function parseId3v1(tail: Uint8Array): Id3Tags {
  const tags: Id3Tags = {};
  if (tail.length < 128) return tags;
  const start = tail.length - 128;
  if (tail[start] !== 0x54 || tail[start + 1] !== 0x41 || tail[start + 2] !== 0x47) return tags;
  const latin = (from: number, len: number) =>
    clean(new TextDecoder("latin1").decode(tail.subarray(start + from, start + from + len)));
  const title = latin(3, 30);
  const artist = latin(33, 30);
  const album = latin(63, 30);
  if (title) tags.title = title;
  if (artist) tags.artist = artist;
  if (album) tags.album = album;
  return tags;
}

export function parseId3Tag(raw: Uint8Array): Id3Tags {
  const tags: Id3Tags = {};
  if (raw.length < 10) return tags;
  if (raw[0] !== 0x49 || raw[1] !== 0x44 || raw[2] !== 0x33) return tags;
  const version = raw[3];
  if (version < 2 || version > 4) return tags;
  const flags = raw[5];
  let body = raw.subarray(10);
  if (flags & 0x80) {
    const out: number[] = [];
    for (let i = 0; i < body.length; i += 1) {
      out.push(body[i]);
      if (body[i] === 0xff && body[i + 1] === 0x00) i += 1;
    }
    body = Uint8Array.from(out);
  }
  if (flags & 0x40) {
    if (body.length < 4) return tags;
    const extSize = version >= 4 ? synchsafe(body[0], body[1], body[2], body[3]) : 4 + be32(body, 0);
    if (extSize < 0 || extSize > body.length) return tags;
    body = body.subarray(version >= 4 ? extSize : extSize);
  }

  let offset = 0;
  const headerLen = version === 2 ? 6 : 10;
  while (offset + headerLen <= body.length) {
    if (body[offset] === 0) break;
    let id = "";
    let size = 0;
    let frameFlags = 0;
    if (version === 2) {
      id = String.fromCharCode(body[offset], body[offset + 1], body[offset + 2]);
      size = (body[offset + 3] << 16) | (body[offset + 4] << 8) | body[offset + 5];
    } else {
      id = String.fromCharCode(body[offset], body[offset + 1], body[offset + 2], body[offset + 3]);
      size =
        version === 4
          ? synchsafe(body[offset + 4], body[offset + 5], body[offset + 6], body[offset + 7])
          : be32(body, offset + 4);
      frameFlags = (body[offset + 8] << 8) | body[offset + 9];
    }
    if (!/^[A-Z0-9]+$/.test(id) || size <= 0 || offset + headerLen + size > body.length) break;
    const data = body.subarray(offset + headerLen, offset + headerLen + size);
    offset += headerLen + size;
    if (frameFlags !== 0) continue;
    if (id.startsWith("T")) assignText(tags, id, data);
    if ((id === "APIC" || id === "PIC") && !tags.picture) {
      const pic = id === "PIC" ? parsePicV22(data) : parseApic(data);
      if (pic && pic.bytes.length > 32) {
        tags.picture = pic.bytes;
        tags.pictureType = pic.type;
      }
    }
  }
  return tags;
}

function parsePicV22(data: Uint8Array): { bytes: Uint8Array; type: string } | null {
  if (data.length < 6) return null;
  const format = String.fromCharCode(data[1], data[2], data[3]).toUpperCase();
  let i = 5;
  while (i < data.length && data[i] !== 0) i += 1;
  i += 1;
  if (i >= data.length) return null;
  const type = format === "PNG" ? "image/png" : "image/jpeg";
  return { bytes: data.subarray(i).slice(), type };
}

export function mergeTags(primary: Id3Tags, fallback: Id3Tags): Id3Tags {
  return {
    title: primary.title || fallback.title,
    artist: primary.artist || fallback.artist,
    album: primary.album || fallback.album,
    picture: primary.picture ?? fallback.picture,
    pictureType: primary.pictureType ?? fallback.pictureType,
  };
}

export async function readMp3Tags(file: File): Promise<Id3Tags> {
  const head = new Uint8Array(await file.slice(0, 10).arrayBuffer());
  let v2: Id3Tags = {};
  if (head[0] === 0x49 && head[1] === 0x44 && head[2] === 0x33) {
    const size = synchsafe(head[6], head[7], head[8], head[9]);
    const capped = Math.min(size, 2_000_000);
    const tag = new Uint8Array(await file.slice(0, 10 + capped).arrayBuffer());
    v2 = parseId3Tag(tag);
  }
  if (v2.title && v2.artist && v2.album && v2.picture) return v2;
  if (file.size < 128) return v2;
  const tail = new Uint8Array(await file.slice(file.size - 128).arrayBuffer());
  return mergeTags(v2, parseId3v1(tail));
}
