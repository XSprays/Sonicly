export const media: {
  audio: HTMLAudioElement | null;
  video: HTMLVideoElement | null;
  ignorePause: boolean;
} = {
  audio: null,
  video: null,
  ignorePause: false,
};
