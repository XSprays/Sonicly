import { defaultSettings, type MetaOverride, type Settings } from "@/player/types";

const SETTINGS_KEY = "mp.local.settings";
const OVERRIDES_KEY = "mp.local.overrides";
const COUNTS_KEY = "mp.local.views";
const DB_NAME = "mp-local";
const DB_VERSION = 1;

function canUseStorage() {
  return typeof localStorage !== "undefined";
}

export function loadSettings(): Settings {
  if (!canUseStorage()) return { ...defaultSettings };
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...defaultSettings };
    const parsed = JSON.parse(raw) as Partial<Settings>;
    const volume = typeof parsed.volume === "number" ? Math.min(1, Math.max(0, parsed.volume)) : defaultSettings.volume;
    const repeat = parsed.repeat === "all" || parsed.repeat === "one" || parsed.repeat === "off" ? parsed.repeat : "off";
    return {
      ...defaultSettings,
      ...parsed,
      volume,
      repeat,
      librarySource: parsed.librarySource === "server" ? "server" : "local",
    };
  } catch {
    return { ...defaultSettings };
  }
}

export function saveSettings(settings: Settings) {
  if (!canUseStorage()) return;
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function loadOverrides(): Record<string, MetaOverride> {
  if (!canUseStorage()) return {};
  try {
    const raw = localStorage.getItem(OVERRIDES_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, MetaOverride>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

export function saveOverrides(overrides: Record<string, MetaOverride>) {
  if (!canUseStorage()) return;
  localStorage.setItem(OVERRIDES_KEY, JSON.stringify(overrides));
}

export function loadCounts(): Record<string, number> {
  if (!canUseStorage()) return {};
  try {
    const raw = localStorage.getItem(COUNTS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, number>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

export function saveCounts(counts: Record<string, number>) {
  if (!canUseStorage()) return;
  localStorage.setItem(COUNTS_KEY, JSON.stringify(counts));
}

export function clearLibraryStorage() {
  if (!canUseStorage()) return;
  localStorage.removeItem(OVERRIDES_KEY);
  localStorage.removeItem(COUNTS_KEY);
}

function requestToPromise<T>(request: IDBRequest<T>) {
  return new Promise<T>((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function openDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("indexedDB unavailable"));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("handles")) db.createObjectStore("handles");
      if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export type SavedFolder = {
  id: string;
  name: string;
  handle: FileSystemDirectoryHandle;
};

export async function loadHandles(): Promise<SavedFolder[]> {
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readonly");
    const store = tx.objectStore("handles");
    const keys = await requestToPromise(store.getAllKeys());
    const values = await requestToPromise(store.getAll());
    const folders: SavedFolder[] = [];
    keys.forEach((key, index) => {
      const value = values[index] as { name?: string; handle?: FileSystemDirectoryHandle } | undefined;
      if (!value?.handle || value.handle.kind !== "directory") return;
      folders.push({
        id: String(key),
        name: value.name || value.handle.name || "Folder",
        handle: value.handle,
      });
    });
    return folders;
  } catch {
    return [];
  }
}

export async function saveHandle(id: string, name: string, handle: FileSystemDirectoryHandle) {
  const db = await openDb();
  const tx = db.transaction("handles", "readwrite");
  await requestToPromise(tx.objectStore("handles").put({ name, handle }, id));
}

export async function deleteHandle(id: string) {
  try {
    const db = await openDb();
    const tx = db.transaction("handles", "readwrite");
    await requestToPromise(tx.objectStore("handles").delete(id));
  } catch {
    /* ignore */
  }
}

export async function loadAllBlobs(): Promise<Record<string, Blob>> {
  try {
    const db = await openDb();
    const tx = db.transaction("blobs", "readonly");
    const store = tx.objectStore("blobs");
    const keys = await requestToPromise(store.getAllKeys());
    const values = await requestToPromise(store.getAll());
    const blobs: Record<string, Blob> = {};
    keys.forEach((key, index) => {
      const value = values[index];
      if (value instanceof Blob) blobs[String(key)] = value;
    });
    return blobs;
  } catch {
    return {};
  }
}

export async function saveBlob(key: string, blob: Blob) {
  const db = await openDb();
  const tx = db.transaction("blobs", "readwrite");
  await requestToPromise(tx.objectStore("blobs").put(blob, key));
}

export async function deleteBlob(key: string) {
  try {
    const db = await openDb();
    const tx = db.transaction("blobs", "readwrite");
    await requestToPromise(tx.objectStore("blobs").delete(key));
  } catch {
    /* ignore */
  }
}

export async function clearBlobsAndHandles() {
  try {
    const db = await openDb();
    const tx = db.transaction(["handles", "blobs"], "readwrite");
    await requestToPromise(tx.objectStore("handles").clear());
    await requestToPromise(tx.objectStore("blobs").clear());
  } catch {
    /* ignore */
  }
}
