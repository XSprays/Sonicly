import { desktop } from "@/player/desktop";
import type { MediaItem } from "@/player/types";

export type RemoteServerConnection = {
  baseUrl: string;
  token: string;
  deviceId?: string;
  hostId?: string;
};

export type RemoteMedia = {
  id: string;
  title: string;
  artist?: string;
  album?: string;
  albumArtist?: string;
  trackNumber?: number;
  trackTotal?: number;
  discNumber?: number;
  discTotal?: number;
  year?: number | null;
  genre?: string;
  hasArtwork?: boolean;
  artworkMime?: string;
  fileName: string;
  path: string;
  folder: string;
  size: number;
  modifiedAt: number;
  mime: string;
  mediaType: "audio" | "video" | "photo";
  streamPath: string;
  artworkPath?: string;
};

export type RemoteServerStatus = {
  name: string;
  version: string;
  protocol: number;
  streaming: boolean;
  photos: boolean;
  serverType: string;
  hostId?: string;
};

export type RemoteLibraryResult = {
  status: RemoteServerStatus;
  media: RemoteMedia[];
  items: MediaItem[];
  total: number;
  truncated: boolean;
};

const PAGE_SIZE = 2000;
// The dedicated server defaults to a 50,000-file index. Keep a hard client
// ceiling too, so a misconfigured endpoint cannot grow renderer memory without
// bound. The result reports truncation when this ceiling is reached.
const MAX_REMOTE_ITEMS = 50_000;
const REQUEST_TIMEOUT_MS = 30_000;

function remoteProxyUrl(path: string) {
  // Electron's local media host adds the encrypted device token in the main
  // process. The bearer token is never placed in the media URL.
  return desktop() ? `/remote-media?p=${encodeURIComponent(path)}` : "";
}

function validMediaPath(entry: RemoteMedia) {
  const id = entry.id;
  if (entry.mediaType === "photo") return entry.streamPath === `/api/v1/photo/${id}`;
  return entry.streamPath === `/api/v1/stream/${id}`;
}

function finiteTag(value: unknown) {
  if (value == null || value === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : undefined;
}

export function mapRemoteItems(items: RemoteMedia[]): MediaItem[] {
  return items.flatMap((entry) => {
    if (!entry || typeof entry.id !== "string" || !/^[a-f\d]{24}$/i.test(entry.id)) return [];
    if (!validMediaPath(entry)) return [];
    const kind = entry.mediaType === "audio" ? "audio" : entry.mediaType === "video" ? "video" : entry.mediaType === "photo" ? "image" : null;
    if (!kind) return [];

    const relPath = String(entry.path || entry.fileName || entry.title || "").replace(/\\/g, "/").replace(/^\/+/, "");
    const name = String(entry.fileName || relPath.split("/").pop() || entry.title || "Media file");
    const ext = name.includes(".") ? name.split(".").pop()!.toLowerCase() : "";
    const folderParts = relPath.split("/").filter(Boolean);
    folderParts.pop();
    const folder = folderParts.join(" / ") || String(entry.folder || "Server library");
    const artworkPath = typeof entry.artworkPath === "string" && entry.artworkPath === `/api/v1/artwork/${entry.id}`
      ? entry.artworkPath
      : undefined;

    return [{
      id: `remote:${entry.id}`,
      kind,
      rootId: "remote-server",
      rootName: "Sonicly Server",
      relPath,
      name,
      ext,
      size: Number(entry.size) || 0,
      mime: String(entry.mime || "application/octet-stream"),
      title: String(entry.title || name.replace(/\.[^.]+$/, "")),
      artist: String(entry.artist || "Unknown"),
      album: String(entry.album || folder || "Unknown"),
      albumArtist: entry.albumArtist ? String(entry.albumArtist) : undefined,
      trackNumber: finiteTag(entry.trackNumber),
      trackTotal: finiteTag(entry.trackTotal),
      discNumber: finiteTag(entry.discNumber),
      discTotal: finiteTag(entry.discTotal),
      year: finiteTag(entry.year) ?? null,
      genre: entry.genre ? String(entry.genre) : undefined,
      hasArtwork: Boolean(entry.hasArtwork || artworkPath),
      artworkMime: entry.artworkMime ? String(entry.artworkMime) : undefined,
      folderKey: `remote-server/${folder}`,
      folderLabel: `Server / ${folder}`,
      streamUrl: remoteProxyUrl(entry.streamPath),
      artworkUrl: artworkPath ? remoteProxyUrl(artworkPath) : undefined,
    } satisfies MediaItem];
  });
}

async function requestJson<T>(baseUrl: string, path: string, token: string): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${baseUrl}${path}`, {
      headers: { accept: "application/json", authorization: `Bearer ${token}` },
      cache: "no-store",
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    if (error instanceof Error && error.name === "TimeoutError") {
      throw new Error("The Sonicly server took too long to respond. Check the server load and network connection.");
    }
    throw new Error("Couldn't reach the saved Sonicly server. Check its address, port, firewall, and HTTPS setup.");
  }

  const payload = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) {
    const message = typeof payload.message === "string"
      ? payload.message
      : typeof payload.error === "string"
        ? payload.error.replaceAll("_", " ")
        : `Server returned HTTP ${response.status}.`;
    if (response.status === 401) {
      throw new Error("This desktop is no longer paired with that server. Reconnect and pair it again.");
    }
    throw new Error(message);
  }
  return payload as T;
}

/**
 * Loads the full v1.0.2 unified library, following every offset page. The same
 * function is used by initial app boot and the Server screen so the two paths
 * cannot disagree about metadata, pagination, or protocol validation.
 */
export async function fetchRemoteMedia(connection: RemoteServerConnection): Promise<RemoteLibraryResult> {
  const status = await requestJson<RemoteServerStatus>(connection.baseUrl, "/api/v1/status", connection.token);
  if (status.protocol !== 1 || status.serverType !== "dedicated") {
    throw new Error("This server does not support the Sonicly dedicated-server protocol.");
  }

  const media: RemoteMedia[] = [];
  let offset = 0;
  let total = 0;
  let serverTruncated = false;
  let reachedEnd = false;
  const visitedOffsets = new Set<number>();

  while (media.length < MAX_REMOTE_ITEMS && !reachedEnd) {
    if (visitedOffsets.has(offset)) throw new Error("The server returned an invalid library page sequence.");
    visitedOffsets.add(offset);

    const query = new URLSearchParams({ type: "all", limit: String(PAGE_SIZE), offset: String(offset) });
    const page = await requestJson<{
      items?: RemoteMedia[];
      total?: number;
      nextOffset?: number | null;
      truncated?: boolean;
    }>(connection.baseUrl, `/api/v1/media?${query.toString()}`, connection.token);

    if (!Array.isArray(page.items)) throw new Error("The server returned an invalid media-library response.");
    const pageItems = page.items.filter((item) => item && typeof item.id === "string");
    media.push(...pageItems.slice(0, MAX_REMOTE_ITEMS - media.length));
    if (Number.isFinite(page.total)) total = Number(page.total);
    serverTruncated = serverTruncated || page.truncated === true;

    if (page.nextOffset == null) {
      reachedEnd = true;
      break;
    }
    const nextOffset = Number(page.nextOffset);
    if (!Number.isSafeInteger(nextOffset) || nextOffset <= offset || pageItems.length === 0) {
      throw new Error("The server returned an invalid next-page offset.");
    }
    offset = nextOffset;
  }

  const truncated = serverTruncated || !reachedEnd;
  return {
    status,
    media,
    items: mapRemoteItems(media),
    total: total || media.length,
    truncated,
  };
}

export async function fetchRemoteLibrary(connection: RemoteServerConnection) {
  const result = await fetchRemoteMedia(connection);
  return {
    status: result.status,
    items: result.items,
    total: result.total,
    truncated: result.truncated,
    nextOffset: result.truncated ? result.media.length : null,
  };
}
