import { create } from "zustand";
import { publishClock } from "@/player/clock";
import {
  buildItems,
  buildPathItems,
  collectHandle,
  forgetFile,
  looseFromList,
  mergeItems,
  permission,
  readDrop,
  urlFor as fileUrl,
  type Incoming,
} from "@/player/files";
import { desktop, joinFolder, mediaUrl } from "@/player/desktop";
import { media } from "@/player/media";
import { fetchRemoteLibrary, type RemoteServerConnection } from "@/player/remote";
import {
  clearBlobsAndHandles,
  clearLibraryStorage,
  deleteBlob,
  deleteHandle,
  loadAllBlobs,
  loadCounts,
  loadHandles,
  loadOverrides,
  loadSettings,
  saveBlob,
  saveCounts,
  saveHandle,
  saveOverrides,
  saveSettings,
} from "@/player/persist";
import {
  defaultSettings,
  metaOf,
  type FolderLink,
  type MediaItem,
  type MediaKind,
  type MetaOverride,
  type RepeatMode,
  type ScanState,
  type Settings,
  type ViewId,
} from "@/player/types";

const handleBin = new Map<string, FileSystemDirectoryHandle>();
const countedSession = new Set<string>();

let chain: Promise<unknown> = Promise.resolve();

function enqueue<T>(job: () => Promise<T>): Promise<T> {
  const run = chain.then(job, job);
  chain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

export function selectActiveItems(state: PlayerState) {
  return state.settings.librarySource === "server" ? state.remoteItems : state.items;
}

function activeItem(items: MediaItem[], currentId: string | null) {
  if (!currentId) return null;
  return items.find((item) => item.id === currentId) ?? null;
}

function activeElement(items: MediaItem[], currentId: string | null) {
  const item = activeItem(items, currentId);
  if (!item) return null;
  if (item.kind === "video") return media.video;
  if (item.kind === "audio") return media.audio;
  return null;
}

function sortByTitle(items: MediaItem[], overrides: Record<string, MetaOverride>) {
  return [...items].sort((a, b) =>
    metaOf(a, overrides).title.localeCompare(metaOf(b, overrides).title, undefined, { sensitivity: "base" }),
  );
}

export function audioPool(state: Pick<PlayerState, "items" | "overrides" | "musicArtist" | "musicAlbum" | "musicQuery">) {
  const query = state.musicQuery.trim().toLowerCase();
  return sortByTitle(
    state.items.filter((item) => {
      if (item.kind !== "audio") return false;
      const meta = metaOf(item, state.overrides);
      if (state.musicArtist !== "all" && meta.artist !== state.musicArtist) return false;
      if (state.musicAlbum !== "all" && meta.album !== state.musicAlbum) return false;
      if (!query) return true;
      return `${meta.title} ${meta.artist} ${meta.album} ${item.name}`.toLowerCase().includes(query);
    }),
    state.overrides,
  );
}

export function videoPool(state: Pick<PlayerState, "items" | "overrides" | "videoFolder" | "videoQuery">) {
  const query = state.videoQuery.trim().toLowerCase();
  return sortByTitle(
    state.items.filter((item) => {
      if (item.kind !== "video") return false;
      if (state.videoFolder !== "all" && item.folderKey !== state.videoFolder) return false;
      if (!query) return true;
      const meta = metaOf(item, state.overrides);
      return `${meta.title} ${item.relPath}`.toLowerCase().includes(query);
    }),
    state.overrides,
  );
}

export type PlayerState = {
  booted: boolean;
  view: ViewId;
  items: MediaItem[];
  remoteItems: MediaItem[];
  remoteConnected: boolean;
  folders: FolderLink[];
  settings: Settings;
  overrides: Record<string, MetaOverride>;
  viewCounts: Record<string, number>;
  artUrls: Record<string, string>;
  backgroundUrl: string | null;
  currentId: string | null;
  queue: string[];
  queueIndex: number;
  playing: boolean;
  error: string | null;
  notice: string | null;
  previewId: string | null;
  videoFolder: string;
  videoQuery: string;
  musicArtist: string;
  musicAlbum: string;
  musicQuery: string;
  galleryQuery: string;
  libraryQuery: string;
  libraryKind: "all" | MediaKind;
  scan: ScanState | null;
  theatre: boolean;
  editingId: string | null;
  boot: () => Promise<void>;
  setRemoteLibrary: (items: MediaItem[], connected: boolean) => void;
  setView: (view: ViewId) => void;
  addLoose: (files: FileList | File[]) => Promise<void>;
  linkFolder: (handle: FileSystemDirectoryHandle) => Promise<void>;
  linkDesktop: (folderPath: string) => Promise<void>;
  importDrop: (data: DataTransfer) => Promise<void>;
  reconnect: (id: string) => Promise<void>;
  rescan: (id: string) => Promise<void>;
  removeFolder: (id: string) => Promise<void>;
  removeItem: (id: string) => void;
  clearLibrary: () => Promise<void>;
  updateSettings: (patch: Partial<Settings>) => void;
  cycleRepeat: () => void;
  setOverride: (id: string, patch: MetaOverride) => void;
  setCover: (id: string, file: File) => Promise<void>;
  clearCover: (id: string) => Promise<void>;
  setBackground: (file: File | null) => Promise<void>;
  play: (id: string) => void;
  toggle: () => void;
  next: (fromEnd?: boolean) => void;
  prev: () => void;
  seek: (fraction: number) => void;
  fail: (message: string) => void;
  notePause: () => void;
  notePlay: () => void;
  markView: (id: string) => void;
  setPreview: (id: string | null) => void;
  setVideoFolder: (folder: string) => void;
  setVideoQuery: (query: string) => void;
  setMusicArtist: (artist: string) => void;
  setMusicAlbum: (album: string) => void;
  setMusicQuery: (query: string) => void;
  setGalleryQuery: (query: string) => void;
  setLibraryQuery: (query: string) => void;
  setLibraryKind: (kind: "all" | MediaKind) => void;
  setTheatre: (on: boolean) => void;
  setEditing: (id: string | null) => void;
  dismissNotice: () => void;
};

function bindAndPlay(item: MediaItem, volume: number) {
  const element = item.kind === "video" ? media.video : media.audio;
  const other = item.kind === "video" ? media.audio : media.video;
  if (!element) {
    usePlayer.setState({ playing: true, error: null });
    return;
  }
  if (element.dataset.mediaId !== item.id) {
    const nextUrl = item.streamUrl || fileUrl(item.id);
    if (!nextUrl) {
      usePlayer.setState({ playing: false, error: "That file isn't available anymore. Add it again." });
      return;
    }
    element.src = nextUrl;
    element.dataset.mediaId = item.id;
    publishClock(0, 0);
  }
  if (other && !other.paused) {
    media.ignorePause = true;
    other.pause();
    media.ignorePause = false;
  }
  element.volume = volume;
  void element.play().then(
    () => usePlayer.setState({ playing: true, error: null }),
    () => usePlayer.setState({ playing: false, error: "Couldn't start playback. Press play once more." }),
  );
}

function playQueueIndex(index: number) {
  const state = usePlayer.getState();
  const id = state.queue[index];
  const item = selectActiveItems(state).find((candidate) => candidate.id === id);
  if (!item) {
    usePlayer.setState({ playing: false });
    return;
  }
  usePlayer.setState({
    queueIndex: index,
    currentId: id,
    view: item.kind === "video" ? "videos" : state.view,
  });
  bindAndPlay(item, state.settings.volume);
}

async function ingestBuilt(items: MediaItem[], label: string, truncated: boolean, quiet = false) {
  if (!items.length) {
    usePlayer.setState({ scan: null, notice: "No audio, video, or images were found." });
    return;
  }
  usePlayer.setState((state) => ({
    items: mergeItems(state.items, items),
    scan: null,
    notice: truncated
      ? "Only the first 8,000 media files were added."
      : quiet
        ? null
        : `Saved “${label}”. It will still be here next time you open Sonicly.`,
  }));
}

async function ingest(incoming: Incoming[], label: string) {
  if (!incoming.length) {
    usePlayer.setState({ notice: "No audio, video, or images were found." });
    return;
  }
  const { items, truncated } = await buildItems(incoming, (done, total) => {
    usePlayer.setState({ scan: { done, total, label } });
  });
  if (!items.length) {
    usePlayer.setState({ scan: null, notice: "No audio, video, or images were found." });
    return;
  }
  usePlayer.setState((state) => ({
    items: mergeItems(state.items, items),
    scan: null,
    notice: truncated ? "Only the first 8,000 media files were added." : null,
  }));
}

let bootPromise: Promise<void> | null = null;

export const usePlayer = create<PlayerState>((set, get) => ({
  booted: false,
  view: "videos",
  items: [],
  remoteItems: [],
  remoteConnected: false,
  folders: [],
  settings: { ...defaultSettings },
  overrides: {},
  viewCounts: {},
  artUrls: {},
  backgroundUrl: null,
  currentId: null,
  queue: [],
  queueIndex: -1,
  playing: false,
  error: null,
  notice: null,
  previewId: null,
  videoFolder: "all",
  videoQuery: "",
  musicArtist: "all",
  musicAlbum: "all",
  musicQuery: "",
  galleryQuery: "",
  libraryQuery: "",
  libraryKind: "all",
  scan: null,
  theatre: false,
  editingId: null,

  boot: () => {
    if (!bootPromise) {
      bootPromise = enqueue(async () => {
        const settings = loadSettings();
        const overrides = loadOverrides();
        const viewCounts = loadCounts();
        const artUrls: Record<string, string> = {};
        let backgroundUrl: string | null = null;
        const blobs = await loadAllBlobs();
        for (const [key, blob] of Object.entries(blobs)) {
          if (key === "bg") backgroundUrl = URL.createObjectURL(blob);
          else if (key.startsWith("art:")) artUrls[key.slice(4)] = URL.createObjectURL(blob);
        }
        const saved = desktop() ? [] : await loadHandles();
        const folders: FolderLink[] = saved.map((folder) => {
          handleBin.set(folder.id, folder.handle);
          return { id: folder.id, name: folder.name, needsPermission: true };
        });
        set({ booted: true, settings, overrides, viewCounts, artUrls, backgroundUrl, folders });
        if (media.audio) media.audio.volume = settings.volume;
        if (media.video) media.video.volume = settings.volume;
        for (const folder of saved) {
          const perm = await permission(folder.handle, false);
          if (perm !== "granted") continue;
          set((state) => ({
            folders: state.folders.map((item) => (item.id === folder.id ? { ...item, needsPermission: false } : item)),
          }));
          try {
            const incoming = await collectHandle(folder.handle, folder.id, folder.name);
            await ingest(incoming, folder.name);
          } catch {
            set({ notice: `Couldn't read “${folder.name}”.` });
          }
        }
        set({ scan: null });
        const api = desktop();
        if (api) {
          const remembered = await api.listSaved();
          set({
            folders: remembered.map((folder) => ({ id: folder.id, name: folder.name, needsPermission: false })),
          });
          for (const folder of remembered) {
            try {
              const files = await api.scan(folder.path);
              const built = await buildPathItems(files, folder.id, folder.name, (relPath) => mediaUrl(joinFolder(folder.path, relPath)));
              await ingestBuilt(built.items, folder.name, built.truncated, true);
            } catch {
              set({ notice: `Couldn't read “${folder.name}”.` });
            }
          }
          set({ scan: null });
          try {
            const remoteConnection = await api.getRemoteServer();
            if (remoteConnection?.token) {
              const remote = await fetchRemoteLibrary(remoteConnection as RemoteServerConnection);
              set({ remoteItems: remote.items, remoteConnected: true });
            }
          } catch (error) {
            set({ remoteConnected: false });
            if (settings.librarySource === "server") {
              set({ notice: error instanceof Error ? `Couldn't load the server library: ${error.message}` : "Couldn't load the server library." });
            }
          }
        }
      }).catch((error: unknown) => {
        bootPromise = null;
        set({ booted: true, notice: error instanceof Error ? error.message : "Couldn't open the saved library." });
      });
    }
    return bootPromise;
  },

  setRemoteLibrary: (remoteItems, connected) => {
    const current = get();
    const currentStillExists = current.currentId && remoteItems.some((item) => item.id === current.currentId);
    if (current.settings.librarySource === "server" && current.currentId && !currentStillExists) stopPlayback();
    set({ remoteItems, remoteConnected: connected });
  },

  setView: (view) => {
    const settings = get().settings;
    if (view === "videos" && !settings.videosEnabled) return;
    if (view === "music" && !settings.musicEnabled) return;
    if (view === "gallery" && !settings.galleryEnabled) return;
    set({ view });
  },

  addLoose: (files) => {
    const list = [...files];
    return enqueue(async () => {
      try {
        const api = desktop();
        if (api) {
          const paths = list.map((file) => {
            try { return api.getPathForFile(file); } catch { return ""; }
          }).filter(Boolean);
          if (paths.length) await api.registerMobileFiles(paths);
        }
        await ingest(looseFromList(list), "Added files");
      } catch (error) {
        set({ scan: null, notice: error instanceof Error ? error.message : "Couldn't add those files." });
      }
    });
  },

  linkFolder: (handle) =>
    enqueue(async () => {
      for (const [id, existing] of handleBin) {
        try {
          if (await existing.isSameEntry(handle)) {
            await rescanFolder(id);
            return;
          }
        } catch {
          /* compare failed */
        }
      }
      const id = `dir_${crypto.randomUUID()}`;
      handleBin.set(id, handle);
      try {
        await saveHandle(id, handle.name, handle);
      } catch {
        set({ notice: "This browser couldn't remember the folder. Files still play for this visit." });
      }
      set((state) => ({
        folders: [...state.folders.filter((folder) => folder.id !== id), { id, name: handle.name, needsPermission: false }],
      }));
      const incoming = await collectHandle(handle, id, handle.name);
      await ingest(incoming, handle.name);
    }),

  linkDesktop: (folderPath) =>
    enqueue(async () => {
      const api = desktop();
      if (!api) return;
      const saved = await api.remember(folderPath);
      set((state) => ({
        folders: [...state.folders.filter((folder) => folder.id !== saved.id), { id: saved.id, name: saved.name, needsPermission: false }],
      }));
      const files = await api.scan(saved.path);
      const built = await buildPathItems(files, saved.id, saved.name, (relPath) => mediaUrl(joinFolder(saved.path, relPath)));
      await ingestBuilt(built.items, saved.name, built.truncated);
    }),

  importDrop: async (data) => {
    const dropped = await readDrop(data);
    for (const handle of dropped.handles) await get().linkFolder(handle);
    if (dropped.loose.length) await enqueue(async () => {
      const api = desktop();
      if (api) {
        const paths = dropped.loose.map((entry) => {
          try { return api.getPathForFile(entry.file); } catch { return ""; }
        }).filter(Boolean);
        if (paths.length) await api.registerMobileFiles(paths);
      }
      await ingest(dropped.loose, "Dropped files");
    });
  },

  reconnect: (id) =>
    enqueue(async () => {
      const handle = handleBin.get(id);
      if (!handle) return;
      const perm = await permission(handle, true);
      if (perm !== "granted") {
        set({ notice: "Permission was not granted for that folder." });
        return;
      }
      set((state) => ({
        folders: state.folders.map((folder) => (folder.id === id ? { ...folder, needsPermission: false } : folder)),
      }));
      await rescanFolder(id);
    }),

  rescan: (id) => enqueue(() => rescanFolder(id)),

  removeFolder: (id) =>
    enqueue(async () => {
      const gone = get().items.filter((item) => item.rootId === id);
      for (const item of gone) dropItem(item, get().artUrls);
      handleBin.delete(id);
      await deleteHandle(id);
      await desktop()?.forget(id);
      const currentGone = gone.some((item) => item.id === get().currentId);
      if (currentGone) stopPlayback();
      set((state) => ({
        folders: state.folders.filter((folder) => folder.id !== id),
        items: state.items.filter((item) => item.rootId !== id),
        queue: state.queue.filter((itemId) => !gone.some((item) => item.id === itemId)),
      }));
    }),

  removeItem: (id) => {
    if (get().settings.librarySource === "server") return;
    const item = get().items.find((candidate) => candidate.id === id);
    if (!item) return;
    dropItem(item, get().artUrls);
    if (item.rootId === "session") void deleteBlob(`art:${id}`);
    if (get().currentId === id) stopPlayback();
    set((state) => ({
      items: state.items.filter((candidate) => candidate.id !== id),
      queue: state.queue.filter((itemId) => itemId !== id),
      editingId: state.editingId === id ? null : state.editingId,
      previewId: state.previewId === id ? null : state.previewId,
      artUrls: omitKey(state.artUrls, id),
    }));
  },

  clearLibrary: () =>
    enqueue(async () => {
      for (const item of get().items) dropItem(item, get().artUrls);
      const background = get().backgroundUrl;
      if (background) URL.revokeObjectURL(background);
      for (const url of Object.values(get().artUrls)) URL.revokeObjectURL(url);
      handleBin.clear();
      countedSession.clear();
      stopPlayback();
      clearLibraryStorage();
      await clearBlobsAndHandles();
      await desktop()?.clear();
      set({
        items: [],
        folders: [],
        overrides: {},
        viewCounts: {},
        artUrls: {},
        backgroundUrl: null,
        previewId: null,
        editingId: null,
        notice: "Library cleared. Files on your computer were not deleted.",
      });
    }),

  updateSettings: (patch) => {
    const settings = { ...get().settings, ...patch };
    if (typeof settings.volume === "number") settings.volume = Math.min(1, Math.max(0, settings.volume));
    saveSettings(settings);
    let view = get().view;
    const sourceChanged = patch.librarySource != null && patch.librarySource !== get().settings.librarySource;
    if (sourceChanged) {
      stopPlayback();
      set({ previewId: null, editingId: null });
    }
    if (view === "videos" && !settings.videosEnabled) view = "library";
    if (view === "music" && !settings.musicEnabled) view = "library";
    if (view === "gallery" && !settings.galleryEnabled) view = "library";
    set({ settings, view });
    if (patch.volume != null) {
      if (media.audio) media.audio.volume = settings.volume;
      if (media.video) media.video.volume = settings.volume;
    }
  },

  cycleRepeat: () => {
    const order: RepeatMode[] = ["off", "all", "one"];
    const next = order[(order.indexOf(get().settings.repeat) + 1) % order.length];
    get().updateSettings({ repeat: next });
  },

  setOverride: (id, patch) => {
    const current = { ...(get().overrides[id] ?? {}), ...patch };
    const next: MetaOverride = {};
    if (current.title?.trim()) next.title = current.title.trim();
    if (current.artist?.trim()) next.artist = current.artist.trim();
    if (current.album?.trim()) next.album = current.album.trim();
    const overrides = { ...get().overrides };
    if (!next.title && !next.artist && !next.album) delete overrides[id];
    else overrides[id] = next;
    set({ overrides });
    saveOverrides(overrides);
  },

  setCover: async (id, file) => {
    try {
      await saveBlob(`art:${id}`, file);
    } catch {
      set({ notice: "Couldn't save that image in this browser." });
    }
    const prev = get().artUrls[id];
    if (prev) URL.revokeObjectURL(prev);
    set({ artUrls: { ...get().artUrls, [id]: URL.createObjectURL(file) } });
  },

  clearCover: async (id) => {
    await deleteBlob(`art:${id}`);
    const prev = get().artUrls[id];
    if (prev) URL.revokeObjectURL(prev);
    set({ artUrls: omitKey(get().artUrls, id) });
  },

  setBackground: async (file) => {
    const background = get().backgroundUrl;
    if (background) URL.revokeObjectURL(background);
    if (!file) {
      await deleteBlob("bg");
      set({ backgroundUrl: null });
      return;
    }
    try {
      await saveBlob("bg", file);
    } catch {
      set({ notice: "Couldn't save the background in this browser." });
    }
    set({ backgroundUrl: URL.createObjectURL(file) });
  },

  play: (id) => {
    const state = get();
    const activeItems = selectActiveItems(state);
    const item = activeItems.find((candidate) => candidate.id === id);
    if (!item || item.kind === "image") {
      set({ previewId: id, view: state.settings.galleryEnabled ? "gallery" : state.view });
      return;
    }
    const activeState = { ...state, items: activeItems };
    const pool = item.kind === "audio" ? audioPool(activeState) : videoPool({ ...activeState, videoFolder: state.videoFolder });
    const usable = pool.some((candidate) => candidate.id === id)
      ? pool
      : activeItems.filter((candidate) => candidate.kind === item.kind);
    const queue = usable.map((candidate) => candidate.id);
    set({
      currentId: id,
      queue,
      queueIndex: Math.max(0, queue.indexOf(id)),
      view: item.kind === "video" ? "videos" : state.view,
      error: null,
    });
    bindAndPlay(item, state.settings.volume);
  },

  toggle: () => {
    const state = get();
    const element = activeElement(selectActiveItems(state), state.currentId);
    if (!element) return;
    if (state.playing) {
      element.pause();
      set({ playing: false });
      return;
    }
    element.volume = state.settings.volume;
    void element.play().then(
      () => set({ playing: true, error: null }),
      () => set({ playing: false, error: "Couldn't start playback. Press play once more." }),
    );
  },

  next: (fromEnd) => {
    const state = get();
    if (!state.currentId) return;
    if (fromEnd && state.settings.repeat === "one") {
      const element = activeElement(selectActiveItems(state), state.currentId);
      if (element) {
        element.currentTime = 0;
        void element.play();
      }
      return;
    }
    const activeItems = selectActiveItems(state);
    const queue = state.queue.filter((id) => activeItems.some((item) => item.id === id));
    if (!queue.length) {
      set({ playing: false });
      return;
    }
    let index = queue.indexOf(state.currentId);
    if (index < 0) index = state.queueIndex;
    if (state.settings.shuffle && queue.length > 1) {
      let next = index;
      while (next === index) next = Math.floor(Math.random() * queue.length);
      set({ queue });
      playQueueIndex(next);
      return;
    }
    const next = index + 1;
    if (next >= queue.length) {
      if (state.settings.repeat === "all") {
        set({ queue });
        playQueueIndex(0);
      } else set({ playing: false, queue });
      return;
    }
    set({ queue });
    playQueueIndex(next);
  },

  prev: () => {
    const state = get();
    const element = activeElement(selectActiveItems(state), state.currentId);
    if (element && element.currentTime > 3) {
      element.currentTime = 0;
      publishClock(0, element.duration || 0);
      return;
    }
    const activeItems = selectActiveItems(state);
    const queue = state.queue.filter((id) => activeItems.some((item) => item.id === id));
    if (!queue.length || !state.currentId) return;
    let index = queue.indexOf(state.currentId);
    if (index < 0) index = 0;
    const next = index <= 0 ? (state.settings.repeat === "all" ? queue.length - 1 : 0) : index - 1;
    set({ queue });
    playQueueIndex(next);
  },

  seek: (fraction) => {
    const current = get();
    const element = activeElement(selectActiveItems(current), current.currentId);
    if (!element || !Number.isFinite(element.duration) || element.duration <= 0) return;
    const next = Math.min(1, Math.max(0, fraction)) * element.duration;
    element.currentTime = next;
    publishClock(next, element.duration);
  },

  fail: (message) => set({ playing: false, error: message }),
  notePause: () => {
    if (media.ignorePause) return;
    const current = get();
    const element = activeElement(selectActiveItems(current), current.currentId);
    if (!element || element.paused) set({ playing: false });
  },
  notePlay: () => set({ playing: true, error: null }),
  markView: (id) => {
    if (!get().settings.viewCountsEnabled || countedSession.has(id)) return;
    countedSession.add(id);
    const viewCounts = { ...get().viewCounts, [id]: (get().viewCounts[id] ?? 0) + 1 };
    set({ viewCounts });
    saveCounts(viewCounts);
  },
  setPreview: (id) => set({ previewId: id }),
  setVideoFolder: (videoFolder) => set({ videoFolder }),
  setVideoQuery: (videoQuery) => set({ videoQuery }),
  setMusicArtist: (musicArtist) => set({ musicArtist, musicAlbum: "all" }),
  setMusicAlbum: (musicAlbum) => set({ musicAlbum }),
  setMusicQuery: (musicQuery) => set({ musicQuery }),
  setGalleryQuery: (galleryQuery) => set({ galleryQuery }),
  setLibraryQuery: (libraryQuery) => set({ libraryQuery }),
  setLibraryKind: (libraryKind) => set({ libraryKind }),
  setTheatre: (theatre) => set({ theatre }),
  setEditing: (editingId) => set({ editingId }),
  dismissNotice: () => set({ notice: null }),
}));

async function rescanFolder(id: string) {
  const api = desktop();
  const saved = api ? (await api.listSaved()).find((folder) => folder.id === id) : undefined;
  if (saved && api) {
    const removed = usePlayer.getState().items.filter((item) => item.rootId === id);
    for (const item of removed) {
      if (item.embeddedArtUrl) URL.revokeObjectURL(item.embeddedArtUrl);
      forgetFile(item.id);
    }
    usePlayer.setState((state) => ({
      items: state.items.filter((item) => item.rootId !== id),
    }));
    const files = await api.scan(saved.path);
    const built = await buildPathItems(files, saved.id, saved.name, (relPath) => mediaUrl(joinFolder(saved.path, relPath)));
    await ingestBuilt(built.items, saved.name, built.truncated);
    return;
  }
  const handle = handleBin.get(id);
  if (!handle) return;
  const name = usePlayer.getState().folders.find((folder) => folder.id === id)?.name || handle.name;
  const removed = usePlayer.getState().items.filter((item) => item.rootId === id);
  for (const item of removed) {
    if (item.embeddedArtUrl) URL.revokeObjectURL(item.embeddedArtUrl);
    forgetFile(item.id);
  }
  usePlayer.setState((state) => ({
    items: state.items.filter((item) => item.rootId !== id),
  }));
  const incoming = await collectHandle(handle, id, name);
  await ingest(incoming, name);
}

function stopPlayback() {
  media.ignorePause = true;
  media.audio?.pause();
  media.video?.pause();
  media.ignorePause = false;
  publishClock(0, 0);
  usePlayer.setState({ playing: false, currentId: null, queue: [], queueIndex: -1 });
}

function dropItem(item: MediaItem, artUrls: Record<string, string>) {
  if (item.embeddedArtUrl) URL.revokeObjectURL(item.embeddedArtUrl);
  forgetFile(item.id);
  if (artUrls[item.id]) URL.revokeObjectURL(artUrls[item.id]);
}

function omitKey(record: Record<string, string>, key: string) {
  const next = { ...record };
  delete next[key];
  return next;
}
