export type MediaKind = "audio" | "video" | "image";

export type RepeatMode = "off" | "all" | "one";

export type ViewId = "videos" | "music" | "gallery" | "library" | "server" | "visualizer" | "settings";

export type MediaItem = {
  id: string;
  kind: MediaKind;
  rootId: string;
  rootName: string;
  relPath: string;
  name: string;
  ext: string;
  size: number;
  mime: string;
  title: string;
  artist: string;
  album: string;
  folderKey: string;
  folderLabel: string;
  embeddedArtUrl?: string;
  siblingArtId?: string;
  /** Authenticated same-origin proxy URL for a dedicated-server item. */
  streamUrl?: string;
  /** Authenticated same-origin proxy URL for server-side album/video artwork. */
  artworkUrl?: string;
  albumArtist?: string;
  trackNumber?: number;
  trackTotal?: number;
  discNumber?: number;
  discTotal?: number;
  year?: number | null;
  genre?: string;
  hasArtwork?: boolean;
  artworkMime?: string;
};

export type Settings = {
  videosEnabled: boolean;
  musicEnabled: boolean;
  galleryEnabled: boolean;
  viewCountsEnabled: boolean;
  volume: number;
  shuffle: boolean;
  repeat: RepeatMode;
  discordPresenceEnabled: boolean;
  discordClientId: string;
  librarySource: "local" | "server";
};

export type FolderLink = {
  id: string;
  name: string;
  needsPermission: boolean;
};

export type MetaOverride = {
  title?: string;
  artist?: string;
  album?: string;
};

export type ScanState = {
  done: number;
  total: number;
  label: string;
};

export const defaultSettings: Settings = {
  videosEnabled: true,
  musicEnabled: true,
  galleryEnabled: true,
  viewCountsEnabled: true,
  volume: 0.8,
  shuffle: false,
  repeat: "off",
  discordPresenceEnabled: false,
  discordClientId: "",
  librarySource: "local",
};

export function metaOf(item: MediaItem, overrides: Record<string, MetaOverride>) {
  const over = overrides[item.id];
  return {
    title: over?.title?.trim() || item.title,
    artist: over?.artist?.trim() || item.artist,
    album: over?.album?.trim() || item.album,
  };
}
