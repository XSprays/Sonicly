import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

/**
 * Static build for the Windows/macOS/Linux desktop shell.
 * The live preview keeps using vite.config.ts (server on port 8080).
 * This one writes a client-only site that Electron can open offline.
 */
export default defineConfig({
  base: "/",
  plugins: [
    tailwindcss(),
    tanstackStart({
      spa: {
        enabled: true,
        prerender: {
          outputPath: "index.html",
        },
      },
    }),
    viteReact(),
  ],
});
